# PLTW Potentiometer Control Dial v1.2

This revision keeps the original 16 mm potentiometer mount, two knob choices,
three labeled M3 terminals, and hollow underside tube grid. It adds the
resistor-style Coupon-F anchor feet and corrected open cardboard tabs.

## What changed

- Moved the cardboard tabs from the M3 nut-loading ends to the two long sides.
- Rebuilt both tabs as open, one-stud-wide × two-stud-long brick-style
  extensions aligned to the `X = −4 mm` LEGO stud column.
- Added the physically selected 3.4 × 1.8 mm brass-fastener slits.
- Opened each tab cavity directly into the main LEGO cavity; no hidden floor or
  partition remains.
- Added a 0.60 mm C-shaped first-layer anchor foot beneath each of the four
  Coupon-F clutch tubes.
- Aligned every anchor-foot notch with its existing `+Y` Coupon-F split.
- Kept all 15 original underside tube bores open; no solid support plugs were
  added.
- Kept every original LEGO stud center clear.
- Preserved all three end-loaded M3 nut paths and the `3V`, `SIG`, and `GND`
  labels.

The earlier v1.1 tabs were located on the same ends as the M3 nut-loading
openings. They also retained the older enclosed-tab construction. Version 1.2
replaces that geometry rather than cutting a larger slit into it.

## Included printable parts

- Potentiometer v1.2 dual-mount base
- 5.9 mm default combination-dial knob
- 5.9 mm default accessible wing knob
- Bushing fit coupon: 7.4, 7.6, and 7.8 mm
- Shaft fit coupon: 5.7, 5.9, and 6.1 mm
- M3 nut-trap coupon
- Brass-fastener slit coupon: 3.2, 3.4, and 3.6 mm

The potentiometer reference STL is used only for the preview and is not packed
as a printable classroom part.

## Print settings

- Bambu A1 mini or comparable printer
- PLA with a 0.4 mm nozzle
- Bambu 0.20 mm Standard profile
- Keep the remaining profile settings at their defaults
- LEGO underside on the build plate
- Supports off; raft off
- Knob shaft opening on the build plate

## Hardware

- One 10 kΩ linear 16 mm panel potentiometer
- Potentiometer washer and M7 nut
- Three M3 × 6 mm screws
- Three standard M3 nuts
- Three 9–10 mm M3 washers
- Three short insulated wires
- Two classroom brass fasteners for cardboard mounting

## Assembly

1. Print the bushing, shaft, M3 nut, and brass-fastener coupons first.
2. Insert the potentiometer from behind the upright panel.
3. Align its anti-rotation tab when present, then install its washer and nut.
4. Load all three M3 nuts through the unchanged right-side openings.
5. Connect the outside pins to `GND` and `3V`; connect the center wiper to
   `SIG`.
6. Clamp each short wire beneath its labeled M3 washer and screw.
7. Press the best-fitting knob onto the shaft.
8. For cardboard use, insert both brass fasteners from the top, pass their legs
   through the cardboard, spread the legs, and cover exposed metal with tape.

## Pilot-print status

The mesh is watertight and a single component. Automated clearance checks
confirm that:

- all four C-shaped anchor feet are present;
- all four anchor-foot notches remain open and aligned to the clutch splits;
- all 15 original underside tube-bore centers remain open;
- all 24 original body stud centers remain open;
- all four continuation-stud centers beneath the tabs remain open; and
- both tab cavities connect to the main LEGO cavity.

The final combined revision is still a prototype. Before classroom quantities,
physically confirm the potentiometer body and bushing, knob fit, all three M3
nuts, clockwise wiring direction, LEGO clutch, supportless first layers,
cardboard seating, and both brass fasteners.

# PLTW flex-sensor LEGO door/flap module v1.6 - extended open end and stem support

This module converts approximately 0-80 degrees of flap motion into a gradual
flex-sensor bend. The printed hinge carries the flap. The sensor is retained
loosely and bends over a replaceable 10 mm roller concentric with the hinge.

Version 1.6 keeps the proven 45 mm active-zone bend, F-fit LEGO underside,
connector clamp, flush 8-32 hinge, roller, and positive 80-degree stops. It
removes the closed-end hood completely. The flap is extended 15 mm and remains
open so the sensor can slide without transferring axial force back to its stem.

The revised base adds a broad fixed support beneath the connector-to-roller
span. Its top is 0.20 mm below the nominal sensor plane, so it supports a
sagging stem without clamping it or changing the bend location. For minimum
wear, cover the support surface with one smooth layer of clear tape.

Reprint the Version 1.6 base and flap as a matched pair. The clamp, roller,
optional test pin, pin keeper, M3 hardware, and 8-32 hinge hardware are reusable.

## Print

- Bambu A1 mini, 0.4 mm nozzle
- PLA for the first prototype
- 0.20 mm Standard
- Four walls and 20% gyroid
- Supports off
- Base: LEGO underside on the build plate
- Flap: keep the supplied long-side print orientation
- Optional 3 mm brim on the flap only if adhesion requires it

## Hardware

- Two standard M3 nuts
- Two M3 x 8 mm screws
- One 8-32 x 1.75 inch pan-head machine screw
- One standard 8-32 hex nut

The pan head sits in the circular recess and the standard nut sits in the
opposite hex recess. Do not use the previous 2.5 inch screw, washers, or nyloc
nut if a flush installation is required. Tighten only until side play is
removed; leave the flap free to rotate.

## Assembly

1. Test the hinge, M3 nut, and 7.8 mm connector coupons.
2. Slide the two M3 nuts into the raised deck from opposite sides.
3. Lay the flex sensor printed/striped side upward.
4. Place only the stiff connector between the clamp's shallow side guides.
5. Install the clamp with two M3 x 8 mm screws and tighten gently.
6. Confirm the active strip can slide lengthwise.
7. Place the 10 mm roller in the central hinge gap.
8. Place the flap barrels between the outer towers and beside the roller.
9. Align all 4.50 mm hinge holes.
10. Seat a standard 8-32 nut in the right-side hex recess.
11. Insert the 8-32 x 1.75 inch screw into the left circular recess and thread it into the nut.
12. Lay the fixed stem span over the broad support without taping it down.
13. Thread the active strip over the roller and beneath all four loose flap keepers.
14. Move the flap slowly from the closed stop toward the open stop.
15. Confirm the bend forms in the striped active area, not at the white stem.
16. Confirm the rounded tip remains supported by the extended flap and is free to slide.

The distal end is deliberately open. Do not add a stop, adhesive, or tight cap
to the sensor tip. The strip must slide lengthwise so repeated door movement
does not pull against the vulnerable connector stem.

## First-prototype checks

Before installing the sensor, bend the middle of its striped active region by
hand and confirm the analog value changes. If it does not, troubleshoot the
voltage-divider wiring and sensor before judging the mechanism.

Physically verify the 80-degree stop, active-zone bend, analog response, and
Bambu Studio support preview before classroom quantities. The sensor is an
approximate reference and the first print remains a fit-and-motion prototype.

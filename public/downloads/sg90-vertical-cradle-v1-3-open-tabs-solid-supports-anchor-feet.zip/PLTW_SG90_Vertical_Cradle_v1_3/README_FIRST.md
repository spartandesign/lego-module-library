# SG90 Vertical Cradle v1.3

This is a narrow cardboard-fit revision of v1.2. It starts from the exact
STL stored in the preceding tested package and subtracts only the two cardboard paths.

## Change in this revision

- Both brass-fastener paths are now 3.60 mm overall x 1.80 mm wide capsules.
- Path centers remain exactly (-36, 0), (36, 0) mm.
- No transform, support addition, mechanism edit, or accessory edit was applied.
- The exported STL was reloaded and compared geometrically with the prior STL. The
  removal-only delta is confined to the two path cutters, and the overall extents are unchanged.

## Supportless LEGO underside retained

- 15 safe non-clutch roof supports at 5.20 mm diameter x 2.85 mm high.
- 13 full-round supports and 2 portal-trimmed supports. Two edge supports remain intentionally portal-trimmed, with solid center cores.
- All 6 Coupon-F bores remain open.
- All 6 0.60 mm C-shaped first-layer anchors remain present and notch-aligned.
- All 28 body LEGO seating points remain open.

## Cardboard mounting

The two X-end tabs retain their 17 x 10 x 9.50 mm bodies, 16 x 6.40 x 2.72 mm underside cavities, 4 x 6.40 x 2.72 mm body portals, and 9.10 mm top head recesses.

The included coupon contains 3.2, 3.4, and 3.6 mm rows. Start with the **3.6 mm row**
because this module is fixed at 3.60 x 1.80 mm. Use the coupon to confirm the chosen
printer/material combination before making a class set.

## Preserved mechanism and accessories

- 12.5 mm body channel and 27.5 mm ear spacing
- 1.8 mm tower pilots and both lower wire portals
- upright horn sweep above the 25 mm towers
- two open brick-style X-end tabs and four continuation seating cavities

Every supplied strap, panel, link, flap, guide, and coupon is copied byte-for-byte from
the preceding package. M3-specific and LED-specific checks are not applicable to these
five servo mechanisms.

## Printing

- PLA, 0.4 mm nozzle, 0.20 mm Standard profile
- LEGO underside flat on the build plate
- Supports off; raft off
- Print moving accessories in their documented flat orientation

## Pilot status

Pilot the widened open tabs with the intended cardboard and brass fasteners before classroom quantities.

The mesh and package checks pass digitally, but a physical fit and motion pilot is still required.

# Preserved mechanism assembly reference

This guide came from the last mechanism revision. The printable base in this package supersedes its underside and cardboard-mount geometry.

---

# SG90 vertical LEGO cradle - compact 7 x 3 version

This version places the proven vertical SG90 cradle on a compact 56 x 24 mm
LEGO base.

## Unchanged tested features

- 12.5 mm servo body channel
- 27.5 mm mounting-hole spacing
- 1.8 mm servo-screw pilots
- Lower wire portals on both mounting towers
- Coupon-F split-ring LEGO interface

## Installation

1. Lower the servo between the 12.5 mm guides with its shaft upward.
2. Route the wire through the nearest lower tower portal.
3. Rest the two servo mounting ears on the tower tops.
4. Install the original servo screws into the 1.8 mm pilots.
5. Tighten only until the mounting ears cannot lift.

## Bambu A1 mini

- PLA
- 0.20 mm Standard
- Four walls
- 20% gyroid
- Supports off
- LEGO underside on the build plate

# SG90 Upright Dashboard Gauge v2.1

This is a narrow cardboard-fit revision of v2.0. It starts from the exact
STL stored in the preceding tested package and subtracts only the two cardboard paths.

## Change in this revision

- Both brass-fastener paths are now 3.60 mm overall x 1.80 mm wide capsules.
- Path centers remain exactly (-20, 12), (20, 12) mm.
- No transform, support addition, mechanism edit, or accessory edit was applied.
- The exported STL was reloaded and compared geometrically with the prior STL. The
  removal-only delta is confined to the two path cutters, and the overall extents are unchanged.

## Supportless LEGO underside retained

- 29 safe non-clutch roof supports at 5.20 mm diameter x 2.85 mm high.
- 29 full-round supports and 0 portal-trimmed supports.
- All 6 Coupon-F bores remain open.
- All 6 0.60 mm C-shaped first-layer anchors remain present and notch-aligned.
- All 48 body LEGO seating points remain open.

## Cardboard mounting

The two compact internal paths retain their 8.50 mm top-open head pockets from Z=5.00 to Z=8.00 and their solid floors outside the narrow slit.

The included coupon contains 3.2, 3.4, and 3.6 mm rows. Start with the **3.6 mm row**
because this module is fixed at 3.60 x 1.80 mm. Use the coupon to confirm the chosen
printer/material combination before making a class set.

## Preserved mechanism and accessories

- three exact 60 mm panels and their holder engagement
- 18 mm right-side horn opening and label-up orientation
- raised markings, wire exit, and exact retaining strap

Every supplied strap, panel, link, flap, guide, and coupon is copied byte-for-byte from
the preceding package. M3-specific and LED-specific checks are not applicable to these
five servo mechanisms.

## Printing

- PLA, 0.4 mm nozzle, 0.20 mm Standard profile
- LEGO underside flat on the build plate
- Supports off; raft off
- Print moving accessories in their documented flat orientation

## Pilot status

Pilot the widened cardboard paths and complete pointer sweep before classroom quantities.

The mesh and package checks pass digitally, but a physical fit and motion pilot is still required.

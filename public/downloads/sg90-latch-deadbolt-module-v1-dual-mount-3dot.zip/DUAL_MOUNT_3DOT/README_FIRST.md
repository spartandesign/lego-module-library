# Direct Cardboard Dual-Mount Variants — Prototype Set

These variants preserve each module's existing F-fit LEGO underside and add two **2.8 × 1.4 mm** flat-shank slits for direct attachment to cardboard with split-pin paper brads.

## Shared brad geometry

- Slit: 2.8 × 1.4 mm
- Head recess: 8.5 mm diameter × 3.0 mm deep
- Intended head: nominal 8 mm
- Recommended prong length: 14 mm minimum; 15–20 mm preferred for corrugated cardboard

## Assembly

1. Insert each brad from the top so its head rests in the recessed pocket.
2. Use the printed module to mark the two cardboard locations.
3. An adult makes the two narrow cardboard openings.
4. Push the brad legs through the cardboard and spread them on the inside.
5. Cover exposed legs with tape when students can touch the inside surface.

## Print settings

- Bambu A1 mini, 0.20 mm Standard
- PLA, 0.4 mm nozzle
- Four walls, 20% gyroid
- Supports off
- Keep the F-fit LEGO underside on the build plate

## Status

The original module mechanisms and F-fit interfaces retain their previous test status. The new cardboard slits and recessed-head locations are **prototypes requiring one complete pilot print** before classroom quantities.

## Modules not converted internally

The compact resistor, three-LED, piezo-buzzer, photocell family, potentiometer, and 7 × 3 vertical-servo cradle do not have two safe 8.5 mm head areas inside their existing footprints. Adding the same recesses would interfere with electrical hardware or the servo channel. They remain LEGO-only until a compact edge or single-fastener solution is physically developed.

# Confirmed Classroom Brass-Fastener Standard

Physical coupon testing confirmed the **two-dot opening** for the classroom brass fasteners.

## Production geometry

- Through-slit: **3.4 × 1.8 mm**
- Recessed head pocket: **8.5 mm diameter × 3.0 mm deep**
- Measured combined fastener-leg width: approximately **3.0 mm**
- Original Coupon-F LEGO clutch geometry: unchanged

The earlier 2.8 × 1.4 mm slit is superseded because it did not accept the measured fastener after printing.

## Printing

- Bambu A1 mini or P2S, 0.20 mm Standard
- PLA, 0.4 mm nozzle
- Four walls, 20% gyroid
- Supports off
- No raft
- Keep the LEGO underside on the build plate

## Cardboard assembly

1. Insert the brass fasteners from the top before attaching the module.
2. Use the module to mark the cardboard openings.
3. Have an adult make the two narrow cardboard openings.
4. Push the fastener legs through and spread them on the inside.
5. Cover exposed legs with tape when students can touch the inside surface.

The slit size is physically confirmed. Each revised module combination should still receive one complete pilot print before classroom quantities.

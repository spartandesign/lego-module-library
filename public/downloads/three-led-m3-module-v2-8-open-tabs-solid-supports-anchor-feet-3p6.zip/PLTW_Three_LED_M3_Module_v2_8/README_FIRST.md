# PLTW Three-LED M3 Terminal Module v2.8

This package starts from the exact current v2.7 STL and
changes the classroom brass-fastener capsule from 3.4 x 1.8 mm to
3.6 x 1.8 mm. Use the **3.6 mm row** of the included 3.2 / 3.4 / 3.6 mm coupon
before printing classroom quantities.

## What changed

- Both existing cardboard capsules are lengthened by 0.20 mm total: only
  0.10 mm of material is removed at each end; width stays 1.80 mm.
- Cardboard mount style remains open X-end tabs.
- Source extents and all unrelated geometry are preserved.
- Actual brad-only removed volume: 4.038510 mm^3.
- M3-clearance removed volume: 7.072718 mm^3.
- Added solid-support volume: 0.000000 mm^3.

The v2.7 LED holders, screw axes, polarity marks, 18 solid supports, six open clutch anchors, terminal top geometry, and open tabs are retained. Six nut tunnels receive only a localized indexed clearance cut below the terminal tops.

## Retained standards

- Footprint: 7 x 5 studs / 56 x 40 mm body; 89 mm across X tabs
- Overall exported extents: 89.00 x 40.00 x 12.30 mm
- 18 full 5.20 mm-diameter x 2.85 mm safe roof supports
- 6 open Coupon-F bores with aligned 0.60 mm C anchors
- 6 indexed M3 nut paths retain zero collision for a nominal 5.50 mm-AF x 2.40 mm nut envelope.
- 3 preserved 5.25 mm LED pocket(s).

## Three-LED indexed nut correction

The intended insertion orientation is 30 degrees in model XY: opposing nut
flats span X and a hex vertex points along each Y loading direction. Six
clearance cutters measure 5.55 mm across flats x 2.45 mm thick, giving the
required nominal 5.50 x 2.40 mm envelope a small export-safe allowance. The
cuts are confined to Z=4.525..6.975 mm and do not reach the terminal tops,
screw axes, polarity labels, LED holders, or underside.

The exact removed volume is reported in the validation JSON. No claim is made
for arbitrary nut rotation; insert all six nuts in the documented indexed
orientation.

## Printing and assembly

- PLA, 0.4 mm nozzle, 0.20 mm Standard profile
- LEGO underside on the build plate
- Supports off; raft off
- Print and test the 3.6 mm coupon row first
- Confirm LEGO seating, removal, cardboard fit, both fasteners, and the complete
  electrical/mechanical assembly before classroom quantities

Automated checks use the exact STL after export and reload. They do not replace
a physical pilot with the classroom printer, plate, hardware, and cardboard.

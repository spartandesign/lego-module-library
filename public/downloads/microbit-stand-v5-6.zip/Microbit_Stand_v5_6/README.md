# PLTW micro:bit Original-Guide Stand v5.6 — Reinforced Towers

This revision starts from the exact packaged v5.5 STL and strengthens both
tall board-retention towers. The guide-facing and board-facing contact surfaces
are unchanged, so the exact guide and vertical micro:bit insertion path remain
the same.

## What changed

- Each tower receives a 2.4–2.5 mm full-height rear/outward L-shaped spine.
- Smooth quarter-ellipse buttresses connect each tower to the base: rearward
  buttresses rise to Z=30.0 mm and outward buttresses rise to Z=28.0 mm.
- Material is added only behind and outside the functional tower faces.
- Two reinforcement-created, sub-nozzle rear/outward relief remnants are
  filled continuously from the supported base roof through the tower top.
- Net added printed volume: 3647.356 mm^3.

At Z=40 mm, tower cross-sectional area is 2.01x and
2.03x the v5.5 value. Centroidal bending inertia improves
by 3.76–4.63x, depending on tower
and loading direction.

## Preserved v5.5 standards

- Overall extents: 48.00 x 80.10 x 57.00 mm
- 39 full 5.20 mm-diameter x 2.85 mm solid roof supports
- Six open Coupon-F bores with aligned 0.60 mm C anchors
- All 60 LEGO stud clearances
- Both top-open 3.60 x 1.80 mm cardboard-fastener paths, head pockets, and floors
- Exact Microbit Alligator Clip Guide v2, copied without modification
- Watertight, consistently wound, single-component main STL

## Printing

- LEGO underside on the build plate
- PLA, 0.4 mm nozzle, 0.20 mm Standard profile
- Supports off; raft off
- For the strongest classroom result, use at least four wall loops
- Print and test the 3.6 mm row of the included fastener coupon first

The new tower spines are vertical and every buttress contracts toward the tower
as layers rise. No new downward-facing surface begins above the base roof.

## Assembly and pilot

1. Slide the micro:bit into the included exact alligator-clip guide.
2. Lower the guide and board vertically into the unchanged stand opening.
3. Confirm that the guide seats fully and that clips, buttons, display, and
   cable routing remain accessible.
4. Flex each tower only as required for insertion; do not pry it sideways.
5. Complete one physical pilot before classroom quantities.

Automated checks confirm topology, preserved clearances, guide/board keepouts,
and the section-strength improvement. They do not replace a physical print
with the classroom printer, filament, guide, board, LEGO, cardboard, and brass
fasteners.

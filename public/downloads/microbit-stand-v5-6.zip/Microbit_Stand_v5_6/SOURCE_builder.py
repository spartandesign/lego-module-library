from __future__ import annotations

import csv
import gc
import hashlib
import json
import math
import os
import sys
import zipfile
from pathlib import Path

CAD_DEPS = Path(r"C:\Users\trira\.codex\tmp\cad_pydeps")
sys.path.insert(0, str(CAD_DEPS))

import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont
from shapely.geometry import Polygon


OUTPUT_DIR = Path(__file__).resolve().parent
LATEST_DIR = OUTPUT_DIR.parent
V55_DIR = LATEST_DIR / "36_Circuit_Microbit_3p6_Upgrades" / "microbit_v5_5"
SOURCE_STL = V55_DIR / (
    "PLTW_Microbit_Stand_v5_5_InternalBrad_FFit_SolidRoofSupports_"
    "AnchoredCouponFFeet_3p6x1p8.stl"
)
SOURCE_ZIP = V55_DIR / (
    "microbit-original-guide-stand-v5-5-solid-supports-internal-paths-"
    "anchor-feet-3p6.zip"
)
SOURCE_MEMBER = (
    "PLTW_Microbit_Original_Guide_Stand_v5_5/"
    + SOURCE_STL.name
)
GUIDE_SOURCE = V55_DIR / "Microbit_Alligator_Clip_Guide_v2.stl"
ATTRIBUTION_SOURCE = V55_DIR / "THIRD_PARTY_ATTRIBUTION.md"
COUPON_SOURCE = (
    LATEST_DIR
    / "18_All_Modules_InternalBrad_3Dot_v0_1"
    / "STL"
    / "PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl"
)
OUTPUT_STL = OUTPUT_DIR / "Microbit_Stand_v5_6.stl"
OUTPUT_ZIP = OUTPUT_DIR / "microbit-stand-v5-6.zip"
ARCHIVE_ROOT = "Microbit_Stand_v5_6"
README_PATH = OUTPUT_DIR / "README.md"
DIMENSIONS_PATH = OUTPUT_DIR / "Dimensions.csv"
VALIDATION_JSON = OUTPUT_DIR / "Validation.json"
PRELIMINARY_JSON = OUTPUT_DIR / "Preliminary.json"
VALIDATION_MD = OUTPUT_DIR / "Validation.md"
ASSEMBLY_PREVIEW = OUTPUT_DIR / "Assembly.png"
TOP_PREVIEW = OUTPUT_DIR / "Top.png"
UNDERSIDE_PREVIEW = OUTPUT_DIR / "Underside.png"
GUIDE_OUTPUT = OUTPUT_DIR / "Guide.stl"
ATTRIBUTION_OUTPUT = OUTPUT_DIR / "Attribution.md"
COUPON_OUTPUT = OUTPUT_DIR / "Brad_Fit_Coupon.stl"
EXPECTED_SOURCE_SHA256 = (
    "2460685d29a7b3efb5df3a73d3f42abc07ced6a6c06b1f3ef870554da3e70c27"
)

BASE_Z = 8.00
TOP_Z = 57.00
SUPPORT_RADIUS = 2.60
SUPPORT_HEIGHT = 2.85
BRAD_LENGTH = 3.60
BRAD_WIDTH = 1.80
BRAD_CENTERS = ((12.0, -12.0), (12.0, 12.0))
CLUTCH_CENTERS = (
    (-16.05, -32.00),
    (-16.05, 0.10),
    (-16.05, 31.90),
    (16.05, -32.00),
    (16.05, 0.10),
    (16.05, 31.90),
)

# The inherited tower outlines contain two shallow, side-open reliefs.  The
# first reinforced build bridged across those reliefs with the rear/outward
# L-spines, turning them into 0.09 and 0.27 mm^2 vertical hairline pockets.
# These small vertical inserts overlap the inherited wall and both spine legs,
# filling only the non-functional rear/outward corner.  They start on the base
# roof and rise continuously to the tower top, so no lower void shell or new
# unsupported ceiling is created.
TOWER_RELIEF_FILL_BOUNDS = (
    ((8.00, -27.95, BASE_Z), (9.30, -27.20, TOP_Z)),
    ((8.00, 27.10, BASE_Z), (9.30, 28.15, TOP_Z)),
)


def grid(xs: tuple[float, ...], ys: tuple[float, ...]) -> tuple[tuple[float, float], ...]:
    return tuple((x, y) for x in xs for y in ys)


TUBE_CENTERS = grid(
    (-16.0, -8.0, 0.0, 8.0, 16.0),
    (-32.0, -24.0, -16.0, -8.0, 0.0, 8.0, 16.0, 24.0, 32.0),
)
SUPPORT_CENTERS = tuple(
    (x, y)
    for x, y in TUBE_CENTERS
    if not (
        abs(abs(x) - 16.0) < 0.2
        and min(abs(y + 32.0), abs(y), abs(y - 32.0)) < 0.2
    )
)
STUD_CENTERS = grid(
    (-20.0, -12.0, -4.0, 4.0, 12.0, 20.0),
    (-36.0, -28.0, -20.0, -12.0, -4.0, 4.0, 12.0, 20.0, 28.0, 36.0),
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_mesh(path: Path) -> trimesh.Trimesh:
    loaded = trimesh.load(path, force="mesh", process=True)
    if isinstance(loaded, trimesh.Scene):
        loaded = loaded.to_geometry()
    if not isinstance(loaded, trimesh.Trimesh):
        raise TypeError(f"Expected mesh at {path}")
    loaded.remove_unreferenced_vertices()
    return loaded


def box_from_bounds(low: tuple[float, float, float], high: tuple[float, float, float]) -> trimesh.Trimesh:
    low_array = np.asarray(low, dtype=float)
    high_array = np.asarray(high, dtype=float)
    result = trimesh.creation.box(extents=high_array - low_array)
    result.apply_translation((low_array + high_array) / 2.0)
    return result


def quarter_ellipse_profile(
    wall: float,
    toe: float,
    base_z: float,
    top_z: float,
    samples: int = 32,
) -> Polygon:
    points = [(wall, base_z), (toe, base_z)]
    for theta in np.linspace(math.pi / 2.0, 0.0, samples)[1:]:
        points.append(
            (
                wall + (toe - wall) * (1.0 - math.cos(float(theta))),
                top_z - (top_z - base_z) * math.sin(float(theta)),
            )
        )
    profile = Polygon(points)
    if not profile.is_valid:
        raise RuntimeError("Invalid quarter-ellipse buttress profile")
    return profile


def extrude_xz(profile: Polygon, y0: float, y1: float) -> trimesh.Trimesh:
    result = trimesh.creation.extrude_polygon(profile, height=y1 - y0)
    result.apply_transform(
        np.asarray(
            [
                [1.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, y0],
                [0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0],
            ]
        )
    )
    return result


def extrude_yz(profile: Polygon, x0: float, x1: float) -> trimesh.Trimesh:
    result = trimesh.creation.extrude_polygon(profile, height=x1 - x0)
    result.apply_transform(
        np.asarray(
            [
                [0.0, 0.0, 1.0, x0],
                [1.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0],
            ]
        )
    )
    return result


def reinforcement_parts() -> list[trimesh.Trimesh]:
    parts = [
        # Negative-Y tower: rear spine and outward cheek. These overlap the
        # old exterior by 0.10 mm while staying behind/outside the functional
        # guide and board contact faces.
        box_from_bounds((9.20, -30.35, BASE_Z), (11.70, -21.05, TOP_Z)),
        box_from_bounds((4.20, -30.35, BASE_Z), (9.30, -27.85, TOP_Z)),
        # Positive-Y tower.
        box_from_bounds((9.20, 20.95, BASE_Z), (11.70, 30.55, TOP_Z)),
        box_from_bounds((4.20, 28.05, BASE_Z), (9.30, 30.55, TOP_Z)),
    ]

    # Consume the two inherited rear/outward relief remnants that otherwise
    # become sub-nozzle vertical hairline pockets when wrapped by the L-spines.
    # Each fill begins on the supported base roof and reaches the tower top.
    parts.extend(
        box_from_bounds(lower, upper)
        for lower, upper in TOWER_RELIEF_FILL_BOUNDS
    )

    rear_profile = quarter_ellipse_profile(11.30, 18.10, BASE_Z, 30.00)
    parts.extend(
        (
            extrude_xz(rear_profile, -30.35, -21.05),
            extrude_xz(rear_profile, 20.95, 30.55),
        )
    )

    parts.extend(
        (
            extrude_yz(
                quarter_ellipse_profile(-29.95, -36.75, BASE_Z, 28.00),
                4.20,
                11.70,
            ),
            extrude_yz(
                quarter_ellipse_profile(30.15, 36.95, BASE_Z, 28.00),
                4.20,
                11.70,
            ),
        )
    )
    if not all(part.is_volume for part in parts):
        raise RuntimeError("A reinforcement primitive is not a closed volume")
    return parts


def export_reload(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    mesh.export(OUTPUT_STL)
    result = load_mesh(OUTPUT_STL)
    if not result.is_watertight:
        raise RuntimeError("Exported STL is not watertight after reload")
    return result


def intersection_volume(a: trimesh.Trimesh, b: trimesh.Trimesh) -> float:
    result = trimesh.boolean.intersection([a, b], engine="manifold")
    if result is None or len(result.faces) == 0:
        return 0.0
    return abs(float(result.volume))


def cylinder_at(
    x: float,
    y: float,
    radius: float,
    height: float,
    z0: float = 0.0,
    sections: int = 64,
) -> trimesh.Trimesh:
    result = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    result.apply_translation((x, y, z0 + height / 2.0))
    return result


def capsule_cutter(center: tuple[float, float]) -> trimesh.Trimesh:
    radius = BRAD_WIDTH / 2.0
    straight = BRAD_LENGTH - BRAD_WIDTH
    height = 9.20
    middle = trimesh.creation.box(extents=(BRAD_WIDTH, straight, height))
    middle.apply_translation((center[0], center[1], 3.60))
    ends = [
        cylinder_at(
            center[0],
            center[1] + sign * straight / 2.0,
            radius,
            height,
            z0=-1.0,
        )
        for sign in (-1.0, 1.0)
    ]
    return trimesh.boolean.union([middle, *ends], engine="manifold")


def contains(mesh: trimesh.Trimesh, points: list[tuple[float, float, float]]) -> list[bool]:
    result: list[bool] = []
    for start in range(0, len(points), 64):
        batch = np.asarray(points[start : start + 64])
        values = mesh.contains(batch)
        result.extend(bool(value) for value in values)
        del batch, values
        gc.collect()
    return result


def support_probe_points() -> list[tuple[float, float, float]]:
    points: list[tuple[float, float, float]] = []
    for x, y in SUPPORT_CENTERS:
        for radius in (0.0, 1.25, 2.30, 2.50):
            angles = (0.0,) if radius == 0.0 else np.linspace(0.0, 2.0 * math.pi, 12, endpoint=False)
            points.extend(
                (
                    x + radius * math.cos(float(angle)),
                    y + radius * math.sin(float(angle)),
                    z,
                )
                for angle in angles
                for z in (0.05, 0.30, 1.40, 2.30, 2.79, 2.84)
            )
    return points


def stud_probe_points() -> list[tuple[float, float, float]]:
    offsets = (
        (0.0, 0.0),
        (2.20, 0.0),
        (-2.20, 0.0),
        (0.0, 2.20),
        (0.0, -2.20),
        (1.55, 1.55),
        (1.55, -1.55),
        (-1.55, 1.55),
        (-1.55, -1.55),
    )
    return [
        (x + dx, y + dy, z)
        for x, y in STUD_CENTERS
        for dx, dy in offsets
        for z in (0.30, 1.40, 2.30)
    ]


def v55_regression(mesh: trimesh.Trimesh) -> dict[str, object]:
    support_points = support_probe_points()
    clutch_points = [
        (x, y, z)
        for x, y in CLUTCH_CENTERS
        for z in (0.05, 0.30, 0.59, 0.61, 1.40, 2.30)
    ]
    anchor_material: list[tuple[float, float, float]] = []
    anchor_above: list[tuple[float, float, float]] = []
    anchor_notches: list[tuple[float, float, float]] = []
    for x, y in CLUTCH_CENTERS:
        length = math.hypot(x, y)
        direction_x, direction_y = -x / length, -y / length
        perpendicular_x, perpendicular_y = -direction_y, direction_x
        material_xy = (
            (x - direction_x * 1.50, y - direction_y * 1.50),
            (x + perpendicular_x * 1.60, y + perpendicular_y * 1.60),
            (x - perpendicular_x * 1.60, y - perpendicular_y * 1.60),
        )
        for point_x, point_y in material_xy:
            anchor_material.extend((point_x, point_y, z) for z in (0.05, 0.30, 0.59))
            anchor_above.append((point_x, point_y, 0.61))
        for radius in (0.0, 0.75, 1.50, 2.50):
            anchor_notches.extend(
                (x + direction_x * radius, y + direction_y * radius, z)
                for z in (0.05, 0.30, 0.59)
            )

    brad_volumes = [intersection_volume(mesh, capsule_cutter(center)) for center in BRAD_CENTERS]
    floor_points = [
        (x + dx, y + dy, 5.00)
        for x, y in BRAD_CENTERS
        for dx, dy in ((3.0, 0.0), (0.0, 3.0))
    ]
    head_points = [
        (x + dx, y + dy, z)
        for x, y in BRAD_CENTERS
        for dx, dy in ((0.0, 0.0), (3.0, 0.0), (0.0, 3.0))
        for z in (5.50, 7.90)
    ]
    checks = {
        "support_count": len(SUPPORT_CENTERS),
        "support_diameter_mm": 5.20,
        "support_height_mm": 2.85,
        "dense_support_samples": len(support_points),
        "all_39_safe_support_disks_solid_to_roof": all(contains(mesh, support_points)),
        "clutch_count": len(CLUTCH_CENTERS),
        "all_6_coupon_f_centerlines_open": not any(contains(mesh, clutch_points)),
        "anchor_material_present_through_z_0p59": all(contains(mesh, anchor_material)),
        "anchor_material_ends_before_z_0p61": not any(contains(mesh, anchor_above)),
        "all_6_anchor_notches_open": not any(contains(mesh, anchor_notches)),
        "lego_stud_clearance_count": len(STUD_CENTERS),
        "all_60_lego_stud_clearances_open_dense": not any(contains(mesh, stud_probe_points())),
        "brad_slit_mm": [BRAD_LENGTH, BRAD_WIDTH],
        "brad_path_count": len(BRAD_CENTERS),
        "brad_collision_volume_mm3": [round(value, 9) for value in brad_volumes],
        "both_3p6x1p8_internal_paths_open": all(value <= 1.0e-7 for value in brad_volumes),
        "both_internal_head_pockets_open": not any(contains(mesh, head_points)),
        "solid_floor_retained_around_internal_slits": all(contains(mesh, floor_points)),
    }
    checks["all_v5_5_regression_checks_pass"] = all(
        (
            checks["all_39_safe_support_disks_solid_to_roof"],
            checks["all_6_coupon_f_centerlines_open"],
            checks["anchor_material_present_through_z_0p59"],
            checks["anchor_material_ends_before_z_0p61"],
            checks["all_6_anchor_notches_open"],
            checks["all_60_lego_stud_clearances_open_dense"],
            checks["both_3p6x1p8_internal_paths_open"],
            checks["both_internal_head_pockets_open"],
            checks["solid_floor_retained_around_internal_slits"],
        )
    )
    return checks


def section_moment(polygon: Polygon) -> dict[str, float]:
    points = np.asarray(polygon.exterior.coords)
    x0, y0 = points[:-1, 0], points[:-1, 1]
    x1, y1 = points[1:, 0], points[1:, 1]
    cross = x0 * y1 - x1 * y0
    area_signed = float(np.sum(cross) / 2.0)
    cx = float(np.sum((x0 + x1) * cross) / (6.0 * area_signed))
    cy = float(np.sum((y0 + y1) * cross) / (6.0 * area_signed))
    ixx_origin = float(np.sum((y0 * y0 + y0 * y1 + y1 * y1) * cross) / 12.0)
    iyy_origin = float(np.sum((x0 * x0 + x0 * x1 + x1 * x1) * cross) / 12.0)
    ixx = ixx_origin - area_signed * cy * cy
    iyy = iyy_origin - area_signed * cx * cx
    if area_signed < 0.0:
        area_signed, ixx, iyy = -area_signed, -ixx, -iyy
    return {
        "area_mm2": round(area_signed, 4),
        "ixx_mm4": round(ixx, 4),
        "iyy_mm4": round(iyy, 4),
    }


def tower_sections(mesh: trimesh.Trimesh, z: float) -> list[dict[str, float]]:
    section = mesh.section(plane_origin=(0.0, 0.0, z), plane_normal=(0.0, 0.0, 1.0))
    if section is None:
        raise RuntimeError(f"No cross section at Z={z}")
    polygons: list[Polygon] = []
    for line in section.discrete:
        polygon = Polygon(line[:, :2])
        bounds = polygon.bounds
        if polygon.is_valid and polygon.area > 10.0 and bounds[0] > 3.0 and (
            bounds[1] < -18.0 or bounds[3] > 18.0
        ):
            polygons.append(polygon)
    polygons.sort(key=lambda polygon: polygon.centroid.y)
    if len(polygons) != 2:
        raise RuntimeError(f"Expected two tower sections at Z={z}, found {len(polygons)}")
    return [section_moment(polygon) for polygon in polygons]


def tower_section_loop_count(mesh: trimesh.Trimesh, z: float) -> int:
    """Count closed tower-region section loops, including any interior voids."""
    section = mesh.section(plane_origin=(0.0, 0.0, z), plane_normal=(0.0, 0.0, 1.0))
    if section is None:
        raise RuntimeError(f"No cross section at Z={z}")
    loops = 0
    for line in section.discrete:
        polygon = Polygon(line[:, :2])
        bounds = polygon.bounds
        if (
            polygon.is_valid
            and polygon.area > 0.001
            and bounds[0] > 3.0
            and (bounds[1] < -18.0 or bounds[3] > 18.0)
        ):
            loops += 1
    return loops


def copy_assets() -> dict[str, str]:
    assets = (
        (GUIDE_SOURCE, GUIDE_OUTPUT),
        (ATTRIBUTION_SOURCE, ATTRIBUTION_OUTPUT),
        (COUPON_SOURCE, COUPON_OUTPUT),
    )
    hashes: dict[str, str] = {}
    for source, destination in assets:
        destination.write_bytes(source.read_bytes())
        if destination.read_bytes() != source.read_bytes():
            raise RuntimeError(f"Asset copy mismatch: {destination.name}")
        hashes[destination.name] = sha256(destination)
    return hashes


def write_readme(checks: dict[str, object]) -> None:
    ratios = checks["tower_section_ratios"]["40.0"]
    text = f"""# PLTW micro:bit Original-Guide Stand v5.6 — Reinforced Towers

This revision starts from the exact packaged v5.5 STL and strengthens both
tall board-retention towers. The guide-facing and board-facing contact surfaces
are unchanged, so the exact guide and vertical micro:bit insertion path remain
the same.

## What changed

- Each tower receives a 2.4–2.5 mm full-height rear/outward L-shaped spine.
- Smooth quarter-ellipse buttresses connect each tower to the base: rearward
  buttresses rise to Z=30.0 mm and outward buttresses rise to Z=28.0 mm.
- Material is added only behind and outside the functional tower faces.
- Two reinforcement-created, sub-nozzle rear/outward relief remnants are
  filled continuously from the supported base roof through the tower top.
- Net added printed volume: {checks['reinforcement_added_volume_mm3']:.3f} mm^3.

At Z=40 mm, tower cross-sectional area is {ratios[0]['area_mm2']:.2f}x and
{ratios[1]['area_mm2']:.2f}x the v5.5 value. Centroidal bending inertia improves
by {ratios[0]['ixx_mm4']:.2f}–{ratios[1]['iyy_mm4']:.2f}x, depending on tower
and loading direction.

## Preserved v5.5 standards

- Overall extents: 48.00 x 80.10 x 57.00 mm
- 39 full 5.20 mm-diameter x 2.85 mm solid roof supports
- Six open Coupon-F bores with aligned 0.60 mm C anchors
- All 60 LEGO stud clearances
- Both top-open 3.60 x 1.80 mm cardboard-fastener paths, head pockets, and floors
- Exact Microbit Alligator Clip Guide v2, copied without modification
- Watertight, consistently wound, single-component main STL

## Printing

- LEGO underside on the build plate
- PLA, 0.4 mm nozzle, 0.20 mm Standard profile
- Supports off; raft off
- For the strongest classroom result, use at least four wall loops
- Print and test the 3.6 mm row of the included fastener coupon first

The new tower spines are vertical and every buttress contracts toward the tower
as layers rise. No new downward-facing surface begins above the base roof.

## Assembly and pilot

1. Slide the micro:bit into the included exact alligator-clip guide.
2. Lower the guide and board vertically into the unchanged stand opening.
3. Confirm that the guide seats fully and that clips, buttons, display, and
   cable routing remain accessible.
4. Flex each tower only as required for insertion; do not pry it sideways.
5. Complete one physical pilot before classroom quantities.

Automated checks confirm topology, preserved clearances, guide/board keepouts,
and the section-strength improvement. They do not replace a physical print
with the classroom printer, filament, guide, board, LEGO, cardboard, and brass
fasteners.
"""
    README_PATH.write_text(text, encoding="utf-8")


def write_dimensions(checks: dict[str, object]) -> None:
    high = checks["tower_sections_reinforced"]["40.0"]
    ratios = checks["tower_section_ratios"]["40.0"]
    rows = [
        ("Feature", "Value"),
        ("Module", "PLTW micro:bit Original-Guide Stand v5.6 — Reinforced Towers"),
        ("Source", f"Exact packaged v5.5 STL; SHA-256 {checks['source_sha256']}"),
        ("Output STL SHA-256", checks["output_sha256"]),
        ("Overall extents", "48.00 x 80.10 x 57.00 mm"),
        ("Rear tower growth", "2.40 mm nominal; X max 9.30 to 11.70 mm"),
        ("Outward tower growth", "2.40 mm nominal on each tower"),
        ("Rear buttress", "Quarter ellipse; toe X=18.10 mm; high Z=30.00 mm"),
        ("Outward buttresses", "Quarter ellipse; toes Y=-36.75/+36.95 mm; high Z=28.00 mm"),
        ("Added volume", f"{checks['reinforcement_added_volume_mm3']:.6f} mm^3"),
        ("Negative tower area at Z40", f"{high[0]['area_mm2']:.4f} mm^2 ({ratios[0]['area_mm2']:.4f}x)"),
        ("Positive tower area at Z40", f"{high[1]['area_mm2']:.4f} mm^2 ({ratios[1]['area_mm2']:.4f}x)"),
        ("Negative tower inertia ratios at Z40", f"Ixx {ratios[0]['ixx_mm4']:.4f}x; Iyy {ratios[0]['iyy_mm4']:.4f}x"),
        ("Positive tower inertia ratios at Z40", f"Ixx {ratios[1]['ixx_mm4']:.4f}x; Iyy {ratios[1]['iyy_mm4']:.4f}x"),
        ("Solid roof supports", "39 at 5.20 mm diameter x 2.85 mm height"),
        ("Open Coupon-F bores / C anchors", "6 / 6"),
        ("LEGO stud clearances", "60"),
        ("Internal cardboard paths", "2 at 3.60 x 1.80 mm"),
        ("Exact guide seated transform", "Translate supplied STL by (-90.0, -90.0, +8.5) mm"),
        ("Board proxy", "1.60 x 52.0 x 43.0 mm; vertical center (0, 0, 34.25)"),
        ("Print orientation", "LEGO underside down; supports off"),
    ]
    with DIMENSIONS_PATH.open("w", newline="", encoding="utf-8") as handle:
        csv.writer(handle).writerows(rows)


def simplified(mesh: trimesh.Trimesh, face_count: int = 120000) -> trimesh.Trimesh:
    if len(mesh.faces) <= face_count:
        return mesh.copy()
    try:
        return mesh.simplify_quadric_decimation(face_count=face_count, aggression=4)
    except (ModuleNotFoundError, ValueError):
        return mesh.copy()


def render_isometric(
    specs: list[tuple[trimesh.Trimesh, tuple[int, int, int]]],
    path: Path,
    title: str,
    footer: str,
    view: tuple[float, float, float] = (1.0, -1.35, 0.90),
) -> None:
    view_vector = np.asarray(view, dtype=float)
    view_vector /= np.linalg.norm(view_vector)
    right = np.cross(view_vector, np.asarray((0.0, 0.0, 1.0)))
    right /= np.linalg.norm(right)
    up = np.cross(right, view_vector)
    up /= np.linalg.norm(up)
    light = np.asarray((0.30, -0.45, 0.84))
    light /= np.linalg.norm(light)
    triangles: list[tuple[float, np.ndarray, tuple[int, int, int]]] = []
    all_projected: list[np.ndarray] = []
    for mesh, color in specs:
        triangle_3d = mesh.vertices[mesh.faces]
        normals = np.cross(triangle_3d[:, 1] - triangle_3d[:, 0], triangle_3d[:, 2] - triangle_3d[:, 0])
        lengths = np.linalg.norm(normals, axis=1)
        valid = lengths > 1.0e-9
        normals[valid] /= lengths[valid, None]
        facing = normals @ view_vector > -0.10
        for triangle, normal in zip(triangle_3d[facing], normals[facing]):
            projected = np.column_stack((triangle @ right, -(triangle @ up)))
            depth = float(np.mean(triangle @ view_vector))
            shade = 0.70 + 0.30 * max(0.0, float(normal @ light))
            shaded = tuple(max(0, min(255, int(channel * shade))) for channel in color)
            triangles.append((depth, projected, shaded))
            all_projected.append(projected)
    all_points = np.vstack(all_projected)
    low, high = all_points.min(axis=0), all_points.max(axis=0)
    canvas = (1500, 1000)
    margin = 110
    scale = min(
        (canvas[0] - 2 * margin) / (high[0] - low[0]),
        (canvas[1] - 2 * margin - 100) / (high[1] - low[1]),
    )
    offset = np.asarray(
        (
            (canvas[0] - (high[0] - low[0]) * scale) / 2.0 - low[0] * scale,
            100.0 + (canvas[1] - 175 - (high[1] - low[1]) * scale) / 2.0 - low[1] * scale,
        )
    )
    image = Image.new("RGB", canvas, (247, 249, 252))
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    draw.text((45, 28), title, fill=(30, 40, 54), font=font)
    for _depth, projected, color in sorted(triangles, key=lambda item: item[0]):
        draw.polygon(
            [(float(x * scale + offset[0]), float(y * scale + offset[1])) for x, y in projected],
            fill=color,
        )
    draw.text((45, 955), footer, fill=(30, 40, 54), font=font)
    image.save(path)


def render_previews(mesh: trimesh.Trimesh) -> None:
    display = simplified(mesh)
    guide = load_mesh(OUTPUT_DIR / GUIDE_SOURCE.name)
    guide.apply_translation((-90.0, -90.0, 8.50))
    board = trimesh.creation.box(extents=(1.60, 52.0, 43.0))
    board.apply_translation((0.0, 0.0, 34.25))
    render_isometric(
        [(display, (174, 184, 194)), (guide, (225, 155, 62)), (board, (55, 122, 96))],
        ASSEMBLY_PREVIEW,
        "MICRO:BIT STAND v5.6 - REINFORCED TOWERS ASSEMBLY",
        "Orange = exact guide seated at Z=8.5; green = vertical micro:bit board proxy.",
    )
    render_isometric(
        [(display, (174, 184, 194))],
        TOP_PREVIEW,
        "MICRO:BIT STAND v5.6 - REINFORCED SUPPORTLESS MODULE",
        "Full-height rear/outward tower spines with smooth root buttresses; supports off.",
    )

    underside = display.copy()
    rotation = trimesh.transformations.rotation_matrix(math.pi, (1.0, 0.0, 0.0))
    underside.apply_transform(rotation)
    supports = trimesh.util.concatenate(
        [cylinder_at(x, y, SUPPORT_RADIUS, SUPPORT_HEIGHT) for x, y in SUPPORT_CENTERS]
    )
    supports.apply_transform(rotation)
    supports.apply_translation((0.0, 0.0, 0.03))
    anchors = trimesh.util.concatenate(
        [
            trimesh.boolean.intersection(
                [mesh, cylinder_at(x, y, 3.05, 0.60)],
                engine="manifold",
            )
            for x, y in CLUTCH_CENTERS
        ]
    )
    anchors.apply_transform(rotation)
    anchors.apply_translation((0.0, 0.0, 0.05))
    render_isometric(
        [(underside, (174, 184, 194)), (supports, (93, 151, 105)), (anchors, (65, 116, 168))],
        UNDERSIDE_PREVIEW,
        "MICRO:BIT STAND v5.6 - PRESERVED LEGO UNDERSIDE",
        "Green = 39 solid 5.20 x 2.85 roof supports; blue = six open C-anchor bores.",
    )


def write_validation(checks: dict[str, object]) -> None:
    VALIDATION_JSON.write_text(json.dumps(checks, indent=2) + "\n", encoding="utf-8")
    regression = checks["v5_5_regression"]
    lines = [
        "# PLTW micro:bit stand v5.6 validation",
        "",
        f"- Exact packaged v5.5 source: {checks['source_is_exact_v5_5_packaged_stl']}",
        f"- Watertight / winding consistent: {checks['watertight']} / {checks['winding_consistent']}",
        f"- Connected components: {checks['components']}",
        f"- Extents preserved: {checks['extents_preserved']}",
        f"- Source removal volume: {checks['source_removal_volume_mm3']} mm^3",
        f"- Added reinforcement volume: {checks['reinforcement_added_volume_mm3']} mm^3",
        f"- Exact guide / board collision: {checks['exact_guide_collision_mm3']} / {checks['conservative_board_collision_mm3']} mm^3",
        f"- Guide, board, and clip insertion keepouts clear: {checks['all_new_reinforcement_keepouts_clear']}",
        f"- High-shaft area at least 1.9x: {checks['all_high_shaft_areas_at_least_1p9x']}",
        f"- High-shaft inertias at least 3.5x: {checks['all_high_shaft_inertias_at_least_3p5x']}",
        f"- Supportless added geometry: {checks['supportless_added_geometry']}",
        f"- 39 solid roof supports retained: {regression['all_39_safe_support_disks_solid_to_roof']}",
        f"- Six open Coupon-F bores and anchors retained: {regression['all_6_coupon_f_centerlines_open'] and regression['all_6_anchor_notches_open']}",
        f"- All 60 LEGO clearances retained: {regression['all_60_lego_stud_clearances_open_dense']}",
        f"- Both 3.6 x 1.8 paths/head pockets/floors retained: {regression['both_3p6x1p8_internal_paths_open'] and regression['both_internal_head_pockets_open'] and regression['solid_floor_retained_around_internal_slits']}",
        f"- Package embeds exact files: {checks.get('package_embeds_exact_files', False)}",
        f"- All required checks pass: {checks['all_required_checks_pass']}",
        "",
        "All mesh checks use the exact binary STL after export and reload.",
        "A physical pilot remains required before classroom quantities.",
        "",
    ]
    VALIDATION_MD.write_text("\n".join(lines), encoding="utf-8")


def package_file_names() -> tuple[str, ...]:
    return (
        README_PATH.name,
        OUTPUT_STL.name,
        COUPON_OUTPUT.name,
        GUIDE_OUTPUT.name,
        ATTRIBUTION_OUTPUT.name,
        DIMENSIONS_PATH.name,
        VALIDATION_MD.name,
        VALIDATION_JSON.name,
        ASSEMBLY_PREVIEW.name,
        TOP_PREVIEW.name,
        UNDERSIDE_PREVIEW.name,
    )


def create_package() -> None:
    with zipfile.ZipFile(OUTPUT_ZIP, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in package_file_names():
            archive.write(OUTPUT_DIR / name, f"{ARCHIVE_ROOT}/{name}")
        archive.write(Path(__file__), f"{ARCHIVE_ROOT}/SOURCE_builder.py")


def package_embeds_exact_files() -> bool:
    with zipfile.ZipFile(OUTPUT_ZIP) as archive:
        ordinary = all(
            archive.read(f"{ARCHIVE_ROOT}/{name}") == (OUTPUT_DIR / name).read_bytes()
            for name in package_file_names()
        )
        source = archive.read(f"{ARCHIVE_ROOT}/SOURCE_builder.py") == Path(__file__).read_bytes()
    return ordinary and source


def build_geometry() -> None:
    if sha256(SOURCE_STL) != EXPECTED_SOURCE_SHA256:
        raise RuntimeError("Exact v5.5 source STL hash changed")
    with zipfile.ZipFile(SOURCE_ZIP) as archive:
        if archive.read(SOURCE_MEMBER) != SOURCE_STL.read_bytes():
            raise RuntimeError("Source STL is not the exact file embedded in the v5.5 package")

    source = load_mesh(SOURCE_STL)
    parts = reinforcement_parts()
    reinforcement = trimesh.boolean.union(parts, engine="manifold")
    combined = trimesh.boolean.union([source, *parts], engine="manifold")
    output = export_reload(combined)

    guide = load_mesh(GUIDE_SOURCE)
    guide.apply_translation((-90.0, -90.0, 8.50))
    board = box_from_bounds((-0.90, -26.50, 12.25), (0.90, 26.50, 56.25))
    clip_keepout = box_from_bounds((-3.70, -29.00, 8.00), (3.70, 29.00, 60.00))
    guide_sweep_points = np.vstack((guide.vertices, guide.vertices + np.asarray((0.0, 0.0, 50.0))))
    guide_insertion_sweep = trimesh.convex.convex_hull(guide_sweep_points)
    board_insertion_sweep = box_from_bounds((-0.90, -26.50, 12.25), (0.90, 26.50, 80.00))
    missing = trimesh.boolean.difference([source, output], engine="manifold")
    missing_volume = 0.0 if missing is None else abs(float(missing.volume))

    old_sections = {str(z): tower_sections(source, z) for z in (20.0, 40.0)}
    new_sections = {str(z): tower_sections(output, z) for z in (20.0, 40.0)}
    section_loop_counts = {
        str(z): tower_section_loop_count(output, z)
        for z in (20.0, 40.0, 56.0)
    }
    ratios: dict[str, list[dict[str, float]]] = {}
    for z in (20.0, 40.0):
        ratios[str(z)] = [
            {
                key: round(new_sections[str(z)][index][key] / old_sections[str(z)][index][key], 4)
                for key in ("area_mm2", "ixx_mm4", "iyy_mm4")
            }
            for index in range(2)
        ]

    downward_above_base = 0
    for part in parts:
        mask = part.face_normals[:, 2] < -1.0e-6
        downward_above_base += int(np.sum(part.triangles_center[mask, 2] > BASE_Z + 1.0e-4))

    backing_candidates = [
        (float(x), float(y), BASE_Z + 0.05)
        for y0, y1 in ((-36.75, -21.05), (20.95, 36.95))
        for x in np.arange(4.40, 18.10, 0.80)
        for y in np.arange(y0 + 0.20, y1, 0.80)
    ]
    at_reinforcement_floor = [
        point
        for point, inside in zip(backing_candidates, contains(reinforcement, backing_candidates))
        if inside
    ]
    source_backing_points = [(x, y, BASE_Z - 0.05) for x, y, _z in at_reinforcement_floor]
    all_floor_backed = all(contains(source, source_backing_points))

    guide_sweep_collision = intersection_volume(reinforcement, guide_insertion_sweep)
    board_sweep_collision = intersection_volume(reinforcement, board_insertion_sweep)
    clip_collision = intersection_volume(reinforcement, clip_keepout)

    checks = {
        "source_sha256": sha256(SOURCE_STL),
        "source_is_exact_v5_5_packaged_stl": True,
        "output_sha256": sha256(OUTPUT_STL),
        "watertight": bool(output.is_watertight),
        "winding_consistent": bool(output.is_winding_consistent),
        "components": len(output.split(only_watertight=False)),
        "bounds_mm": np.round(output.bounds, 4).tolist(),
        "extents_mm": np.round(output.extents, 4).tolist(),
        "extents_preserved": bool(np.allclose(output.extents, source.extents, atol=1.0e-5)),
        "source_removal_volume_mm3": round(missing_volume, 9),
        "no_source_material_removed": missing_volume <= 1.0e-5,
        "reinforcement_added_volume_mm3": round(float(output.volume - source.volume), 6),
        "exact_guide_collision_mm3": round(intersection_volume(output, guide), 9),
        "conservative_board_collision_mm3": round(intersection_volume(output, board), 9),
        "new_reinforcement_clip_keepout_collision_mm3": round(
            clip_collision, 9
        ),
        "new_reinforcement_guide_insertion_sweep_collision_mm3": round(guide_sweep_collision, 9),
        "new_reinforcement_board_insertion_sweep_collision_mm3": round(board_sweep_collision, 9),
        "all_new_reinforcement_keepouts_clear": bool(
            clip_collision <= 1.0e-7
            and guide_sweep_collision <= 1.0e-7
            and board_sweep_collision <= 1.0e-7
        ),
        "exact_guide_seated_transform_mm": [-90.0, -90.0, 8.5],
        "exact_guide_seated_bounds_mm": np.round(guide.bounds, 4).tolist(),
        "conservative_board_bounds_mm": np.round(board.bounds, 4).tolist(),
        "tower_sections_source": old_sections,
        "tower_sections_reinforced": new_sections,
        "tower_section_ratios": ratios,
        "tower_section_loop_counts": section_loop_counts,
        "tower_sections_have_no_internal_void_loops": all(
            count == 2 for count in section_loop_counts.values()
        ),
        "all_high_shaft_areas_at_least_1p9x": all(
            item["area_mm2"] >= 1.9 for item in ratios["40.0"]
        ),
        "all_high_shaft_inertias_at_least_3p5x": all(
            item["ixx_mm4"] >= 3.5 and item["iyy_mm4"] >= 3.5
            for item in ratios["40.0"]
        ),
        "reinforcement_downward_faces_above_base": downward_above_base,
        "reinforcement_floor_probe_count": len(source_backing_points),
        "all_reinforcement_floor_points_backed_by_v5_5_base": all_floor_backed,
        "reinforcement_min_z_mm": round(float(reinforcement.bounds[0, 2]), 4),
        "supportless_added_geometry": bool(downward_above_base == 0 and all_floor_backed),
    }
    checks["all_preliminary_checks_pass"] = bool(
        checks["watertight"]
        and checks["winding_consistent"]
        and checks["components"] == 1
        and checks["extents_preserved"]
        and checks["no_source_material_removed"]
        and checks["exact_guide_collision_mm3"] <= 1.0e-7
        and checks["conservative_board_collision_mm3"] <= 1.0e-7
        and checks["all_new_reinforcement_keepouts_clear"]
        and checks["all_high_shaft_areas_at_least_1p9x"]
        and checks["all_high_shaft_inertias_at_least_3p5x"]
        and checks["tower_sections_have_no_internal_void_loops"]
        and checks["supportless_added_geometry"]
    )
    if not checks["all_preliminary_checks_pass"]:
        PRELIMINARY_JSON.write_text(json.dumps(checks, indent=2) + "\n", encoding="utf-8")
        raise SystemExit("v5.6 preliminary geometry validation failed")
    PRELIMINARY_JSON.write_text(json.dumps(checks, indent=2) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {
                "geometry_pass": True,
                "stl": str(OUTPUT_STL),
                "stl_sha256": checks["output_sha256"],
            },
            indent=2,
        ),
        flush=True,
    )


def finalize_package() -> None:
    if not PRELIMINARY_JSON.exists() or not OUTPUT_STL.exists():
        raise RuntimeError("Run the geometry stage before finalization")
    checks = json.loads(PRELIMINARY_JSON.read_text(encoding="utf-8"))
    if not checks.get("all_preliminary_checks_pass"):
        raise RuntimeError("Preliminary geometry checks did not pass")
    if sha256(OUTPUT_STL) != checks["output_sha256"]:
        raise RuntimeError("Output STL changed after the geometry stage")

    output = load_mesh(OUTPUT_STL)
    checks["v5_5_regression"] = v55_regression(output)
    output._cache.clear()
    gc.collect()
    checks["asset_sha256"] = copy_assets()
    checks["assets_copied_byte_for_byte"] = True
    checks["guide_geometry_unchanged"] = (
        checks["asset_sha256"][GUIDE_OUTPUT.name] == sha256(GUIDE_SOURCE)
    )
    checks["package_embeds_exact_files"] = False
    checks["all_required_checks_pass"] = bool(
        checks["all_preliminary_checks_pass"]
        and checks["v5_5_regression"]["all_v5_5_regression_checks_pass"]
        and checks["assets_copied_byte_for_byte"]
        and checks["guide_geometry_unchanged"]
    )
    if not checks["all_required_checks_pass"]:
        write_validation(checks)
        raise SystemExit("v5.6 full geometry regression failed")

    write_readme(checks)
    write_dimensions(checks)
    render_previews(output)
    del output
    gc.collect()
    write_validation(checks)
    create_package()
    checks["package_embeds_exact_files"] = package_embeds_exact_files()
    checks["all_required_checks_pass"] = bool(
        checks["all_required_checks_pass"] and checks["package_embeds_exact_files"]
    )
    write_validation(checks)
    create_package()
    if not package_embeds_exact_files():
        raise SystemExit("Final v5.6 package exact-file verification failed")
    print(
        json.dumps(
            {
                "pass": checks["all_required_checks_pass"],
                "stl": str(OUTPUT_STL),
                "stl_sha256": checks["output_sha256"],
                "zip": str(OUTPUT_ZIP),
                "zip_sha256": sha256(OUTPUT_ZIP),
                "added_volume_mm3": checks["reinforcement_added_volume_mm3"],
                "v5_5_regression": checks["v5_5_regression"]["all_v5_5_regression_checks_pass"],
            },
            indent=2,
        ),
        flush=True,
    )
    if not checks["all_required_checks_pass"]:
        raise SystemExit("Final v5.6 package failed")


if __name__ == "__main__":
    if "--finalize-only" in sys.argv:
        finalize_package()
    else:
        build_geometry()
        if "--geometry-only" not in sys.argv:
            # Use the basename after changing directory: the bundled Windows
            # runtime truncates an absolute script argument at workspace spaces.
            os.chdir(OUTPUT_DIR)
            os.execv(sys.executable, [sys.executable, Path(__file__).name, "--finalize-only"])

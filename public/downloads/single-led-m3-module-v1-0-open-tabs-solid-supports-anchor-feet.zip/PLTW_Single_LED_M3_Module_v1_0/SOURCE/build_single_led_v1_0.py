from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
import zipfile
from pathlib import Path


CAD_DEPS = Path(r"C:\Users\trira\.codex\tmp\cad_pydeps")
sys.path.insert(0, str(CAD_DEPS))

import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont


OUTPUT_DIR = Path(__file__).resolve().parent
LATEST_DIR = OUTPUT_DIR.parent
SOURCE_BASE = (
    LATEST_DIR
    / "23_Compact_Resistor_v2_8_Polarity_Labels"
    / "PLTW_Resistor_LEGO_Module_v2_8_FFit_DualMount_"
    "PolarityLabels_3p4x1p8.stl"
)
LED_DONOR = (
    LATEST_DIR
    / "30_Three_LED_v2_6_OpenTabs_AnchorFeet"
    / "PLTW_Three_LED_LEGO_Module_v2_6_FFit_DualMount_"
    "OpenBrickTabs_AnchoredCouponFFeet_3p4x1p8.stl"
)
BRAD_COUPON_SOURCE = (
    LATEST_DIR
    / "18_All_Modules_InternalBrad_3Dot_v0_1"
    / "STL"
    / "PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl"
)

FILE_PREFIX = "PLTW_Single_LED_v1_0"
ARCHIVE_ROOT = "PLTW_Single_LED_M3_Module_v1_0"
OUTPUT_STL_NAME = (
    "PLTW_Single_LED_M3_Module_v1_0_FFit_DualMount_OpenBrickTabs_"
    "SolidRoofSupports_AnchoredCouponFFeet_3p4x1p8.stl"
)
OUTPUT_STL = OUTPUT_DIR / OUTPUT_STL_NAME
OUTPUT_ZIP = OUTPUT_DIR / (
    "single-led-m3-module-v1-0-open-tabs-solid-supports-anchor-feet.zip"
)
M3_COUPON_NAME = "PLTW_Single_LED_M3_Nut_Path_Fit_Coupon.stl"
M3_COUPON = OUTPUT_DIR / M3_COUPON_NAME
BRAD_COUPON_NAME = BRAD_COUPON_SOURCE.name

BODY_TUBES = tuple(
    (x, y)
    for x in (-12.0, -4.0, 4.0, 12.0)
    for y in (-4.0, 4.0)
)
CLUTCH_CENTERS = tuple(
    (x, y)
    for x in (-12.0, 12.0)
    for y in (-4.0, 4.0)
)
SUPPORT_CENTERS = tuple(
    point for point in BODY_TUBES if point not in CLUTCH_CENTERS
)
BODY_STUD_CENTERS = tuple(
    (x, y)
    for x in (-16.0, -8.0, 0.0, 8.0, 16.0)
    for y in (-8.0, 0.0, 8.0)
)
TAB_CONTINUATION_CENTERS = (
    (0.0, -24.0),
    (0.0, -16.0),
    (0.0, 16.0),
    (0.0, 24.0),
)
TERMINAL_AXES = ((-13.0, 0.0), (13.0, 0.0))

SUPPORT_RADIUS = 2.60
SUPPORT_HEIGHT = 2.85
CLUTCH_ANCHOR_RADIUS = 3.00
CLUTCH_ANCHOR_HEIGHT = 0.60
LED_POCKET_RADIUS = 2.625
LED_FEATURE_RADIUS = 4.10
LED_SUPPORT_GAP = math.hypot(4.0, 4.0) - SUPPORT_RADIUS - LED_POCKET_RADIUS

SHAVE_MIN = np.array([-6.60, -4.50, 7.321])
SHAVE_MAX = np.array([6.60, 4.50, 12.60])
LED_EXTRACT_Z = (9.49, 12.31)
LED_Z_SHIFT = -2.18

M3_AF = 5.50
M3_THICKNESS = 2.40
M3_CENTER_Z = 5.52
M3_INDEXED_ANGLE_DEG = 0.0
M3_REJECTED_ANGLE_DEG = 30.0


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_mesh(path: Path) -> trimesh.Trimesh:
    loaded = trimesh.load(path, force="mesh", process=True)
    if isinstance(loaded, trimesh.Scene):
        loaded = loaded.to_geometry()
    if not isinstance(loaded, trimesh.Trimesh):
        raise TypeError(f"Expected a mesh at {path}, got {type(loaded)!r}")
    loaded.remove_unreferenced_vertices()
    return loaded


def cylinder_at(
    x: float,
    y: float,
    radius: float,
    height: float,
    z0: float = 0.0,
    sections: int = 96,
) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(
        radius=radius,
        height=height,
        sections=sections,
    )
    mesh.apply_translation([x, y, z0 + height / 2.0])
    return mesh


def box_from_bounds(low: np.ndarray, high: np.ndarray) -> trimesh.Trimesh:
    mesh = trimesh.creation.box(extents=high - low)
    mesh.apply_translation((low + high) / 2.0)
    return mesh


def export_and_reload(mesh: trimesh.Trimesh, path: Path) -> trimesh.Trimesh:
    mesh.remove_unreferenced_vertices()
    mesh.export(path)
    exported = load_mesh(path)
    nondegenerate = exported.nondegenerate_faces()
    if not bool(np.all(nondegenerate)):
        exported.update_faces(nondegenerate)
        exported.remove_unreferenced_vertices()
        exported.export(path)
        exported = load_mesh(path)
    return exported


def clutch_split_direction(x: float, _y: float) -> tuple[float, float]:
    """The resistor donor's indexed splits point inward along X."""
    return (1.0, 0.0) if x < 0.0 else (-1.0, 0.0)


def coupon_f_anchor_overlay(x: float, y: float) -> trimesh.Trimesh:
    direction_x, direction_y = clutch_split_direction(x, y)
    disk = cylinder_at(
        x,
        y,
        CLUTCH_ANCHOR_RADIUS,
        CLUTCH_ANCHOR_HEIGHT,
    )
    notch = trimesh.creation.box(extents=[4.20, 1.55, 1.00])
    angle = math.atan2(direction_y, direction_x)
    notch.apply_transform(
        trimesh.transformations.rotation_matrix(angle, [0.0, 0.0, 1.0])
    )
    notch.apply_translation(
        [x + direction_x * 2.0, y + direction_y * 2.0, 0.30]
    )
    return trimesh.boolean.difference([disk, notch], engine="manifold")


def hex_swept_envelope(
    start: tuple[float, float],
    end: tuple[float, float],
    across_flats: float,
    thickness: float,
    center_z: float,
    angle_deg: float,
) -> trimesh.Trimesh:
    """Convex solid swept by a flat M3 hex nut between two XY centers."""
    radius = across_flats / math.sqrt(3.0)
    angle = math.radians(angle_deg)
    hex_xy = tuple(
        (
            radius * math.cos(angle + index * math.pi / 3.0),
            radius * math.sin(angle + index * math.pi / 3.0),
        )
        for index in range(6)
    )
    points = np.asarray(
        [
            (center[0] + dx, center[1] + dy, center_z + dz)
            for center in (start, end)
            for dx, dy in hex_xy
            for dz in (-thickness / 2.0, thickness / 2.0)
        ]
    )
    envelope = trimesh.convex.convex_hull(points)
    envelope.remove_unreferenced_vertices()
    return envelope


def intersection_volume(a: trimesh.Trimesh, b: trimesh.Trimesh) -> float:
    overlap = trimesh.boolean.intersection([a, b], engine="manifold")
    if overlap is None or len(overlap.faces) == 0:
        return 0.0
    return abs(float(overlap.volume))


def build_module() -> tuple[
    trimesh.Trimesh,
    trimesh.Trimesh,
    trimesh.Trimesh,
    list[trimesh.Trimesh],
    list[trimesh.Trimesh],
]:
    source = load_mesh(SOURCE_BASE)
    led_donor = load_mesh(LED_DONOR)

    shave = box_from_bounds(SHAVE_MIN, SHAVE_MAX)
    shaved = trimesh.boolean.difference([source, shave], engine="manifold")

    extract = cylinder_at(
        0.0,
        0.0,
        LED_FEATURE_RADIUS,
        LED_EXTRACT_Z[1] - LED_EXTRACT_Z[0],
        z0=LED_EXTRACT_Z[0],
        sections=128,
    )
    led_feature = trimesh.boolean.intersection(
        [led_donor, extract],
        engine="manifold",
    )
    led_feature.apply_transform(
        trimesh.transformations.rotation_matrix(
            math.pi / 2.0,
            [0.0, 0.0, 1.0],
        )
    )
    led_feature.apply_translation([0.0, 0.0, LED_Z_SHIFT])

    result = trimesh.boolean.union([shaved, led_feature], engine="manifold")
    exported = export_and_reload(result, OUTPUT_STL)

    supports = [
        cylinder_at(x, y, SUPPORT_RADIUS, SUPPORT_HEIGHT)
        for x, y in SUPPORT_CENTERS
    ]
    # Preview the donor's exact first-layer C geometry instead of drawing an
    # idealized replacement.  The module construction intentionally preserves
    # this geometry byte-for-byte below the center-only top shave.
    anchors = [
        trimesh.boolean.intersection(
            [
                source,
                cylinder_at(x, y, 3.05, CLUTCH_ANCHOR_HEIGHT, sections=96),
            ],
            engine="manifold",
        )
        for x, y in CLUTCH_CENTERS
    ]
    return source, led_donor, exported, supports, anchors


def build_m3_coupon() -> trimesh.Trimesh:
    base = trimesh.creation.box(extents=[48.0, 18.0, 8.0])
    base.apply_translation([0.0, 0.0, 4.0])
    lane_specs = ((-16.0, 5.60), (0.0, 5.80), (16.0, 6.00))
    cutters: list[trimesh.Trimesh] = []
    for x, clearance_af in lane_specs:
        cutters.append(
            hex_swept_envelope(
                (x, -10.0),
                (x, 0.0),
                clearance_af,
                2.65,
                4.20,
                M3_INDEXED_ANGLE_DEG,
            )
        )
        cutters.append(cylinder_at(x, 0.0, 1.70, 10.0, z0=-1.0))

    coupon = trimesh.boolean.difference([base, *cutters], engine="manifold")

    # One, two, or three raised dots identify the 5.60, 5.80, and 6.00 mm lanes.
    dots: list[trimesh.Trimesh] = []
    for x, count in ((-16.0, 1), (0.0, 2), (16.0, 3)):
        offsets = np.linspace(-(count - 1) * 0.85, (count - 1) * 0.85, count)
        dots.extend(
            cylinder_at(x + float(offset), 6.2, 0.58, 0.60, z0=8.0, sections=48)
            for offset in offsets
        )
    coupon = trimesh.boolean.union([coupon, *dots], engine="manifold")
    return export_and_reload(coupon, M3_COUPON)


def contains(mesh: trimesh.Trimesh, points: list[tuple[float, float, float]]) -> list[bool]:
    if not points:
        return []
    return [bool(value) for value in mesh.contains(np.asarray(points))]


def validate_module(
    source: trimesh.Trimesh,
    led_donor: trimesh.Trimesh,
    mesh: trimesh.Trimesh,
) -> dict[str, object]:
    support_points: list[tuple[float, float, float]] = []
    for x, y in SUPPORT_CENTERS:
        for radius in np.linspace(0.0, 2.45, 8):
            angles = (0.0,) if radius == 0.0 else np.linspace(
                0.0, 2.0 * math.pi, 24, endpoint=False
            )
            for angle in angles:
                for z in (0.05, 0.30, 1.40, 2.50, 2.79):
                    support_points.append(
                        (
                            x + float(radius) * math.cos(float(angle)),
                            y + float(radius) * math.sin(float(angle)),
                            z,
                        )
                    )

    clutch_bores = [
        (x, y, z)
        for x, y in CLUTCH_CENTERS
        for z in (0.05, 0.30, 0.59, 0.61, 1.40, 2.30)
    ]
    anchor_material: list[tuple[float, float, float]] = []
    anchor_above: list[tuple[float, float, float]] = []
    anchor_notches: list[tuple[float, float, float]] = []
    for x, y in CLUTCH_CENTERS:
        direction_x, direction_y = clutch_split_direction(x, y)
        perpendicular_x, perpendicular_y = -direction_y, direction_x
        material_xy = (
            (x - direction_x * 1.50, y - direction_y * 1.50),
            (x + perpendicular_x * 1.60, y + perpendicular_y * 1.60),
            (x - perpendicular_x * 1.60, y - perpendicular_y * 1.60),
        )
        for point_x, point_y in material_xy:
            anchor_material.extend(
                (point_x, point_y, z) for z in (0.05, 0.30, 0.59)
            )
            anchor_above.append((point_x, point_y, 0.61))
        # The preserved resistor anchor is a crescent inside the clutch ring.
        # Its indexed opening runs from the bore center to the 2.25 mm inner
        # edge; the surrounding Coupon-F ring remains intentionally present.
        for radius in (0.0, 0.75, 1.50, 2.25):
            anchor_notches.extend(
                (
                    x + direction_x * radius,
                    y + direction_y * radius,
                    z,
                )
                for z in (0.05, 0.30, 0.59)
            )

    tab_portals = [
        (x, sign * y, 1.40)
        for sign in (-1.0, 1.0)
        for x in (-2.30, 0.0, 2.30)
        for y in (11.0, 12.0, 13.0, 16.0, 20.0, 24.0)
    ]
    tab_slits = [
        (x, sign * 20.0, z)
        for sign in (-1.0, 1.0)
        for x in (-0.70, 0.0, 0.70)
        for z in (0.10, 4.00, 9.20)
    ]

    screw_bore_points: list[tuple[float, float, float]] = []
    for x, y in TERMINAL_AXES:
        for radius in (0.0, 0.50, 1.00, 1.40):
            angles = (0.0,) if radius == 0.0 else np.linspace(
                0.0, 2.0 * math.pi, 24, endpoint=False
            )
            for angle in angles:
                screw_bore_points.extend(
                    (
                        x + radius * math.cos(float(angle)),
                        y + radius * math.sin(float(angle)),
                        z,
                    )
                    for z in (3.00, 4.08, 5.52, 6.96, 8.00, 9.50, 10.00)
                )

    pocket_open_points: list[tuple[float, float, float]] = []
    floor_solid_points: list[tuple[float, float, float]] = []
    for radius in np.linspace(0.0, 2.55, 12):
        angles = (0.0,) if radius == 0.0 else np.linspace(
            0.0, 2.0 * math.pi, 36, endpoint=False
        )
        for angle in angles:
            x = float(radius) * math.cos(float(angle))
            y = float(radius) * math.sin(float(angle))
            pocket_open_points.extend(
                (x, y, z) for z in (7.34, 8.00, 9.00, 9.50, 10.00)
            )
            floor_solid_points.extend((x, y, z) for z in (7.20, 7.30))

    # The imported holder has two indexed diagonal lead slots which turn toward
    # the X terminals after the required 90-degree rotation.
    lead_exit_points = [
        (
            radius * math.cos(math.radians(angle_deg)),
            radius * math.sin(math.radians(angle_deg)),
            z,
        )
        for angle_deg in (150.0, 330.0)
        for radius in np.linspace(2.70, 4.00, 14)
        for z in (8.50, 9.00)
    ]

    indexed_volumes: list[float] = []
    rejected_volumes: list[float] = []
    for start, end in (((-21.0, 0.0), (-13.0, 0.0)), ((13.0, 0.0), (21.0, 0.0))):
        indexed = hex_swept_envelope(
            start,
            end,
            M3_AF,
            M3_THICKNESS,
            M3_CENTER_Z,
            M3_INDEXED_ANGLE_DEG,
        )
        rejected = hex_swept_envelope(
            start,
            end,
            M3_AF,
            M3_THICKNESS,
            M3_CENTER_Z,
            M3_REJECTED_ANGLE_DEG,
        )
        indexed_volumes.append(intersection_volume(mesh, indexed))
        rejected_volumes.append(intersection_volume(mesh, rejected))

    checks: dict[str, object] = {
        "watertight": bool(mesh.is_watertight),
        "winding_consistent": bool(mesh.is_winding_consistent),
        "components": len(mesh.split(only_watertight=False)),
        "faces": int(len(mesh.faces)),
        "bounds_mm": [[round(float(value), 3) for value in row] for row in mesh.bounds],
        "extents_mm": [round(float(value), 3) for value in mesh.extents],
        "source_base_sha256": sha256(SOURCE_BASE),
        "led_donor_sha256": sha256(LED_DONOR),
        "output_stl_sha256": sha256(OUTPUT_STL),
        "source_underside_and_tabs_preserved_by_construction": True,
        "source_polarity_labels_preserved_outside_center_shave": True,
        "shave_box_bounds_mm": [SHAVE_MIN.tolist(), SHAVE_MAX.tolist()],
        "led_extract": {
            "radius_mm": LED_FEATURE_RADIUS,
            "source_z_mm": list(LED_EXTRACT_Z),
            "rotation_z_deg": 90.0,
            "translation_z_mm": LED_Z_SHIFT,
        },
        "solid_support_count": len(SUPPORT_CENTERS),
        "dense_support_disk_samples": len(support_points),
        "all_four_support_disks_solid_to_roof": all(contains(mesh, support_points)),
        "open_coupon_f_bore_count": len(CLUTCH_CENTERS),
        "all_four_clutch_centerlines_open": not any(contains(mesh, clutch_bores)),
        "anchor_material_present_through_z_0p59": all(contains(mesh, anchor_material)),
        "anchor_material_ends_before_z_0p61": not any(contains(mesh, anchor_above)),
        "all_four_anchor_notches_open": not any(contains(mesh, anchor_notches)),
        "all_15_body_lego_seating_points_open": not any(
            contains(mesh, [(x, y, 1.40) for x, y in BODY_STUD_CENTERS])
        ),
        "four_tab_continuation_stud_centers_open": not any(
            contains(
                mesh,
                [(x, y, z) for x, y in TAB_CONTINUATION_CENTERS for z in (0.30, 1.40, 2.30)],
            )
        ),
        "both_tab_cavities_and_base_portals_open": not any(contains(mesh, tab_portals)),
        "both_3p4x1p8_brad_slits_open": not any(contains(mesh, tab_slits)),
        "both_m3_screw_axes_open_dense": not any(contains(mesh, screw_bore_points)),
        "m3_nut": {
            "nominal_across_flats_mm": M3_AF,
            "nominal_thickness_mm": M3_THICKNESS,
            "center_z_mm": M3_CENTER_Z,
            "indexed_angle_deg": M3_INDEXED_ANGLE_DEG,
            "indexed_description": "flat-aligned donor orientation; hex vertices on X axis",
            "indexed_swept_collision_volume_mm3": [round(value, 9) for value in indexed_volumes],
            "indexed_sweeps_zero_collision": all(value <= 1e-7 for value in indexed_volumes),
            "rejected_control_angle_deg": M3_REJECTED_ANGLE_DEG,
            "rejected_control_collision_volume_mm3": [round(value, 6) for value in rejected_volumes],
            "rejected_control_confirms_keying": all(value > 0.10 for value in rejected_volumes),
        },
        "led_pocket_nominal_diameter_mm": 5.25,
        "led_pocket_open_from_z_7p34_to_top": not any(contains(mesh, pocket_open_points)),
        "led_pocket_blind_floor_solid_through_z_7p30": all(
            contains(mesh, floor_solid_points)
        ),
        "both_led_lead_exits_open_toward_terminals": not any(
            contains(mesh, lead_exit_points)
        ),
        "led_pocket_to_support_planar_gap_mm": round(LED_SUPPORT_GAP, 3),
        "led_pocket_clears_all_support_disks": LED_SUPPORT_GAP >= 0.40,
    }
    checks["all_required_checks_pass"] = bool(
        checks["watertight"]
        and checks["winding_consistent"]
        and checks["components"] == 1
        and checks["all_four_support_disks_solid_to_roof"]
        and checks["all_four_clutch_centerlines_open"]
        and checks["anchor_material_present_through_z_0p59"]
        and checks["anchor_material_ends_before_z_0p61"]
        and checks["all_four_anchor_notches_open"]
        and checks["all_15_body_lego_seating_points_open"]
        and checks["four_tab_continuation_stud_centers_open"]
        and checks["both_tab_cavities_and_base_portals_open"]
        and checks["both_3p4x1p8_brad_slits_open"]
        and checks["both_m3_screw_axes_open_dense"]
        and checks["m3_nut"]["indexed_sweeps_zero_collision"]
        and checks["m3_nut"]["rejected_control_confirms_keying"]
        and checks["led_pocket_open_from_z_7p34_to_top"]
        and checks["led_pocket_blind_floor_solid_through_z_7p30"]
        and checks["both_led_lead_exits_open_toward_terminals"]
        and checks["led_pocket_clears_all_support_disks"]
    )
    return checks


def validate_m3_coupon(coupon: trimesh.Trimesh) -> dict[str, object]:
    lane_specs = ((-16.0, 5.60), (0.0, 5.80), (16.0, 6.00))
    collision_volumes = []
    screw_points: list[tuple[float, float, float]] = []
    for x, _clearance_af in lane_specs:
        nominal = hex_swept_envelope(
            (x, -10.0),
            (x, 0.0),
            M3_AF,
            M3_THICKNESS,
            4.20,
            M3_INDEXED_ANGLE_DEG,
        )
        collision_volumes.append(intersection_volume(coupon, nominal))
        screw_points.extend(
            (x + radius * math.cos(angle), radius * math.sin(angle), z)
            for radius in (0.0, 0.75, 1.40)
            for angle in np.linspace(0.0, 2.0 * math.pi, 20, endpoint=False)
            for z in (0.10, 2.00, 4.20, 6.00, 7.90)
        )
    return {
        "watertight": bool(coupon.is_watertight),
        "winding_consistent": bool(coupon.is_winding_consistent),
        "components": len(coupon.split(only_watertight=False)),
        "extents_mm": [round(float(value), 3) for value in coupon.extents],
        "lane_clearance_across_flats_mm": [value for _x, value in lane_specs],
        "lane_dot_code": [1, 2, 3],
        "nominal_m3_swept_collision_volume_mm3": [
            round(value, 9) for value in collision_volumes
        ],
        "all_nominal_indexed_nut_sweeps_open": all(
            value <= 1e-7 for value in collision_volumes
        ),
        "all_three_screw_bores_open": not any(contains(coupon, screw_points)),
        "output_sha256": sha256(M3_COUPON),
    }


def write_readme(mesh: trimesh.Trimesh) -> None:
    text = f"""# PLTW Single 5 mm LED M3 Module v1.0

This compact module holds one standard 5 mm LED and preserves the physically
confirmed compact resistor v2.8 mechanical scaffold. The complete LEGO
underside, Y-end cardboard tabs, X-end M3 nut tunnels, terminal axes, and raised
polarity marks are unchanged. Only the centered resistor cradle was shaved;
the proven center LED holder from the three-LED v2.6 module was rotated so its
two lead exits point toward the two terminals.

## Key geometry

- 5 x 3-stud / 40 x 24 mm nominal LEGO body
- Overall printable mesh: {mesh.extents[0]:.2f} x {mesh.extents[1]:.2f} x {mesh.extents[2]:.2f} mm
- One centered 5.25 mm blind LED pocket; the underside remains closed
- Four solid non-gripping roof supports
- Four open Coupon-F clutch bores with aligned 0.60 mm C anchor feet
- Two open Y-end cardboard tabs with 3.4 x 1.8 mm brass-fastener slits
- Two preserved side-loaded M3 terminals at X = -13 and +13 mm
- Raised `+` and `-` marks remain visible beside the terminals and away from
  the X-end nut openings

The calculated planar gap from the LED pocket to each solid support disk is
{LED_SUPPORT_GAP:.3f} mm. Dense exported-mesh sampling confirms that the holder
and both lead exits do not trim the four support disks.

## M3 nut insertion

The nut tunnels are keyed. Use a standard nominal 5.5 mm-across-flats x 2.4 mm
M3 nut in the donor's indexed flat-aligned orientation (hex vertices on the X
axis in the model):

1. Insert the left nut from the left X end toward the `+` terminal.
2. Insert the right nut from the right X end toward the `-` terminal.
3. Keep each nut flat-aligned as it slides; do not rotate it 30 degrees.

Boolean swept-envelope validation of the exact reloaded STL reports zero
collision for both indexed paths. A 30-degree control orientation collides and
confirms that the passage is intentionally keyed.

## LED assembly

1. Test the included M3 and brass-fastener coupons first.
2. Insert the LED from the top into the blind pocket.
3. Aim the long anode lead toward the left `+` terminal (X = -13 mm).
4. Aim the short cathode / flat-side lead toward the right `-` terminal
   (X = +13 mm).
5. Bend each lead gently through its lead exit and beneath a conductive washer.
6. Install two M3 x 6 mm screws, nuts, and 9-12 mm washers. Tighten only enough
   to capture the LED leads without cutting them.

## Printing

- PLA, 0.4 mm nozzle, 0.20 mm Standard profile
- Four wall loops, 20% gyroid
- LEGO underside on the build plate
- Supports off; raft off
- Use a small outer brim if corner lifting occurs

## Coupon map

- Brass coupon: 3.2 / 3.4 / 3.6 mm fastener slits; use the 3.4 mm row first.
- M3 coupon: one dot = 5.60 mm AF clearance, two dots = 5.80 mm, three dots =
  6.00 mm. Test the one-dot lane first with the same flat-aligned orientation.

## Pilot status

Automated mesh, support, clutch, anchor, cardboard-path, LED-pocket, screw-axis,
and true swept-nut checks pass on the exact exported-and-reloaded STL. A physical
pilot with the classroom LEGO plate, LED, M3 hardware, cardboard, brass
fasteners, printer, and slicer is still required before classroom quantities.
"""
    (OUTPUT_DIR / "README_FIRST.md").write_text(text, encoding="utf-8")


def write_dimensions(mesh: trimesh.Trimesh) -> None:
    rows = [
        ("Feature", "Value"),
        ("Module", "PLTW Single 5 mm LED M3 Module v1.0"),
        ("LEGO body footprint", "5 x 3 studs / 40 x 24 mm nominal"),
        ("Overall mesh extents", " x ".join(f"{value:.2f}" for value in mesh.extents) + " mm"),
        ("LED pocket", "5.25 mm diameter, blind, centered"),
        ("LED pocket floor", "Solid through Z = 7.30 mm; pocket opens at Z = 7.32 mm"),
        ("LED feature source", "Three-LED v2.6 center holder, rotated 90 degrees"),
        ("LED pocket-to-support planar gap", f"{LED_SUPPORT_GAP:.3f} mm"),
        ("M3 terminal axes", "X = -13 and +13 mm; Y = 0"),
        ("M3 nut envelope", "5.5 mm AF x 2.4 mm; indexed 0-degree X sweep"),
        ("M3 hardware", "2 x M3 x 6 mm screws, nuts, and 9-12 mm washers"),
        ("Polarity", "Left X terminal +; right X terminal -"),
        ("Solid roof supports", "4 at 5.20 mm diameter x 2.85 mm high"),
        ("Coupon-F clutch bores", "4 open"),
        ("C anchor feet", "4 at 6.00 mm diameter x 0.60 mm high"),
        ("Cardboard tabs", "2 open Y-end tabs"),
        ("Brass-fastener slit", "3.4 x 1.8 mm capsule"),
        ("Tab centers", "Y = -20 and +20 mm; X = 0"),
        ("Tab underside cavity", "16.0 x 6.4 x 2.72 mm"),
        ("Brad head recess", "9.1 mm diameter x 1.22 mm deep"),
    ]
    with (OUTPUT_DIR / f"{FILE_PREFIX}_Dimensions.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        csv.writer(handle).writerows(rows)


def render_isometric(
    specs: list[tuple[trimesh.Trimesh, tuple[int, int, int]]],
    path: Path,
    title: str,
    footer: str,
    overlay_count: int = 0,
) -> None:
    view = np.array([1.0, -1.35, 0.90])
    view /= np.linalg.norm(view)
    right = np.cross(view, np.array([0.0, 0.0, 1.0]))
    right /= np.linalg.norm(right)
    up = np.cross(right, view)
    up /= np.linalg.norm(up)
    light = np.array([0.30, -0.45, 0.84])
    light /= np.linalg.norm(light)

    triangles: list[tuple[float, np.ndarray, tuple[int, int, int]]] = []
    overlays: list[tuple[float, np.ndarray, tuple[int, int, int]]] = []
    projected_all: list[np.ndarray] = []
    overlay_start = len(specs) - overlay_count
    for index, (mesh, color) in enumerate(specs):
        tri3 = mesh.vertices[mesh.faces]
        normals = np.cross(tri3[:, 1] - tri3[:, 0], tri3[:, 2] - tri3[:, 0])
        lengths = np.linalg.norm(normals, axis=1)
        valid = lengths > 1e-9
        normals[valid] /= lengths[valid, None]
        facing = normals @ view > -0.10
        for triangle, normal in zip(tri3[facing], normals[facing]):
            projected = np.column_stack((triangle @ right, -(triangle @ up)))
            depth = float(np.mean(triangle @ view))
            shade = 0.70 + 0.30 * max(0.0, float(normal @ light))
            shaded = tuple(
                max(0, min(255, int(channel * shade))) for channel in color
            )
            target = overlays if overlay_count and index >= overlay_start else triangles
            target.append((depth, projected, shaded))
            projected_all.append(projected)

    all_points = np.vstack(projected_all)
    low = all_points.min(axis=0)
    high = all_points.max(axis=0)
    canvas = (1500, 1000)
    margin = 110
    scale = min(
        (canvas[0] - 2 * margin) / (high[0] - low[0]),
        (canvas[1] - 2 * margin - 100) / (high[1] - low[1]),
    )
    offset = np.array(
        [
            (canvas[0] - (high[0] - low[0]) * scale) / 2.0 - low[0] * scale,
            100.0
            + (canvas[1] - 175 - (high[1] - low[1]) * scale) / 2.0
            - low[1] * scale,
        ]
    )
    image = Image.new("RGB", canvas, (247, 249, 252))
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    draw.text((45, 28), title, fill=(30, 40, 54), font=font)
    for collection in (triangles, overlays):
        for _depth, projected, color in sorted(collection, key=lambda item: item[0]):
            points = [
                (float(x * scale + offset[0]), float(y * scale + offset[1]))
                for x, y in projected
            ]
            draw.polygon(points, fill=color)
    draw.text((45, 955), footer, fill=(30, 40, 54), font=font)
    image.save(path)


def led_assembly_proxy() -> trimesh.Trimesh:
    body = cylinder_at(0.0, 0.0, 2.45, 5.5, z0=7.55, sections=96)
    dome = trimesh.creation.uv_sphere(radius=2.45, count=[48, 24])
    dome.apply_translation([0.0, 0.0, 13.05])
    left_lead = trimesh.creation.box(extents=[10.0, 0.65, 0.65])
    left_lead.apply_translation([-7.5, 0.0, 8.75])
    right_lead = trimesh.creation.box(extents=[10.0, 0.65, 0.65])
    right_lead.apply_translation([7.5, 0.0, 8.75])
    washers = [cylinder_at(x, 0.0, 4.0, 0.60, z0=10.05) for x in (-13.0, 13.0)]
    return trimesh.util.concatenate([body, dome, left_lead, right_lead, *washers])


def render_previews(
    mesh: trimesh.Trimesh,
    supports: list[trimesh.Trimesh],
    anchors: list[trimesh.Trimesh],
) -> None:
    render_isometric(
        [(mesh, (174, 184, 194)), (led_assembly_proxy(), (55, 122, 96))],
        OUTPUT_DIR / f"{FILE_PREFIX}_Assembly_Preview.png",
        "SINGLE LED v1.0 - ASSEMBLY REFERENCE",
        "Long LED lead to +; short lead / flat side to -. Use conductive M3 washers.",
    )
    render_isometric(
        [(mesh, (174, 184, 194))],
        OUTPUT_DIR / f"{FILE_PREFIX}_Top_Preview.png",
        "SINGLE LED v1.0 - PRINTABLE MODULE",
        "Centered blind 5 mm LED holder; preserved M3 terminals, labels, and open Y tabs.",
    )

    rotation = trimesh.transformations.rotation_matrix(math.pi, [1.0, 0.0, 0.0])
    underside = mesh.copy()
    underside.apply_transform(rotation)
    support_overlay = trimesh.util.concatenate([item.copy() for item in supports])
    support_overlay.apply_transform(rotation)
    support_overlay.apply_translation([0.0, 0.0, 0.03])
    anchor_overlay = trimesh.util.concatenate([item.copy() for item in anchors])
    anchor_overlay.apply_transform(rotation)
    anchor_overlay.apply_translation([0.0, 0.0, 0.05])
    render_isometric(
        [
            (underside, (174, 184, 194)),
            (support_overlay, (93, 151, 105)),
            (anchor_overlay, (65, 116, 168)),
        ],
        OUTPUT_DIR / f"{FILE_PREFIX}_Underside_Preview.png",
        "SINGLE LED v1.0 - SUPPORTLESS UNDERSIDE",
        "Green = four solid roof supports; blue = four open, split-aligned Coupon-F anchors.",
        overlay_count=2,
    )


def write_validation(checks: dict[str, object]) -> None:
    (OUTPUT_DIR / "MESH_AND_CLEARANCE_VALIDATION.json").write_text(
        json.dumps(checks, indent=2) + "\n",
        encoding="utf-8",
    )
    nut = checks["m3_nut"]
    coupon = checks["m3_coupon"]
    lines = [
        "# Single-LED v1.0 mesh and clearance validation",
        "",
        f"- Watertight: `{checks['watertight']}`",
        f"- Winding consistent: `{checks['winding_consistent']}`",
        f"- Connected components: `{checks['components']}`",
        f"- Exported mesh extents: `{checks['extents_mm']} mm`",
        f"- Four dense solid-support disks reach the roof: `{checks['all_four_support_disks_solid_to_roof']}`",
        f"- Four Coupon-F centerlines open: `{checks['all_four_clutch_centerlines_open']}`",
        f"- Four C anchors present through Z=0.59: `{checks['anchor_material_present_through_z_0p59']}`",
        f"- C anchors end before Z=0.61: `{checks['anchor_material_ends_before_z_0p61']}`",
        f"- Four aligned anchor notches open: `{checks['all_four_anchor_notches_open']}`",
        f"- Fifteen LEGO seating points open: `{checks['all_15_body_lego_seating_points_open']}`",
        f"- Four tab continuation centers open: `{checks['four_tab_continuation_stud_centers_open']}`",
        f"- Both tab cavities and base portals open: `{checks['both_tab_cavities_and_base_portals_open']}`",
        f"- Both 3.4 x 1.8 mm brad slits open: `{checks['both_3p4x1p8_brad_slits_open']}`",
        f"- Both M3 screw axes open (dense): `{checks['both_m3_screw_axes_open_dense']}`",
        f"- Indexed 5.5 AF x 2.4 mm nut sweep volumes: `{nut['indexed_swept_collision_volume_mm3']} mm^3`",
        f"- Both indexed nut paths zero-collision: `{nut['indexed_sweeps_zero_collision']}`",
        f"- Rejected 30-degree control volumes: `{nut['rejected_control_collision_volume_mm3']} mm^3`",
        f"- Rejected control confirms keyed orientation: `{nut['rejected_control_confirms_keying']}`",
        f"- 5.25 mm LED pocket open from Z=7.34 to top: `{checks['led_pocket_open_from_z_7p34_to_top']}`",
        f"- Blind LED-pocket floor solid through Z=7.30: `{checks['led_pocket_blind_floor_solid_through_z_7p30']}`",
        f"- Both LED lead exits open toward terminals: `{checks['both_led_lead_exits_open_toward_terminals']}`",
        f"- LED pocket-to-support planar gap: `{checks['led_pocket_to_support_planar_gap_mm']} mm`",
        f"- LED pocket clears all four support disks: `{checks['led_pocket_clears_all_support_disks']}`",
        f"- M3 coupon watertight / one component: `{coupon['watertight']}` / `{coupon['components']}`",
        f"- M3 coupon indexed nut lanes open: `{coupon['all_nominal_indexed_nut_sweeps_open']}`",
        f"- M3 coupon screw bores open: `{coupon['all_three_screw_bores_open']}`",
        f"- Package embeds exact output files: `{checks.get('package_embeds_exact_files', False)}`",
        f"- All required automated checks pass: `{checks['all_required_checks_pass']}`",
        "",
        "All geometry checks use the exact STL artifacts after export and reload.",
        "A complete physical pilot remains required before classroom quantities.",
        "",
    ]
    (OUTPUT_DIR / "MESH_AND_CLEARANCE_VALIDATION.md").write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def package_files() -> list[str]:
    return [
        "README_FIRST.md",
        OUTPUT_STL_NAME,
        M3_COUPON_NAME,
        BRAD_COUPON_NAME,
        f"{FILE_PREFIX}_Dimensions.csv",
        "MESH_AND_CLEARANCE_VALIDATION.md",
        "MESH_AND_CLEARANCE_VALIDATION.json",
        f"{FILE_PREFIX}_Assembly_Preview.png",
        f"{FILE_PREFIX}_Top_Preview.png",
        f"{FILE_PREFIX}_Underside_Preview.png",
    ]


def create_package() -> None:
    with zipfile.ZipFile(
        OUTPUT_ZIP,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for name in package_files():
            archive.write(OUTPUT_DIR / name, f"{ARCHIVE_ROOT}/{name}")
        archive.write(
            Path(__file__),
            f"{ARCHIVE_ROOT}/SOURCE/{Path(__file__).name}",
        )


def package_embeds_exact_files() -> bool:
    with zipfile.ZipFile(OUTPUT_ZIP) as archive:
        return all(
            archive.read(f"{ARCHIVE_ROOT}/{name}") == (OUTPUT_DIR / name).read_bytes()
            for name in package_files()
        )


def main() -> None:
    for source in (SOURCE_BASE, LED_DONOR, BRAD_COUPON_SOURCE):
        if not source.exists():
            raise FileNotFoundError(source)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    (OUTPUT_DIR / BRAD_COUPON_NAME).write_bytes(BRAD_COUPON_SOURCE.read_bytes())

    source, led_donor, mesh, supports, anchors = build_module()
    m3_coupon = build_m3_coupon()
    checks = validate_module(source, led_donor, mesh)
    checks["m3_coupon"] = validate_m3_coupon(m3_coupon)
    checks["all_required_checks_pass"] = bool(
        checks["all_required_checks_pass"]
        and checks["m3_coupon"]["watertight"]
        and checks["m3_coupon"]["winding_consistent"]
        and checks["m3_coupon"]["components"] == 1
        and checks["m3_coupon"]["all_nominal_indexed_nut_sweeps_open"]
        and checks["m3_coupon"]["all_three_screw_bores_open"]
    )

    write_readme(mesh)
    write_dimensions(mesh)
    render_previews(mesh, supports, anchors)
    checks["package_embeds_exact_files"] = False
    write_validation(checks)
    create_package()
    checks["package_embeds_exact_files"] = package_embeds_exact_files()
    checks["all_required_checks_pass"] = bool(
        checks["all_required_checks_pass"] and checks["package_embeds_exact_files"]
    )
    write_validation(checks)
    create_package()

    final_exact = package_embeds_exact_files()
    if not checks["all_required_checks_pass"] or not final_exact:
        failed = [
            key
            for key, value in checks.items()
            if isinstance(value, bool) and not value
        ]
        raise SystemExit(
            "Single-LED v1.0 validation failed loudly: " + ", ".join(failed)
        )

    print(
        "single_led_v1_0|pass=True|"
        f"watertight={checks['watertight']}|components={checks['components']}|"
        f"supports={checks['solid_support_count']}|clutches={checks['open_coupon_f_bore_count']}|"
        f"m3_indexed_volumes={checks['m3_nut']['indexed_swept_collision_volume_mm3']}|"
        f"extents={checks['extents_mm']}|zip={OUTPUT_ZIP}"
    )


if __name__ == "__main__":
    main()

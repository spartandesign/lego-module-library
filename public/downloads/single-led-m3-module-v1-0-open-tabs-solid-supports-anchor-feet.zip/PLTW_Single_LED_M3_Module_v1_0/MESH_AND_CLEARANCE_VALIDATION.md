# Single-LED v1.0 mesh and clearance validation

- Watertight: `True`
- Winding consistent: `True`
- Connected components: `1`
- Exported mesh extents: `[39.96, 57.0, 10.12] mm`
- Four dense solid-support disks reach the roof: `True`
- Four Coupon-F centerlines open: `True`
- Four C anchors present through Z=0.59: `True`
- C anchors end before Z=0.61: `True`
- Four aligned anchor notches open: `True`
- Fifteen LEGO seating points open: `True`
- Four tab continuation centers open: `True`
- Both tab cavities and base portals open: `True`
- Both 3.4 x 1.8 mm brad slits open: `True`
- Both M3 screw axes open (dense): `True`
- Indexed 5.5 AF x 2.4 mm nut sweep volumes: `[0.0, 0.0] mm^3`
- Both indexed nut paths zero-collision: `True`
- Rejected 30-degree control volumes: `[4.513412, 4.765808] mm^3`
- Rejected control confirms keyed orientation: `True`
- 5.25 mm LED pocket open from Z=7.34 to top: `True`
- Blind LED-pocket floor solid through Z=7.30: `True`
- Both LED lead exits open toward terminals: `True`
- LED pocket-to-support planar gap: `0.432 mm`
- LED pocket clears all four support disks: `True`
- M3 coupon watertight / one component: `True` / `1`
- M3 coupon indexed nut lanes open: `True`
- M3 coupon screw bores open: `True`
- Package embeds exact output files: `True`
- All required automated checks pass: `True`

All geometry checks use the exact STL artifacts after export and reload.
A complete physical pilot remains required before classroom quantities.

# PLTW Single 5 mm LED M3 Module v1.0

This compact module holds one standard 5 mm LED and preserves the physically
confirmed compact resistor v2.8 mechanical scaffold. The complete LEGO
underside, Y-end cardboard tabs, X-end M3 nut tunnels, terminal axes, and raised
polarity marks are unchanged. Only the centered resistor cradle was shaved;
the proven center LED holder from the three-LED v2.6 module was rotated so its
two lead exits point toward the two terminals.

## Key geometry

- 5 x 3-stud / 40 x 24 mm nominal LEGO body
- Overall printable mesh: 39.96 x 57.00 x 10.12 mm
- One centered 5.25 mm blind LED pocket; the underside remains closed
- Four solid non-gripping roof supports
- Four open Coupon-F clutch bores with aligned 0.60 mm C anchor feet
- Two open Y-end cardboard tabs with 3.4 x 1.8 mm brass-fastener slits
- Two preserved side-loaded M3 terminals at X = -13 and +13 mm
- Raised `+` and `-` marks remain visible beside the terminals and away from
  the X-end nut openings

The calculated planar gap from the LED pocket to each solid support disk is
0.432 mm. Dense exported-mesh sampling confirms that the holder
and both lead exits do not trim the four support disks.

## M3 nut insertion

The nut tunnels are keyed. Use a standard nominal 5.5 mm-across-flats x 2.4 mm
M3 nut in the donor's indexed flat-aligned orientation (hex vertices on the X
axis in the model):

1. Insert the left nut from the left X end toward the `+` terminal.
2. Insert the right nut from the right X end toward the `-` terminal.
3. Keep each nut flat-aligned as it slides; do not rotate it 30 degrees.

Boolean swept-envelope validation of the exact reloaded STL reports zero
collision for both indexed paths. A 30-degree control orientation collides and
confirms that the passage is intentionally keyed.

## LED assembly

1. Test the included M3 and brass-fastener coupons first.
2. Insert the LED from the top into the blind pocket.
3. Aim the long anode lead toward the left `+` terminal (X = -13 mm).
4. Aim the short cathode / flat-side lead toward the right `-` terminal
   (X = +13 mm).
5. Bend each lead gently through its lead exit and beneath a conductive washer.
6. Install two M3 x 6 mm screws, nuts, and 9-12 mm washers. Tighten only enough
   to capture the LED leads without cutting them.

## Printing

- PLA, 0.4 mm nozzle, 0.20 mm Standard profile
- Four wall loops, 20% gyroid
- LEGO underside on the build plate
- Supports off; raft off
- Use a small outer brim if corner lifting occurs

## Coupon map

- Brass coupon: 3.2 / 3.4 / 3.6 mm fastener slits; use the 3.4 mm row first.
- M3 coupon: one dot = 5.60 mm AF clearance, two dots = 5.80 mm, three dots =
  6.00 mm. Test the one-dot lane first with the same flat-aligned orientation.

## Pilot status

Automated mesh, support, clutch, anchor, cardboard-path, LED-pocket, screw-axis,
and true swept-nut checks pass on the exact exported-and-reloaded STL. A physical
pilot with the classroom LEGO plate, LED, M3 hardware, cardboard, brass
fasteners, printer, and slicer is still required before classroom quantities.

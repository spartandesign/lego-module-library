from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path


CAD_DEPS = Path(r"C:\Users\trira\.codex\tmp\cad_pydeps")
sys.path.insert(0, str(CAD_DEPS))

import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont


OUTPUT_ROOT = Path(__file__).resolve().parent
LATEST_DIR = OUTPUT_ROOT.parent

BRAD_COUPON = (
    LATEST_DIR
    / "18_All_Modules_InternalBrad_3Dot_v0_1"
    / "STL"
    / "PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl"
)
SINGLE_DIR = LATEST_DIR / "34_Single_LED_v1_0_Supportless_DualMount"
THREE_DIR = LATEST_DIR / "35_Three_LED_v2_7_SolidRoofSupports"
BUZZER_DIR = (
    LATEST_DIR
    / "33_Buzzer_and_Servo_Supportless_Upgrades"
    / "buzzer_v2_2"
)
MICROBIT_DIR = LATEST_DIR / "31_Microbit_Stand_v5_4_InternalPaths_AnchorFeet"

SUPPORT_RADIUS = 2.60
SUPPORT_HEIGHT = 2.85
ANCHOR_HEIGHT = 0.60
OLD_BRAD_LENGTH = 3.40
NEW_BRAD_LENGTH = 3.60
BRAD_WIDTH = 1.80


@dataclass(frozen=True)
class M3Path:
    start: tuple[float, float]
    end: tuple[float, float]
    center_z: float
    indexed_angle_deg: float


@dataclass(frozen=True)
class ModuleConfig:
    key: str
    title: str
    version: str
    source_version: str
    source_stl: Path
    source_sha256: str
    output_stl_name: str
    output_zip_name: str
    archive_root: str
    file_prefix: str
    footprint: str
    tube_centers: tuple[tuple[float, float], ...]
    clutch_centers: tuple[tuple[float, float], ...]
    support_centers: tuple[tuple[float, float], ...]
    stud_centers: tuple[tuple[float, float], ...]
    brad_centers: tuple[tuple[float, float], ...]
    brad_axis: str
    brad_cut_z_max: float
    brad_kind: str
    tab_stud_centers: tuple[tuple[float, float], ...] = ()
    m3_paths: tuple[M3Path, ...] = ()
    m3_axes: tuple[tuple[float, float], ...] = ()
    led_centers: tuple[tuple[float, float], ...] = ()
    add_supports: bool = False
    correct_m3_paths: bool = False
    anchor_mode: str = "radial"
    anchor_notch_radius: float = 2.50
    extra_assets: tuple[tuple[Path, str], ...] = ()
    mechanism_note: str = ""

    @property
    def output_dir(self) -> Path:
        return OUTPUT_ROOT / self.key

    @property
    def output_stl(self) -> Path:
        return self.output_dir / self.output_stl_name

    @property
    def output_zip(self) -> Path:
        return self.output_dir / self.output_zip_name


def grid(
    xs: tuple[float, ...],
    ys: tuple[float, ...],
) -> tuple[tuple[float, float], ...]:
    return tuple((x, y) for x in xs for y in ys)


SMALL_TUBES = grid((-12.0, -4.0, 4.0, 12.0), (-4.0, 4.0))
SMALL_CLUTCH = tuple(
    (x, y) for x in (-12.0, 12.0) for y in (-4.0, 4.0)
)
SMALL_SUPPORTS = tuple(point for point in SMALL_TUBES if point not in SMALL_CLUTCH)
SMALL_STUDS = grid((-16.0, -8.0, 0.0, 8.0, 16.0), (-8.0, 0.0, 8.0))

THREE_CLUTCH = (
    (-20.0, -12.0),
    (-20.0, 12.0),
    (-4.0, -4.0),
    (4.0, 4.0),
    (20.0, -12.0),
    (20.0, 12.0),
)
THREE_TUBES = grid(
    (-20.0, -12.0, -4.0, 4.0, 12.0, 20.0),
    (-12.0, -4.0, 4.0, 12.0),
)
THREE_SUPPORTS = tuple(point for point in THREE_TUBES if point not in THREE_CLUTCH)
THREE_STUDS = grid(
    (-24.0, -16.0, -8.0, 0.0, 8.0, 16.0, 24.0),
    (-16.0, -8.0, 0.0, 8.0, 16.0),
)

MICROBIT_CLUTCH = (
    (-16.05, -32.00),
    (-16.05, 0.10),
    (-16.05, 31.90),
    (16.05, -32.00),
    (16.05, 0.10),
    (16.05, 31.90),
)
MICROBIT_TUBES = grid(
    (-16.0, -8.0, 0.0, 8.0, 16.0),
    (-32.0, -24.0, -16.0, -8.0, 0.0, 8.0, 16.0, 24.0, 32.0),
)
MICROBIT_SUPPORTS = tuple(
    (x, y)
    for x, y in MICROBIT_TUBES
    if not (
        abs(abs(x) - 16.0) < 0.2
        and min(abs(y + 32.0), abs(y), abs(y - 32.0)) < 0.2
    )
)
MICROBIT_STUDS = grid(
    (-20.0, -12.0, -4.0, 4.0, 12.0, 20.0),
    (-36.0, -28.0, -20.0, -12.0, -4.0, 4.0, 12.0, 20.0, 28.0, 36.0),
)


def x_loaded_paths(
    terminal_x: tuple[float, float],
    z: float,
) -> tuple[M3Path, ...]:
    return (
        M3Path((-21.0, 0.0), (terminal_x[0], 0.0), z, 0.0),
        M3Path((terminal_x[1], 0.0), (21.0, 0.0), z, 0.0),
    )


THREE_M3_PATHS = tuple(
    M3Path((x, -21.0), (x, -11.5), 5.75, 30.0)
    for x in (-16.0, 0.0, 16.0)
) + tuple(
    M3Path((x, 11.5), (x, 21.0), 5.75, 30.0)
    for x in (-16.0, 0.0, 16.0)
)


CONFIGS = (
    ModuleConfig(
        key="resistor_v2_9",
        title="PLTW Compact Resistor Terminal",
        version="v2.9",
        source_version="v2.8",
        source_stl=(
            LATEST_DIR
            / "23_Compact_Resistor_v2_8_Polarity_Labels"
            / "PLTW_Resistor_LEGO_Module_v2_8_FFit_DualMount_"
            "PolarityLabels_3p4x1p8.stl"
        ),
        source_sha256="712e076803391d023e0c9ea2169b8fbbea2832e8b1b0e14c97ae8b7b6e559e97",
        output_stl_name=(
            "PLTW_Resistor_LEGO_Module_v2_9_FFit_DualMount_"
            "PolarityLabels_3p6x1p8.stl"
        ),
        output_zip_name="compact-resistor-module-v2-9-dual-mount-polarity-3p6.zip",
        archive_root="PLTW_Compact_Resistor_Module_v2_9",
        file_prefix="PLTW_Resistor_v2_9",
        footprint="5 x 3 studs / 40 x 24 mm body; 57 mm across Y tabs",
        tube_centers=SMALL_TUBES,
        clutch_centers=SMALL_CLUTCH,
        support_centers=SMALL_SUPPORTS,
        stud_centers=SMALL_STUDS,
        brad_centers=((0.0, -20.0), (0.0, 20.0)),
        brad_axis="x",
        brad_cut_z_max=10.50,
        brad_kind="open Y-end tabs",
        tab_stud_centers=((0.0, -24.0), (0.0, -16.0), (0.0, 16.0), (0.0, 24.0)),
        m3_paths=x_loaded_paths((-13.0, 13.0), 5.52),
        m3_axes=((-13.0, 0.0), (13.0, 0.0)),
        anchor_mode="x_inward",
        anchor_notch_radius=2.25,
        mechanism_note=(
            "The physically fit-confirmed v2.8 base, resistor cradle, raised polarity marks, "
            "two indexed M3 tunnels, four solid supports, and four clutch anchors are unchanged."
        ),
    ),
    ModuleConfig(
        key="single_led_v1_1",
        title="PLTW Single-LED M3 Terminal Module",
        version="v1.1",
        source_version="v1.0",
        source_stl=(
            SINGLE_DIR
            / "PLTW_Single_LED_M3_Module_v1_0_FFit_DualMount_OpenBrickTabs_"
            "SolidRoofSupports_AnchoredCouponFFeet_3p4x1p8.stl"
        ),
        source_sha256="941f234fc099822121c5d4129b529c69cc4638fb6555cd14ff59a50878481fe4",
        output_stl_name=(
            "PLTW_Single_LED_M3_Module_v1_1_FFit_DualMount_OpenBrickTabs_"
            "SolidRoofSupports_AnchoredCouponFFeet_3p6x1p8.stl"
        ),
        output_zip_name=(
            "single-led-m3-module-v1-1-open-tabs-solid-supports-anchor-feet-3p6.zip"
        ),
        archive_root="PLTW_Single_LED_M3_Module_v1_1",
        file_prefix="PLTW_Single_LED_v1_1",
        footprint="5 x 3 studs / 40 x 24 mm body; 57 mm across Y tabs",
        tube_centers=SMALL_TUBES,
        clutch_centers=SMALL_CLUTCH,
        support_centers=SMALL_SUPPORTS,
        stud_centers=SMALL_STUDS,
        brad_centers=((0.0, -20.0), (0.0, 20.0)),
        brad_axis="x",
        brad_cut_z_max=10.50,
        brad_kind="open Y-end tabs",
        tab_stud_centers=((0.0, -24.0), (0.0, -16.0), (0.0, 16.0), (0.0, 24.0)),
        m3_paths=x_loaded_paths((-13.0, 13.0), 5.52),
        m3_axes=((-13.0, 0.0), (13.0, 0.0)),
        led_centers=((0.0, 0.0),),
        anchor_mode="x_inward",
        anchor_notch_radius=2.25,
        extra_assets=((SINGLE_DIR / "PLTW_Single_LED_M3_Nut_Path_Fit_Coupon.stl", "PLTW_Single_LED_M3_Nut_Path_Fit_Coupon.stl"),),
        mechanism_note=(
            "The v1.0 blind 5.25 mm LED pocket, two lead exits, polarity marks, "
            "indexed M3 tunnels, four solid supports, and four clutch anchors are unchanged."
        ),
    ),
    ModuleConfig(
        key="three_led_v2_8",
        title="PLTW Three-LED M3 Terminal Module",
        version="v2.8",
        source_version="v2.7",
        source_stl=(
            THREE_DIR
            / "PLTW_Three_LED_LEGO_Module_v2_7_FFit_DualMount_OpenBrickTabs_"
            "SolidRoofSupports_AnchoredCouponFFeet_3p4x1p8.stl"
        ),
        source_sha256="313fa5e0d4090a567adaa3de131057e2a8b613357fcb4b751baa63346aa52793",
        output_stl_name=(
            "PLTW_Three_LED_LEGO_Module_v2_8_FFit_DualMount_OpenBrickTabs_"
            "SolidRoofSupports_AnchoredCouponFFeet_3p6x1p8_ClearM3.stl"
        ),
        output_zip_name=(
            "three-led-m3-module-v2-8-open-tabs-solid-supports-anchor-feet-3p6.zip"
        ),
        archive_root="PLTW_Three_LED_M3_Module_v2_8",
        file_prefix="PLTW_Three_LED_v2_8",
        footprint="7 x 5 studs / 56 x 40 mm body; 89 mm across X tabs",
        tube_centers=THREE_TUBES,
        clutch_centers=THREE_CLUTCH,
        support_centers=THREE_SUPPORTS,
        stud_centers=THREE_STUDS,
        brad_centers=((-36.0, 0.0), (36.0, 0.0)),
        brad_axis="y",
        brad_cut_z_max=12.80,
        brad_kind="open X-end tabs",
        tab_stud_centers=((-40.0, 0.0), (-32.0, 0.0), (32.0, 0.0), (40.0, 0.0)),
        m3_paths=THREE_M3_PATHS,
        m3_axes=tuple((x, y) for x in (-16.0, 0.0, 16.0) for y in (-11.5, 11.5)),
        led_centers=((-16.0, 0.0), (0.0, 0.0), (16.0, 0.0)),
        correct_m3_paths=True,
        mechanism_note=(
            "The v2.7 LED holders, screw axes, polarity marks, 18 solid supports, six open "
            "clutch anchors, terminal top geometry, and open tabs are retained. Six nut tunnels "
            "receive only a localized indexed clearance cut below the terminal tops."
        ),
    ),
    ModuleConfig(
        key="buzzer_v2_3",
        title="PLTW 26SMDBZ1 Piezo Buzzer Module",
        version="v2.3",
        source_version="v2.2",
        source_stl=BUZZER_DIR / "PLTW_26SMDBZ1_Buzzer_v2_2_DualMount.stl",
        source_sha256="251fb070841c31f16f429da861f7afd4174d3d002345ce218b71155627066bcd",
        output_stl_name="PLTW_26SMDBZ1_Buzzer_v2_3_DualMount_3p6x1p8.stl",
        output_zip_name=(
            "piezo-buzzer-module-v2-3-open-tabs-solid-supports-anchor-feet-3p6.zip"
        ),
        archive_root="PLTW_Piezo_Buzzer_Module_v2_3",
        file_prefix="PLTW_Piezo_Buzzer_v2_3",
        footprint="5 x 3 studs / 40 x 24 mm body; 73 mm across X tabs",
        tube_centers=SMALL_TUBES,
        clutch_centers=SMALL_CLUTCH,
        support_centers=SMALL_SUPPORTS,
        stud_centers=SMALL_STUDS,
        brad_centers=((-28.0, 0.0), (28.0, 0.0)),
        brad_axis="y",
        brad_cut_z_max=12.30,
        brad_kind="open X-end tabs",
        tab_stud_centers=((-32.0, 0.0), (-24.0, 0.0), (24.0, 0.0), (32.0, 0.0)),
        m3_paths=(
            M3Path((-9.75, -13.0), (-9.75, 0.0), 6.60, 0.0),
            M3Path((9.75, 0.0), (9.75, 13.0), 6.60, 0.0),
        ),
        m3_axes=((-9.75, 0.0), (9.75, 0.0)),
        extra_assets=(
            (BUZZER_DIR / "PLTW_26SMDBZ1_Terminal_Spacing_Coupon_A19p0_B19p5_C20p0.stl", "PLTW_26SMDBZ1_Terminal_Spacing_Coupon_A19p0_B19p5_C20p0.stl"),
            (BUZZER_DIR / "PLTW_26SMDBZ1_M3_Nut_Trap_Fit_Coupon.stl", "PLTW_26SMDBZ1_M3_Nut_Trap_Fit_Coupon.stl"),
        ),
        mechanism_note=(
            "The v2.2 19.5 mm buzzer locator, two indexed M3 tunnels, four solid supports, "
            "four clutch anchors, and polarity geometry are unchanged."
        ),
    ),
    ModuleConfig(
        key="microbit_v5_5",
        title="PLTW micro:bit Original-Guide Stand",
        version="v5.5",
        source_version="v5.4",
        source_stl=(
            MICROBIT_DIR
            / "PLTW_Microbit_Stand_v5_4_InternalBrad_FFit_"
            "AnchoredCouponFFeet_3p4x1p8.stl"
        ),
        source_sha256="f447f4e8b4a41196685938174f76d9a450333b30674a7d9893522a2ef6778e4f",
        output_stl_name=(
            "PLTW_Microbit_Stand_v5_5_InternalBrad_FFit_SolidRoofSupports_"
            "AnchoredCouponFFeet_3p6x1p8.stl"
        ),
        output_zip_name=(
            "microbit-original-guide-stand-v5-5-solid-supports-internal-paths-"
            "anchor-feet-3p6.zip"
        ),
        archive_root="PLTW_Microbit_Original_Guide_Stand_v5_5",
        file_prefix="PLTW_Microbit_Stand_v5_5",
        footprint="6 x 10 studs / 48 x 80 mm nominal base",
        tube_centers=MICROBIT_TUBES,
        clutch_centers=MICROBIT_CLUTCH,
        support_centers=MICROBIT_SUPPORTS,
        stud_centers=MICROBIT_STUDS,
        brad_centers=((12.0, -12.0), (12.0, 12.0)),
        brad_axis="y",
        brad_cut_z_max=8.20,
        brad_kind="two top-open internal paths",
        add_supports=True,
        extra_assets=(
            (MICROBIT_DIR / "Microbit_Alligator_Clip_Guide_v2.stl", "Microbit_Alligator_Clip_Guide_v2.stl"),
            (MICROBIT_DIR / "THIRD_PARTY_ATTRIBUTION.md", "THIRD_PARTY_ATTRIBUTION.md"),
        ),
        mechanism_note=(
            "The exact-guide cradle and all upper stand geometry are retained. All 39 safe "
            "non-clutch centers become solid while six true clutch bores and their C anchors stay open."
        ),
    ),
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_mesh(path: Path) -> trimesh.Trimesh:
    loaded = trimesh.load(path, force="mesh", process=True)
    if isinstance(loaded, trimesh.Scene):
        loaded = loaded.to_geometry()
    if not isinstance(loaded, trimesh.Trimesh):
        raise TypeError(f"Expected mesh at {path}, got {type(loaded)!r}")
    loaded.remove_unreferenced_vertices()
    return loaded


def cylinder_at(
    x: float,
    y: float,
    radius: float,
    height: float,
    z0: float = 0.0,
    sections: int = 64,
) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    mesh.apply_translation([x, y, z0 + height / 2.0])
    return mesh


def capsule_cutter(
    center: tuple[float, float],
    axis: str,
    length: float,
    width: float,
    z_max: float,
) -> trimesh.Trimesh:
    radius = width / 2.0
    straight = length - width
    if straight <= 0.0:
        raise ValueError("Capsule length must exceed its width")
    height = z_max + 1.0
    middle_extents = (
        [straight, width, height]
        if axis == "x"
        else [width, straight, height]
    )
    middle = trimesh.creation.box(extents=middle_extents)
    middle.apply_translation([center[0], center[1], (z_max - 1.0) / 2.0])
    ends: list[trimesh.Trimesh] = []
    for sign in (-1.0, 1.0):
        x = center[0] + (sign * straight / 2.0 if axis == "x" else 0.0)
        y = center[1] + (sign * straight / 2.0 if axis == "y" else 0.0)
        ends.append(cylinder_at(x, y, radius, height, z0=-1.0, sections=64))
    return trimesh.boolean.union([middle, *ends], engine="manifold")


def hex_swept_envelope(
    path: M3Path,
    across_flats: float,
    thickness: float,
) -> trimesh.Trimesh:
    radius = across_flats / math.sqrt(3.0)
    angle = math.radians(path.indexed_angle_deg)
    hex_xy = tuple(
        (
            radius * math.cos(angle + index * math.pi / 3.0),
            radius * math.sin(angle + index * math.pi / 3.0),
        )
        for index in range(6)
    )
    points = np.asarray(
        [
            (center[0] + dx, center[1] + dy, path.center_z + dz)
            for center in (path.start, path.end)
            for dx, dy in hex_xy
            for dz in (-thickness / 2.0, thickness / 2.0)
        ]
    )
    return trimesh.convex.convex_hull(points)


def intersection_volume(a: trimesh.Trimesh, b: trimesh.Trimesh) -> float:
    overlap = trimesh.boolean.intersection([a, b], engine="manifold")
    if overlap is None or len(overlap.faces) == 0:
        return 0.0
    return abs(float(overlap.volume))


def export_and_reload(mesh: trimesh.Trimesh, path: Path) -> trimesh.Trimesh:
    mesh.remove_unreferenced_vertices()
    mesh.export(path)
    exported = load_mesh(path)
    # A few inherited micro:bit triangles collapse to collinear, zero-area
    # facets at binary-STL float32 precision.  They are nevertheless the
    # source model's topological closures: the raw reloaded STL is watertight,
    # consistently wound, and a single volume.  Deleting those facets opens
    # zero-width seams, so retain them whenever the exact reloaded artifact
    # already satisfies the required topology.  The cleanup branch remains a
    # fallback only for an artifact which actually reloads non-watertight.
    if exported.is_watertight and exported.is_winding_consistent:
        return exported
    nondegenerate = exported.nondegenerate_faces()
    if not bool(np.all(nondegenerate)):
        exported.update_faces(nondegenerate)
        exported.remove_unreferenced_vertices()
        exported.export(path)
        exported = load_mesh(path)
    return exported


def anchor_direction(config: ModuleConfig, x: float, y: float) -> tuple[float, float]:
    if config.anchor_mode == "x_inward":
        return ((1.0, 0.0) if x < 0.0 else (-1.0, 0.0))
    length = math.hypot(x, y)
    return (-x / length, -y / length)


def build_module(
    config: ModuleConfig,
) -> tuple[
    trimesh.Trimesh,
    trimesh.Trimesh,
    list[trimesh.Trimesh],
    list[trimesh.Trimesh],
    dict[str, float],
]:
    if sha256(config.source_stl).lower() != config.source_sha256.lower():
        raise RuntimeError(f"Source hash changed for {config.key}")
    source = load_mesh(config.source_stl)

    brad_cutters = [
        capsule_cutter(
            center,
            config.brad_axis,
            NEW_BRAD_LENGTH,
            BRAD_WIDTH,
            config.brad_cut_z_max,
        )
        for center in config.brad_centers
    ]
    after_brad = trimesh.boolean.difference([source, *brad_cutters], engine="manifold")
    brad_removed = max(0.0, float(source.volume - after_brad.volume))

    after_m3 = after_brad
    m3_removed = 0.0
    if config.correct_m3_paths:
        # A small documented manufacturing allowance ensures the required
        # nominal 5.50 AF x 2.40 mm envelope remains collision-free after STL
        # float32 export.  The indexed 30-degree orientation places opposing
        # flats across X and a vertex along the Y insertion direction.
        clearance_cutters = [
            hex_swept_envelope(path, 5.55, 2.45)
            for path in config.m3_paths
        ]
        after_m3 = trimesh.boolean.difference(
            [after_brad, *clearance_cutters],
            engine="manifold",
        )
        m3_removed = max(0.0, float(after_brad.volume - after_m3.volume))

    supports = [
        cylinder_at(x, y, SUPPORT_RADIUS, SUPPORT_HEIGHT, sections=64)
        for x, y in config.support_centers
    ]
    result = after_m3
    support_added = 0.0
    if config.add_supports:
        result = trimesh.boolean.union([after_m3, *supports], engine="manifold")
        support_added = max(0.0, float(result.volume - after_m3.volume))

    config.output_dir.mkdir(parents=True, exist_ok=True)
    exported = export_and_reload(result, config.output_stl)

    anchor_overlays = [
        trimesh.boolean.intersection(
            [source, cylinder_at(x, y, 3.05, ANCHOR_HEIGHT, sections=64)],
            engine="manifold",
        )
        for x, y in config.clutch_centers
    ]
    deltas = {
        "brad_capsule_removed_volume_mm3": round(brad_removed, 6),
        "m3_clearance_removed_volume_mm3": round(m3_removed, 6),
        "support_added_volume_mm3": round(support_added, 6),
        "net_volume_change_mm3": round(float(exported.volume - source.volume), 6),
    }
    return source, exported, supports, anchor_overlays, deltas


def contains(
    mesh: trimesh.Trimesh,
    points: list[tuple[float, float, float]],
) -> list[bool]:
    if not points:
        return []
    # Keep the dense micro:bit audit memory-bounded.  Trimesh's ray test can
    # otherwise allocate an intersections matrix proportional to both the
    # 333k-face stand and all ~8.6k support probes at once.
    result: list[bool] = []
    for start in range(0, len(points), 256):
        result.extend(
            bool(value)
            for value in mesh.contains(np.asarray(points[start : start + 256]))
        )
    return result


def support_probe_points(
    centers: tuple[tuple[float, float], ...],
) -> list[tuple[float, float, float]]:
    points: list[tuple[float, float, float]] = []
    for x, y in centers:
        for radius in (0.0, 1.25, 2.30, 2.50):
            angles = (0.0,) if radius == 0.0 else np.linspace(
                0.0, 2.0 * math.pi, 12, endpoint=False
            )
            points.extend(
                (
                    x + radius * math.cos(float(angle)),
                    y + radius * math.sin(float(angle)),
                    z,
                )
                for angle in angles
                for z in (0.05, 0.30, 1.40, 2.30, 2.79, 2.84)
            )
    return points


def stud_probe_points(
    centers: tuple[tuple[float, float], ...],
) -> list[tuple[float, float, float]]:
    offsets = (
        (0.0, 0.0),
        (2.20, 0.0),
        (-2.20, 0.0),
        (0.0, 2.20),
        (0.0, -2.20),
        (1.55, 1.55),
        (1.55, -1.55),
        (-1.55, 1.55),
        (-1.55, -1.55),
    )
    return [
        (x + dx, y + dy, z)
        for x, y in centers
        for dx, dy in offsets
        for z in (0.30, 1.40, 2.30)
    ]


def validate(
    config: ModuleConfig,
    source: trimesh.Trimesh,
    mesh: trimesh.Trimesh,
    deltas: dict[str, float],
) -> dict[str, object]:
    support_points = support_probe_points(config.support_centers)
    clutch_points = [
        (x, y, z)
        for x, y in config.clutch_centers
        for z in (0.05, 0.30, 0.59, 0.61, 1.40, 2.30)
    ]
    anchor_material: list[tuple[float, float, float]] = []
    anchor_above: list[tuple[float, float, float]] = []
    anchor_notches: list[tuple[float, float, float]] = []
    for x, y in config.clutch_centers:
        direction_x, direction_y = anchor_direction(config, x, y)
        perpendicular_x, perpendicular_y = -direction_y, direction_x
        material_xy = (
            (x - direction_x * 1.50, y - direction_y * 1.50),
            (x + perpendicular_x * 1.60, y + perpendicular_y * 1.60),
            (x - perpendicular_x * 1.60, y - perpendicular_y * 1.60),
        )
        for point_x, point_y in material_xy:
            anchor_material.extend(
                (point_x, point_y, z) for z in (0.05, 0.30, 0.59)
            )
            anchor_above.append((point_x, point_y, 0.61))
        for radius in (0.0, 0.75, 1.50, config.anchor_notch_radius):
            anchor_notches.extend(
                (
                    x + direction_x * radius,
                    y + direction_y * radius,
                    z,
                )
                for z in (0.05, 0.30, 0.59)
            )

    brad_collision_volumes = [
        intersection_volume(
            mesh,
            capsule_cutter(
                center,
                config.brad_axis,
                NEW_BRAD_LENGTH,
                BRAD_WIDTH,
                config.brad_cut_z_max,
            ),
        )
        for center in config.brad_centers
    ]

    m3_collision_volumes = [
        intersection_volume(mesh, hex_swept_envelope(path, 5.50, 2.40))
        for path in config.m3_paths
    ]
    m3_control_volumes: list[float] = []
    if config.correct_m3_paths:
        m3_control_volumes = [
            intersection_volume(
                mesh,
                hex_swept_envelope(
                    M3Path(path.start, path.end, path.center_z, 0.0),
                    5.50,
                    2.40,
                ),
            )
            for path in config.m3_paths
        ]

    screw_points: list[tuple[float, float, float]] = []
    for x, y in config.m3_axes:
        for radius in (0.0, 0.70, 1.35):
            angles = (0.0,) if radius == 0.0 else np.linspace(
                0.0, 2.0 * math.pi, 12, endpoint=False
            )
            screw_points.extend(
                (
                    x + radius * math.cos(float(angle)),
                    y + radius * math.sin(float(angle)),
                    z,
                )
                for angle in angles
                for z in (3.50, 5.75, 8.00, 9.50)
            )

    led_points: list[tuple[float, float, float]] = []
    for x, y in config.led_centers:
        for radius in (0.0, 1.25, 2.50, 2.55):
            angles = (0.0,) if radius == 0.0 else np.linspace(
                0.0, 2.0 * math.pi, 16, endpoint=False
            )
            led_points.extend(
                (
                    x + radius * math.cos(float(angle)),
                    y + radius * math.sin(float(angle)),
                    z,
                )
                for angle in angles
                for z in (
                    (7.34, 8.50, 9.50, 10.00)
                    if config.key == "single_led_v1_1"
                    else (10.00, 11.00, 12.00)
                )
            )

    checks: dict[str, object] = {
        "watertight": bool(mesh.is_watertight),
        "winding_consistent": bool(mesh.is_winding_consistent),
        "components": len(mesh.split(only_watertight=False)),
        "faces": int(len(mesh.faces)),
        "bounds_mm": [[round(float(value), 3) for value in row] for row in mesh.bounds],
        "extents_mm": [round(float(value), 3) for value in mesh.extents],
        "source_extents_mm": [round(float(value), 3) for value in source.extents],
        "source_sha256": sha256(config.source_stl),
        "output_stl_sha256": sha256(config.output_stl),
        "source_version": config.source_version,
        "source_hash_matches_exact_current_artifact": sha256(config.source_stl).lower() == config.source_sha256.lower(),
        "source_extents_preserved": bool(np.allclose(mesh.extents, source.extents, atol=1e-5)),
        "deltas": deltas,
        "localization": {
            "brad_change": "Only the final 0.10 mm at each end of each 3.4 mm capsule is newly removed; width remains 1.8 mm.",
            "brad_centers_mm": [list(center) for center in config.brad_centers],
            "brad_axis": config.brad_axis,
            "m3_change": (
                "Six 5.55 mm AF x 2.45 mm indexed swept clearance cuts, confined to Z=4.525..6.975 mm."
                if config.correct_m3_paths
                else "None."
            ),
            "support_change": (
                "Thirty-nine full diameter 5.20 x 2.85 mm posts at non-clutch centers."
                if config.add_supports
                else "None. Existing solid supports retained."
            ),
        },
        "support_count": len(config.support_centers),
        "support_diameter_mm": 5.20,
        "support_height_mm": 2.85,
        "dense_support_samples": len(support_points),
        "all_safe_support_disks_solid_to_roof": all(contains(mesh, support_points)),
        "clutch_count": len(config.clutch_centers),
        "all_coupon_f_centerlines_open": not any(contains(mesh, clutch_points)),
        "anchor_material_present_through_z_0p59": all(contains(mesh, anchor_material)),
        "anchor_material_ends_before_z_0p61": not any(contains(mesh, anchor_above)),
        "all_anchor_notches_open": not any(contains(mesh, anchor_notches)),
        "lego_stud_clearance_count": len(config.stud_centers),
        "all_lego_stud_clearances_open_dense": not any(
            contains(mesh, stud_probe_points(config.stud_centers))
        ),
        "tab_continuation_count": len(config.tab_stud_centers),
        "all_tab_continuation_clearances_open_dense": not any(
            contains(mesh, stud_probe_points(config.tab_stud_centers))
        ) if config.tab_stud_centers else True,
        "brad_slit_mm": [NEW_BRAD_LENGTH, BRAD_WIDTH],
        "brad_path_count": len(config.brad_centers),
        "brad_nominal_collision_volume_mm3": [round(value, 9) for value in brad_collision_volumes],
        "all_3p6x1p8_brad_paths_open": all(value <= 1e-7 for value in brad_collision_volumes),
        "m3_path_count": len(config.m3_paths),
        "m3_nominal_envelope_mm": [5.50, 2.40],
        "m3_indexed_angles_deg": [path.indexed_angle_deg for path in config.m3_paths],
        "m3_nominal_collision_volume_mm3": [round(value, 9) for value in m3_collision_volumes],
        "all_required_m3_sweeps_zero_collision": all(value <= 1e-7 for value in m3_collision_volumes),
        "m3_zero_degree_control_collision_volume_mm3": [round(value, 6) for value in m3_control_volumes],
        "all_m3_screw_axes_open_dense": not any(contains(mesh, screw_points)),
        "led_pocket_count": len(config.led_centers),
        "all_led_pockets_open_dense": not any(contains(mesh, led_points)),
        "exact_upper_mechanism_retained_by_local_construction": True,
    }

    # micro:bit internal-path floors must remain solid outside the widened slit.
    if config.key == "microbit_v5_5":
        floor_points = [
            (x + dx, y + dy, 5.00)
            for x, y in config.brad_centers
            for dx, dy in ((3.0, 0.0), (0.0, 3.0))
        ]
        head_points = [
            (x + dx, y + dy, z)
            for x, y in config.brad_centers
            for dx, dy in ((0.0, 0.0), (3.0, 0.0), (0.0, 3.0))
            for z in (5.50, 7.90)
        ]
        checks["both_internal_head_pockets_open"] = not any(contains(mesh, head_points))
        checks["solid_floor_retained_around_internal_slits"] = all(contains(mesh, floor_points))
    else:
        checks["both_internal_head_pockets_open"] = True
        checks["solid_floor_retained_around_internal_slits"] = True

    checks["all_required_checks_pass"] = bool(
        checks["watertight"]
        and checks["winding_consistent"]
        and checks["components"] == 1
        and checks["source_hash_matches_exact_current_artifact"]
        and checks["source_extents_preserved"]
        and checks["all_safe_support_disks_solid_to_roof"]
        and checks["all_coupon_f_centerlines_open"]
        and checks["anchor_material_present_through_z_0p59"]
        and checks["anchor_material_ends_before_z_0p61"]
        and checks["all_anchor_notches_open"]
        and checks["all_lego_stud_clearances_open_dense"]
        and checks["all_tab_continuation_clearances_open_dense"]
        and checks["all_3p6x1p8_brad_paths_open"]
        and checks["all_required_m3_sweeps_zero_collision"]
        and checks["all_m3_screw_axes_open_dense"]
        and checks["all_led_pockets_open_dense"]
        and checks["both_internal_head_pockets_open"]
        and checks["solid_floor_retained_around_internal_slits"]
    )
    return checks


def copy_assets(config: ModuleConfig) -> tuple[str, ...]:
    assets = [(BRAD_COUPON, BRAD_COUPON.name), *config.extra_assets]
    names: list[str] = []
    for source, name in assets:
        if not source.exists():
            raise FileNotFoundError(source)
        (config.output_dir / name).write_bytes(source.read_bytes())
        names.append(name)
    return tuple(names)


def write_readme(config: ModuleConfig, mesh: trimesh.Trimesh, deltas: dict[str, float]) -> None:
    m3_section = (
        "- M3 hardware: N/A for this stand.\n"
        if not config.m3_paths
        else (
            f"- {len(config.m3_paths)} indexed M3 nut paths retain zero collision for a "
            "nominal 5.50 mm-AF x 2.40 mm nut envelope.\n"
        )
    )
    led_section = (
        "- LED pockets: N/A.\n"
        if not config.led_centers
        else f"- {len(config.led_centers)} preserved 5.25 mm LED pocket(s).\n"
    )
    special = ""
    if config.correct_m3_paths:
        special += """
## Three-LED indexed nut correction

The intended insertion orientation is 30 degrees in model XY: opposing nut
flats span X and a hex vertex points along each Y loading direction. Six
clearance cutters measure 5.55 mm across flats x 2.45 mm thick, giving the
required nominal 5.50 x 2.40 mm envelope a small export-safe allowance. The
cuts are confined to Z=4.525..6.975 mm and do not reach the terminal tops,
screw axes, polarity labels, LED holders, or underside.

The exact removed volume is reported in the validation JSON. No claim is made
for arbitrary nut rotation; insert all six nuts in the documented indexed
orientation.
"""
    if config.add_supports:
        special += """
## micro:bit roof-support correction

All 39 non-clutch tube centers now receive full 5.20 mm-diameter x 2.85 mm
solid posts. The six true Coupon-F bores and their C anchors remain open. The
two widened internal paths remain top-open, all 60 LEGO stud clearances remain
open, and the exact-guide cradle and attributed guide STL are unchanged.
"""
    text = f"""# {config.title} {config.version}

This package starts from the exact current {config.source_version} STL and
changes the classroom brass-fastener capsule from 3.4 x 1.8 mm to
3.6 x 1.8 mm. Use the **3.6 mm row** of the included 3.2 / 3.4 / 3.6 mm coupon
before printing classroom quantities.

## What changed

- Both existing cardboard capsules are lengthened by 0.20 mm total: only
  0.10 mm of material is removed at each end; width stays 1.80 mm.
- Cardboard mount style remains {config.brad_kind}.
- Source extents and all unrelated geometry are preserved.
- Actual brad-only removed volume: {deltas['brad_capsule_removed_volume_mm3']:.6f} mm^3.
- M3-clearance removed volume: {deltas['m3_clearance_removed_volume_mm3']:.6f} mm^3.
- Added solid-support volume: {deltas['support_added_volume_mm3']:.6f} mm^3.

{config.mechanism_note}

## Retained standards

- Footprint: {config.footprint}
- Overall exported extents: {mesh.extents[0]:.2f} x {mesh.extents[1]:.2f} x {mesh.extents[2]:.2f} mm
- {len(config.support_centers)} full 5.20 mm-diameter x 2.85 mm safe roof supports
- {len(config.clutch_centers)} open Coupon-F bores with aligned 0.60 mm C anchors
{m3_section}{led_section}{special}
## Printing and assembly

- PLA, 0.4 mm nozzle, 0.20 mm Standard profile
- LEGO underside on the build plate
- Supports off; raft off
- Print and test the 3.6 mm coupon row first
- Confirm LEGO seating, removal, cardboard fit, both fasteners, and the complete
  electrical/mechanical assembly before classroom quantities

Automated checks use the exact STL after export and reload. They do not replace
a physical pilot with the classroom printer, plate, hardware, and cardboard.
"""
    (config.output_dir / "README_FIRST.md").write_text(text, encoding="utf-8")


def write_dimensions(config: ModuleConfig, mesh: trimesh.Trimesh, deltas: dict[str, float]) -> None:
    rows = [
        ("Feature", "Value"),
        ("Module", f"{config.title} {config.version}"),
        ("Source artifact", f"Exact current {config.source_version}; SHA-256 {config.source_sha256}"),
        ("Footprint", config.footprint),
        ("Overall extents", " x ".join(f"{value:.2f}" for value in mesh.extents) + " mm"),
        ("Cardboard mount", config.brad_kind),
        ("Brass-fastener capsule", "3.60 x 1.80 mm"),
        ("Recommended coupon row", "3.6 mm"),
        ("Brad centers", "; ".join(f"({x:.2f}, {y:.2f})" for x, y in config.brad_centers)),
        ("Solid roof supports", f"{len(config.support_centers)} at 5.20 x 2.85 mm"),
        ("Open Coupon-F bores / C anchors", str(len(config.clutch_centers))),
        ("M3 nut paths", str(len(config.m3_paths)) if config.m3_paths else "N/A"),
        ("M3 nominal envelope", "5.50 mm AF x 2.40 mm" if config.m3_paths else "N/A"),
        ("LED pockets", str(len(config.led_centers)) if config.led_centers else "N/A"),
        ("Brad removed volume", f"{deltas['brad_capsule_removed_volume_mm3']:.6f} mm^3"),
        ("M3 removed volume", f"{deltas['m3_clearance_removed_volume_mm3']:.6f} mm^3"),
        ("Support added volume", f"{deltas['support_added_volume_mm3']:.6f} mm^3"),
    ]
    with (config.output_dir / f"{config.file_prefix}_Dimensions.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        csv.writer(handle).writerows(rows)


def render_isometric(
    specs: list[tuple[trimesh.Trimesh, tuple[int, int, int]]],
    path: Path,
    title: str,
    footer: str,
    overlay_count: int = 0,
) -> None:
    view = np.array([1.0, -1.35, 0.90])
    view /= np.linalg.norm(view)
    right = np.cross(view, np.array([0.0, 0.0, 1.0]))
    right /= np.linalg.norm(right)
    up = np.cross(right, view)
    up /= np.linalg.norm(up)
    light = np.array([0.30, -0.45, 0.84])
    light /= np.linalg.norm(light)
    triangles: list[tuple[float, np.ndarray, tuple[int, int, int]]] = []
    overlays: list[tuple[float, np.ndarray, tuple[int, int, int]]] = []
    projected_all: list[np.ndarray] = []
    overlay_start = len(specs) - overlay_count
    for index, (mesh, color) in enumerate(specs):
        tri3 = mesh.vertices[mesh.faces]
        normals = np.cross(tri3[:, 1] - tri3[:, 0], tri3[:, 2] - tri3[:, 0])
        lengths = np.linalg.norm(normals, axis=1)
        valid = lengths > 1e-9
        normals[valid] /= lengths[valid, None]
        facing = normals @ view > -0.10
        for triangle, normal in zip(tri3[facing], normals[facing]):
            projected = np.column_stack((triangle @ right, -(triangle @ up)))
            depth = float(np.mean(triangle @ view))
            shade = 0.70 + 0.30 * max(0.0, float(normal @ light))
            shaded = tuple(max(0, min(255, int(channel * shade))) for channel in color)
            target = overlays if overlay_count and index >= overlay_start else triangles
            target.append((depth, projected, shaded))
            projected_all.append(projected)
    all_points = np.vstack(projected_all)
    low = all_points.min(axis=0)
    high = all_points.max(axis=0)
    canvas = (1500, 1000)
    margin = 110
    scale = min(
        (canvas[0] - 2 * margin) / (high[0] - low[0]),
        (canvas[1] - 2 * margin - 100) / (high[1] - low[1]),
    )
    offset = np.array(
        [
            (canvas[0] - (high[0] - low[0]) * scale) / 2.0 - low[0] * scale,
            100.0 + (canvas[1] - 175 - (high[1] - low[1]) * scale) / 2.0 - low[1] * scale,
        ]
    )
    image = Image.new("RGB", canvas, (247, 249, 252))
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    draw.text((45, 28), title, fill=(30, 40, 54), font=font)
    for collection in (triangles, overlays):
        for _depth, projected, color in sorted(collection, key=lambda item: item[0]):
            points = [
                (float(x * scale + offset[0]), float(y * scale + offset[1]))
                for x, y in projected
            ]
            draw.polygon(points, fill=color)
    draw.text((45, 955), footer, fill=(30, 40, 54), font=font)
    image.save(path)


def assembly_proxy(config: ModuleConfig) -> trimesh.Trimesh:
    parts: list[trimesh.Trimesh] = []
    if config.led_centers:
        z0 = 7.55 if config.key == "single_led_v1_1" else 9.65
        for x, y in config.led_centers:
            body = cylinder_at(x, y, 2.45, 5.4, z0=z0, sections=48)
            dome = trimesh.creation.uv_sphere(radius=2.45, count=[30, 15])
            dome.apply_translation([x, y, z0 + 5.4])
            parts.extend([body, dome])
    elif config.key == "resistor_v2_9":
        resistor = trimesh.creation.box(extents=[10.0, 3.2, 3.2])
        resistor.apply_translation([0.0, 0.0, 10.5])
        parts.append(resistor)
    elif config.key == "buzzer_v2_3":
        board = trimesh.creation.box(extents=[24.8, 11.0, 1.0])
        board.apply_translation([0.0, 0.0, 12.3])
        body = trimesh.creation.box(extents=[10.6, 10.0, 5.1])
        body.apply_translation([0.0, 0.0, 15.35])
        parts.extend([board, body])
    else:
        guide = trimesh.creation.box(extents=[5.85, 56.0, 11.2])
        guide.apply_translation([0.0, 0.0, 39.0])
        parts.append(guide)
    return trimesh.util.concatenate(parts)


def render_previews(
    config: ModuleConfig,
    mesh: trimesh.Trimesh,
    supports: list[trimesh.Trimesh],
    anchors: list[trimesh.Trimesh],
) -> None:
    render_isometric(
        [(mesh, (174, 184, 194)), (assembly_proxy(config), (55, 122, 96))],
        config.output_dir / f"{config.file_prefix}_Assembly_Preview.png",
        f"{config.title.upper()} {config.version} - ASSEMBLY",
        "Revised 3.6 mm cardboard path; component and mechanism geometry retained.",
    )
    render_isometric(
        [(mesh, (174, 184, 194))],
        config.output_dir / f"{config.file_prefix}_Top_Preview.png",
        f"{config.title.upper()} {config.version} - PRINTABLE MODULE",
        "Use the 3.6 mm row of the included brass-fastener coupon first.",
    )
    rotation = trimesh.transformations.rotation_matrix(math.pi, [1.0, 0.0, 0.0])
    underside = mesh.copy()
    underside.apply_transform(rotation)
    support_overlay = trimesh.util.concatenate([item.copy() for item in supports])
    support_overlay.apply_transform(rotation)
    support_overlay.apply_translation([0.0, 0.0, 0.03])
    anchor_overlay = trimesh.util.concatenate([item.copy() for item in anchors])
    anchor_overlay.apply_transform(rotation)
    anchor_overlay.apply_translation([0.0, 0.0, 0.05])
    render_isometric(
        [
            (underside, (174, 184, 194)),
            (support_overlay, (93, 151, 105)),
            (anchor_overlay, (65, 116, 168)),
        ],
        config.output_dir / f"{config.file_prefix}_Underside_Preview.png",
        f"{config.title.upper()} {config.version} - UNDERSIDE",
        f"Green = {len(supports)} solid supports; blue = {len(anchors)} open clutch C anchors.",
        overlay_count=2,
    )


def write_validation(config: ModuleConfig, checks: dict[str, object]) -> None:
    (config.output_dir / "MESH_AND_CLEARANCE_VALIDATION.json").write_text(
        json.dumps(checks, indent=2) + "\n", encoding="utf-8"
    )
    lines = [
        f"# {config.title} {config.version} validation",
        "",
        f"- Exact source hash matched: `{checks['source_hash_matches_exact_current_artifact']}`",
        f"- Watertight: `{checks['watertight']}`",
        f"- Winding consistent: `{checks['winding_consistent']}`",
        f"- Connected components: `{checks['components']}`",
        f"- Source extents preserved: `{checks['source_extents_preserved']}`",
        f"- Solid supports: `{checks['support_count']}` at 5.20 x 2.85 mm",
        f"- All support disks solid: `{checks['all_safe_support_disks_solid_to_roof']}`",
        f"- Open Coupon-F bores / anchors: `{checks['clutch_count']}`",
        f"- All clutch centerlines open: `{checks['all_coupon_f_centerlines_open']}`",
        f"- Anchor material through Z=0.59: `{checks['anchor_material_present_through_z_0p59']}`",
        f"- Anchor material ends before Z=0.61: `{checks['anchor_material_ends_before_z_0p61']}`",
        f"- Anchor notches open: `{checks['all_anchor_notches_open']}`",
        f"- LEGO stud clearances open: `{checks['all_lego_stud_clearances_open_dense']}`",
        f"- 3.6 x 1.8 mm brad collision volumes: `{checks['brad_nominal_collision_volume_mm3']} mm^3`",
        f"- Both 3.6 x 1.8 mm paths open: `{checks['all_3p6x1p8_brad_paths_open']}`",
        f"- Nominal M3 collision volumes: `{checks['m3_nominal_collision_volume_mm3']} mm^3`",
        f"- Required M3 sweeps zero-collision: `{checks['all_required_m3_sweeps_zero_collision']}`",
        f"- M3 screw axes open: `{checks['all_m3_screw_axes_open_dense']}`",
        f"- LED pockets open: `{checks['all_led_pockets_open_dense']}`",
        f"- Internal head pockets open: `{checks['both_internal_head_pockets_open']}`",
        f"- Internal floor retained: `{checks['solid_floor_retained_around_internal_slits']}`",
        f"- Change deltas: `{checks['deltas']}`",
        f"- Package embeds exact files: `{checks.get('package_embeds_exact_files', False)}`",
        f"- All required checks pass: `{checks['all_required_checks_pass']}`",
        "",
        "All geometry checks use the exact STL after export and reload.",
        "A physical 3.6 mm coupon and complete module pilot remain required.",
        "",
    ]
    (config.output_dir / "MESH_AND_CLEARANCE_VALIDATION.md").write_text(
        "\n".join(lines), encoding="utf-8"
    )


def package_names(config: ModuleConfig, assets: tuple[str, ...]) -> list[str]:
    return [
        "README_FIRST.md",
        config.output_stl_name,
        *assets,
        f"{config.file_prefix}_Dimensions.csv",
        "MESH_AND_CLEARANCE_VALIDATION.md",
        "MESH_AND_CLEARANCE_VALIDATION.json",
        f"{config.file_prefix}_Assembly_Preview.png",
        f"{config.file_prefix}_Top_Preview.png",
        f"{config.file_prefix}_Underside_Preview.png",
    ]


def create_package(config: ModuleConfig, assets: tuple[str, ...]) -> None:
    with zipfile.ZipFile(
        config.output_zip,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for name in package_names(config, assets):
            archive.write(config.output_dir / name, f"{config.archive_root}/{name}")
        archive.write(Path(__file__), f"{config.archive_root}/SOURCE/{Path(__file__).name}")


def package_embeds_exact_files(config: ModuleConfig, assets: tuple[str, ...]) -> bool:
    with zipfile.ZipFile(config.output_zip) as archive:
        return all(
            archive.read(f"{config.archive_root}/{name}") == (config.output_dir / name).read_bytes()
            for name in package_names(config, assets)
        )


def main() -> None:
    if not BRAD_COUPON.exists():
        raise FileNotFoundError(BRAD_COUPON)
    all_pass = True
    for config in CONFIGS:
        config.output_dir.mkdir(parents=True, exist_ok=True)
        assets = copy_assets(config)
        source, mesh, supports, anchors, deltas = build_module(config)
        checks = validate(config, source, mesh, deltas)
        write_readme(config, mesh, deltas)
        write_dimensions(config, mesh, deltas)
        render_previews(config, mesh, supports, anchors)
        checks["package_embeds_exact_files"] = False
        write_validation(config, checks)
        create_package(config, assets)
        checks["package_embeds_exact_files"] = package_embeds_exact_files(config, assets)
        checks["all_required_checks_pass"] = bool(
            checks["all_required_checks_pass"] and checks["package_embeds_exact_files"]
        )
        write_validation(config, checks)
        create_package(config, assets)
        passed = bool(
            checks["all_required_checks_pass"]
            and package_embeds_exact_files(config, assets)
        )
        all_pass = all_pass and passed
        print(
            f"{config.key}|pass={passed}|watertight={checks['watertight']}|"
            f"components={checks['components']}|supports={checks['support_count']}|"
            f"clutches={checks['clutch_count']}|brad={checks['brad_nominal_collision_volume_mm3']}|"
            f"m3={checks['m3_nominal_collision_volume_mm3']}|zip={config.output_zip}",
            flush=True,
        )
    if not all_pass:
        raise SystemExit("One or more circuit/micro:bit 3.6 upgrades failed validation")


if __name__ == "__main__":
    main()

from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import shutil
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


CAD_DEPS = Path(r"C:\Users\trira\.codex\tmp\cad_pydeps")
sys.path.insert(0, str(CAD_DEPS))

import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont


OUTPUT_ROOT = Path(__file__).resolve().parent
DOWNLOADS = Path(r"C:\dev\pltw-lego-module-library\public\downloads")
COUPON_SOURCE = (
    OUTPUT_ROOT.parent
    / "18_All_Modules_InternalBrad_3Dot_v0_1"
    / "STL"
    / "PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl"
)
COUPON_NAME = COUPON_SOURCE.name

SUPPORT_RADIUS = 2.60
SUPPORT_HEIGHT = 2.85
ANCHOR_RADIUS = 3.00
ANCHOR_HEIGHT = 0.60
ANCHOR_NOTCH_WIDTH = 1.55
ANCHOR_NOTCH_LENGTH = 4.20
BRAD_LONG = 3.60
BRAD_WIDTH = 1.80
DELTA_KERNEL_ENVELOPE = 0.35


@dataclass(frozen=True)
class NutPath:
    start: tuple[float, float]
    end: tuple[float, float]
    z_center: float
    transverse: tuple[float, float]
    half_width: float = 2.20
    half_height: float = 0.90


@dataclass(frozen=True)
class ScrewBore:
    center: tuple[float, float]
    zs: tuple[float, ...]


@dataclass(frozen=True)
class ModelSpec:
    key: str
    display_name: str
    source_zip_name: str
    source_member: str
    output_stl_name: str
    tube_grid: tuple[tuple[float, float], ...]
    clutch_centers: tuple[tuple[float, float], ...]
    body_stud_centers: tuple[tuple[float, float], ...]
    tab_stud_centers: tuple[tuple[float, float], ...]
    roof_start_z: float
    anchor_direction: str
    brad_centers: tuple[tuple[float, float], ...]
    brad_axis: str
    screw_bores: tuple[ScrewBore, ...]
    nut_paths: tuple[NutPath, ...]
    nut_index_angle_deg: float | None = None
    expected_m3_clearance_cuts: int = 0
    supports_already_present: bool = False
    anchors_already_present: bool = False
    special_void_points: tuple[tuple[float, float, float], ...] = ()

    @property
    def support_centers(self) -> tuple[tuple[float, float], ...]:
        clutch = set(self.clutch_centers)
        return tuple(point for point in self.tube_grid if point not in clutch)


@dataclass(frozen=True)
class PackageSpec:
    key: str
    display_name: str
    version: str
    directory_name: str
    archive_root: str
    zip_name: str
    dimensions_name: str
    models: tuple[ModelSpec, ...]
    extra_members: tuple[str, ...]
    mount_description: str
    hardware_description: str
    mechanism_description: str
    expected_supports: int
    expected_clutches: int


def grid(xs: Iterable[float], ys: Iterable[float]) -> tuple[tuple[float, float], ...]:
    return tuple((float(x), float(y)) for x in xs for y in ys)


PADDLE = ModelSpec(
    key="flex_paddle",
    display_name="PLTW Flex Paddle Module v3.5",
    source_zip_name="flex-paddle-module-v3-4-dual-mount-3p4.zip",
    source_member=(
        "CARDBOARD_MOUNT_CONFIRMED_3P4/"
        "PLTW_Flex_Module_v3_4_FFit_DualMount_3p4x1p8.stl"
    ),
    output_stl_name=(
        "PLTW_Flex_Module_v3_5_FFit_DualMount_SolidRoofSupports_"
        "AnchoredCouponFFeet_3p6x1p8.stl"
    ),
    tube_grid=grid(range(-44, 45, 8), (-8, 0, 8)),
    clutch_centers=tuple(
        (float(x), float(y)) for x in (-44, 4, 44) for y in (-8, 8)
    ),
    body_stud_centers=grid(range(-48, 49, 8), (-12, -4, 4, 12)),
    tab_stud_centers=(),
    roof_start_z=2.31,
    anchor_direction="inward",
    brad_centers=((-8.0, -4.0), (8.0, -4.0)),
    brad_axis="Y",
    screw_bores=(
        ScrewBore((-37.5, -8.1), (3.10, 4.00, 5.15, 6.45)),
        ScrewBore((-37.5, 8.1), (3.10, 4.00, 5.15, 6.45)),
    ),
    nut_paths=(
        NutPath((-37.5, -15.50), (-37.5, -8.10), 5.15, (1.0, 0.0)),
        NutPath((-37.5, 15.50), (-37.5, 8.10), 5.15, (1.0, 0.0)),
    ),
    nut_index_angle_deg=0.0,
    expected_m3_clearance_cuts=2,
)

DOOR = ModelSpec(
    key="flex_door",
    display_name="PLTW Flex Door / Flap Module v1.8",
    source_zip_name="flex-door-flap-module-v1-7-dual-mount-3p4.zip",
    source_member=(
        "CARDBOARD_MOUNT_CONFIRMED_3P4/"
        "PLTW_Flex_Door_v1_7_FFit_DualMount_3p4x1p8.stl"
    ),
    output_stl_name=(
        "PLTW_Flex_Door_v1_8_FFit_DualMount_SolidRoofSupports_"
        "AnchoredCouponFFeet_3p6x1p8.stl"
    ),
    tube_grid=grid(range(-24, 25, 8), range(-16, 17, 8)),
    clutch_centers=tuple(
        (float(x), float(y)) for x in (-24, -8, 24) for y in (-16, 16)
    ),
    body_stud_centers=grid(range(-28, 29, 8), range(-20, 21, 8)),
    tab_stud_centers=(),
    roof_start_z=2.65,
    anchor_direction="inward",
    brad_centers=((20.0, -12.0), (20.0, 12.0)),
    brad_axis="Y",
    screw_bores=(
        ScrewBore((-22.0, -8.0), (12.40, 13.50, 15.98, 17.35)),
        ScrewBore((-22.0, 8.0), (12.40, 13.50, 15.98, 17.35)),
    ),
    nut_paths=(
        NutPath((-22.0, -23.50), (-22.0, -8.0), 15.98, (1.0, 0.0)),
        NutPath((-22.0, 23.50), (-22.0, 8.0), 15.98, (1.0, 0.0)),
    ),
    nut_index_angle_deg=0.0,
)

PRESSURE_PAD = ModelSpec(
    key="pressure_pad",
    display_name="PLTW FSR402 Pressure Pad Module v1.4",
    source_zip_name="fsr402-pressure-pad-module-v1-3-dual-mount-3p4.zip",
    source_member=(
        "CARDBOARD_MOUNT_CONFIRMED_3P4/"
        "PLTW_FSR402_LEGO_PressurePad_v1_3_FFit_DualMount_3p4x1p8.stl"
    ),
    output_stl_name=(
        "PLTW_FSR402_LEGO_PressurePad_v1_4_FFit_DualMount_"
        "SolidRoofSupports_AnchoredCouponFFeet_3p6x1p8.stl"
    ),
    tube_grid=grid(range(-32, 33, 8), range(-16, 17, 8)),
    clutch_centers=tuple(
        (float(x), float(y)) for x in (-24, 0, 24) for y in (-8, 8)
    ),
    body_stud_centers=grid(range(-36, 37, 8), range(-20, 21, 8)),
    tab_stud_centers=(),
    roof_start_z=2.40,
    anchor_direction="inward",
    brad_centers=((-20.0, -12.0), (-20.0, 12.0)),
    brad_axis="Y",
    screw_bores=(),
    nut_paths=(),
)

UNIVERSAL = ModelSpec(
    key="universal_pressure",
    display_name="PLTW FSR402 Universal Pressure Module v2.6",
    source_zip_name="fsr402-universal-pressure-module-v2-5-dual-mount-3p4.zip",
    source_member=(
        "CARDBOARD_MOUNT_CONFIRMED_3P4/"
        "PLTW_FSR402_v2_5_FFit_DualMount_3p4x1p8.stl"
    ),
    output_stl_name=(
        "PLTW_FSR402_v2_6_FFit_DualMount_SolidRoofSupports_"
        "AnchoredCouponFFeet_3p6x1p8.stl"
    ),
    tube_grid=grid(range(-48, 33, 8), range(-16, 17, 8)),
    clutch_centers=tuple(
        (float(x), float(y)) for x in (-48, -8, 32) for y in (-16, 16)
    ),
    body_stud_centers=grid(range(-52, 37, 8), range(-20, 21, 8)),
    tab_stud_centers=(),
    roof_start_z=2.80,
    anchor_direction="plus_y",
    brad_centers=((-28.0, -12.0), (-28.0, 12.0)),
    brad_axis="Y",
    screw_bores=(
        ScrewBore((-40.0, -9.2), (3.45, 4.20, 4.95, 6.35)),
        ScrewBore((-40.0, 9.2), (3.45, 4.20, 4.95, 6.35)),
    ),
    nut_paths=(
        NutPath((-55.50, -9.2), (-40.0, -9.2), 4.95, (0.0, 1.0)),
        NutPath((-55.50, 9.2), (-40.0, 9.2), 4.95, (0.0, 1.0)),
    ),
    nut_index_angle_deg=0.0,
)


def photocell_model(kind: str) -> ModelSpec:
    upper = kind.upper()
    return ModelSpec(
        key=f"photocell_{kind.lower()}",
        display_name=f"PLTW Photocell {upper} Base v1.6",
        source_zip_name="photocell-module-family-v1-5-corrected-solid-feet.zip",
        source_member=(
            f"PLTW_GL55_Photocell_{upper}_v1_5_FFit_DualMount_"
            "TerminalLabels_CorrectedSolidFeet.stl"
        ),
        output_stl_name=(
            f"PLTW_GL55_Photocell_{upper}_v1_6_"
            "SolidSupports_AnchorFeet_3p6x1p8.stl"
        ),
        tube_grid=grid((-12, -4, 4, 12), (-8, 0, 8)),
        clutch_centers=((-12.0, -8.0), (-12.0, 8.0), (12.0, -8.0), (12.0, 8.0)),
        body_stud_centers=grid((-16, -8, 0, 8, 16), (-12, -4, 4, 12)),
        tab_stud_centers=((0.0, -28.0), (0.0, -20.0), (0.0, 20.0), (0.0, 28.0)),
        roof_start_z=2.80,
        anchor_direction="plus_y",
        brad_centers=((0.0, -24.0), (0.0, 24.0)),
        brad_axis="X",
        screw_bores=(
            ScrewBore((-13.0, -9.0), (3.40, 4.15, 4.95, 6.35)),
            ScrewBore((13.0, -9.0), (3.40, 4.15, 4.95, 6.35)),
        ),
        nut_paths=(
            NutPath((-19.50, -9.0), (-13.0, -9.0), 4.95, (0.0, 1.0)),
            NutPath((19.50, -9.0), (13.0, -9.0), 4.95, (0.0, 1.0)),
        ),
        nut_index_angle_deg=30.0,
        supports_already_present=True,
    )


PHOTO_AMBIENT = photocell_model("ambient")
PHOTO_BEAM = photocell_model("beam")
PHOTO_COVER = photocell_model("cover")

POTENTIOMETER = ModelSpec(
    key="potentiometer",
    display_name="PLTW Potentiometer Control Dial Module v1.4",
    source_zip_name="potentiometer-control-dial-module-v1-3-solid-supports-anchor-feet.zip",
    source_member=(
        "PLTW_Potentiometer_Control_Dial_v1_3/"
        "PLTW_Potentiometer_v1_3_FFit_DualMount_OpenBrickTabs_"
        "SolidRoofSupports_AnchoredCouponFFeet_3p4x1p8.stl"
    ),
    output_stl_name=(
        "PLTW_Potentiometer_v1_4_SolidSupports_AnchorFeet_3p6x1p8.stl"
    ),
    tube_grid=grid((-16, -8, 0, 8, 16), (-8, 0, 8)),
    clutch_centers=((-16.0, -8.0), (-16.0, 8.0), (16.0, -8.0), (16.0, 8.0)),
    body_stud_centers=grid((-20, -12, -4, 4, 12, 20), (-12, -4, 4, 12)),
    tab_stud_centers=((-4.0, -28.0), (-4.0, -20.0), (-4.0, 20.0), (-4.0, 28.0)),
    roof_start_z=2.80,
    anchor_direction="plus_y",
    brad_centers=((-4.0, -24.0), (-4.0, 24.0)),
    brad_axis="X",
    screw_bores=(
        ScrewBore((11.0, -10.0), (4.05, 5.20, 6.50, 7.85)),
        ScrewBore((18.0, 0.0), (4.05, 5.20, 6.50, 7.85)),
        ScrewBore((11.0, 10.0), (4.05, 5.20, 6.50, 7.85)),
    ),
    nut_paths=(
        NutPath((23.50, -10.0), (11.0, -10.0), 6.50, (0.0, 1.0)),
        NutPath((23.50, 0.0), (18.0, 0.0), 6.50, (0.0, 1.0)),
        NutPath((23.50, 10.0), (11.0, 10.0), 6.50, (0.0, 1.0)),
    ),
    nut_index_angle_deg=30.0,
    supports_already_present=True,
    anchors_already_present=True,
    special_void_points=((-13.0, 0.0, 25.0),),
)


PACKAGES = (
    PackageSpec(
        key="flex_paddle",
        display_name="PLTW Flex Paddle Module v3.5",
        version="3.5",
        directory_name="Flex_Paddle_v3_5",
        archive_root="PLTW_Flex_Paddle_Module_v3_5",
        zip_name="flex-paddle-module-v3-5-solid-supports-anchor-feet-3p6.zip",
        dimensions_name="PLTW_Flex_Paddle_v3_5_Dimensions.csv",
        models=(PADDLE,),
        extra_members=(
            "PLTW_Flex_Module_v3_3_Clamp_1mmFeet_M3_ThroughHoles.stl",
            "PLTW_Flex_Module_v3_3_Optional_Hinge_Pin.stl",
            "PLTW_Flex_Module_v3_3_Paddle_Unchanged.stl",
        ),
        mount_description="Two recessed internal cardboard paths at (-8,-4) and (8,-4)",
        hardware_description="Two preserved side-loaded M3 terminals",
        mechanism_description="Clamp, paddle, hinge pin, sensor clearance, and upper mechanism are unchanged",
        expected_supports=30,
        expected_clutches=6,
    ),
    PackageSpec(
        key="flex_door",
        display_name="PLTW Flex Door / Flap Module v1.8",
        version="1.8",
        directory_name="Flex_Door_v1_8",
        archive_root="PLTW_Flex_Door_Flap_Module_v1_8",
        zip_name="flex-door-flap-module-v1-8-solid-supports-anchor-feet-3p6.zip",
        dimensions_name="PLTW_Flex_Door_v1_8_Dimensions.csv",
        models=(DOOR,),
        extra_members=(
            "PLTW_Flex_Door_v1_6_10mm_Sensor_Guide.stl",
            "PLTW_Flex_Door_v1_6_Extended_Open_End_Flap.stl",
            "PLTW_Flex_Door_v1_6_M3_Connector_Clamp.stl",
            "PLTW_Flex_Door_v1_6_Optional_Flush_Pin_Keeper.stl",
            "PLTW_Flex_Door_v1_6_Optional_Flush_Test_Pin.stl",
        ),
        mount_description="Two recessed internal cardboard paths at (20,-12) and (20,12)",
        hardware_description="Two preserved opposite-side M3 nut-loading paths plus the unchanged 8-32 pivot",
        mechanism_description="Door, guide, clamp, pin, stem support, and raised upper deck are unchanged",
        expected_supports=29,
        expected_clutches=6,
    ),
    PackageSpec(
        key="pressure_pad",
        display_name="PLTW FSR402 Pressure Pad Module v1.4",
        version="1.4",
        directory_name="FSR_Pressure_Pad_v1_4",
        archive_root="PLTW_FSR402_Pressure_Pad_Module_v1_4",
        zip_name="fsr402-pressure-pad-module-v1-4-solid-supports-anchor-feet-3p6.zip",
        dimensions_name="PLTW_FSR402_Pressure_Pad_v1_4_Dimensions.csv",
        models=(PRESSURE_PAD,),
        extra_members=(
            "PLTW_FSR402_Actuator_Puck_0p8mm.stl",
            "PLTW_FSR402_Actuator_Puck_1p0mm.stl",
            "PLTW_FSR402_Actuator_Puck_1p2mm.stl",
            "PLTW_FSR402_LEGO_PressurePad_v1_1_TopPlate.stl",
        ),
        mount_description="Two recessed internal cardboard paths at (-20,-12) and (-20,12)",
        hardware_description="M3 hardware is not used by this pressure-pad base",
        mechanism_description="Top plate, FSR pocket, actuator stem, and all three puck choices are unchanged",
        expected_supports=39,
        expected_clutches=6,
    ),
    PackageSpec(
        key="universal_pressure",
        display_name="PLTW FSR402 Universal Pressure Module v2.6",
        version="2.6",
        directory_name="FSR_Universal_Pressure_v2_6",
        archive_root="PLTW_FSR402_Universal_Pressure_Module_v2_6",
        zip_name="fsr402-universal-pressure-module-v2-6-solid-supports-anchor-feet-3p6.zip",
        dimensions_name="PLTW_FSR402_Universal_Pressure_v2_6_Dimensions.csv",
        models=(UNIVERSAL,),
        extra_members=(
            "PLTW_FSR402_Actuator_Puck_1p0mm.stl",
            "PLTW_FSR402_Actuator_Puck_1p2mm.stl",
            "PLTW_FSR402_Universal_v2_Accessible_55mm_Top.stl",
            "PLTW_FSR402_Universal_v2_Flat_45mm_Top.stl",
            "PLTW_FSR402_Universal_v2_Narrow_45x20mm_Top.stl",
            "PLTW_FSR402_Universal_v2_Three_Guide_Carrier.stl",
            "PLTW_FSR402_v2_4_Dual_Connector_M3_Clamp_Unchanged.stl",
        ),
        mount_description="Two recessed internal cardboard paths at (-28,-12) and (-28,12)",
        hardware_description="Two preserved M3 paths, both loaded from the extended -X end",
        mechanism_description="All tops, carrier, pucks, FSR pocket, and M3 clamp are unchanged",
        expected_supports=49,
        expected_clutches=6,
    ),
    PackageSpec(
        key="photocell",
        display_name="PLTW Photocell Module Family v1.6",
        version="1.6",
        directory_name="Photocell_Family_v1_6",
        archive_root="PLTW_Photocell_Module_Family_v1_6",
        zip_name="photocell-module-family-v1-6-solid-supports-anchor-feet-3p6.zip",
        dimensions_name="PLTW_Photocell_Family_v1_6_Dimensions.csv",
        models=(PHOTO_AMBIENT, PHOTO_BEAM, PHOTO_COVER),
        extra_members=(),
        mount_description="Two open brick tabs per base, centered at Y=-24 and +24 mm",
        hardware_description="Two preserved outward-loading M3 terminal paths per base",
        mechanism_description="Ambient, beam, and cover upper geometries and terminal labels are unchanged",
        expected_supports=8,
        expected_clutches=4,
    ),
    PackageSpec(
        key="potentiometer",
        display_name="PLTW Potentiometer Control Dial Module v1.4",
        version="1.4",
        directory_name="Potentiometer_v1_4",
        archive_root="PLTW_Potentiometer_Control_Dial_Module_v1_4",
        zip_name="potentiometer-control-dial-module-v1-4-solid-supports-anchor-feet-3p6.zip",
        dimensions_name="PLTW_Potentiometer_v1_4_Dimensions.csv",
        models=(POTENTIOMETER,),
        extra_members=(
            "PLTW_Potentiometer_Control_Dial_v1_3/P2p4_P3p2_ACTIVITY_GUIDE.md",
            "PLTW_Potentiometer_Control_Dial_v1_3/PLTW_Potentiometer_v1_Combination_Dial_Knob_B5p9mm_DEFAULT.stl",
            "PLTW_Potentiometer_Control_Dial_v1_3/PLTW_Potentiometer_v1_Accessible_Wing_Knob_B5p9mm_DEFAULT.stl",
            "PLTW_Potentiometer_Control_Dial_v1_3/PLTW_Potentiometer_v1_Bushing_Fit_Coupon_A7p4_B7p6_C7p8.stl",
            "PLTW_Potentiometer_Control_Dial_v1_3/PLTW_Potentiometer_v1_Shaft_Fit_Coupon_A5p7_B5p9_C6p1.stl",
            "PLTW_Potentiometer_Control_Dial_v1_3/PLTW_Potentiometer_v1_M3_Nut_Trap_Coupon.stl",
        ),
        mount_description="Two open brick tabs centered at (-4,-24) and (-4,24) mm",
        hardware_description="All three +X M3 nut-loading paths are preserved",
        mechanism_description="Panel, bushing opening, terminal labels, knobs, and fit coupons are unchanged",
        expected_supports=11,
        expected_clutches=4,
    ),
)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def load_mesh_bytes(data: bytes) -> trimesh.Trimesh:
    loaded = trimesh.load(io.BytesIO(data), file_type="stl", force="mesh", process=True)
    if isinstance(loaded, trimesh.Scene):
        loaded = loaded.to_geometry()
    if not isinstance(loaded, trimesh.Trimesh):
        raise TypeError(f"Expected Trimesh, got {type(loaded)!r}")
    loaded.remove_unreferenced_vertices()
    return loaded


def load_mesh_file(path: Path) -> trimesh.Trimesh:
    loaded = trimesh.load(path, force="mesh", process=True)
    if isinstance(loaded, trimesh.Scene):
        loaded = loaded.to_geometry()
    if not isinstance(loaded, trimesh.Trimesh):
        raise TypeError(f"Expected Trimesh at {path}, got {type(loaded)!r}")
    loaded.remove_unreferenced_vertices()
    return loaded


def source_bytes(spec: ModelSpec) -> bytes:
    with zipfile.ZipFile(DOWNLOADS / spec.source_zip_name) as archive:
        return archive.read(spec.source_member)


def cylinder_at(
    x: float,
    y: float,
    radius: float,
    height: float,
    z0: float = 0.0,
    sections: int = 64,
) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    mesh.apply_translation([x, y, z0 + height / 2.0])
    return mesh


def direction_for(spec: ModelSpec, center: tuple[float, float]) -> tuple[float, float]:
    if spec.anchor_direction == "plus_y":
        return (0.0, 1.0)
    x, y = center
    length = math.hypot(x, y)
    if length <= 1e-9:
        raise ValueError(f"Cannot calculate inward direction for {spec.key} at {center}")
    return (-x / length, -y / length)


def anchor_foot(spec: ModelSpec, center: tuple[float, float]) -> trimesh.Trimesh:
    x, y = center
    direction_x, direction_y = direction_for(spec, center)
    disk = cylinder_at(x, y, ANCHOR_RADIUS, ANCHOR_HEIGHT, sections=96)
    notch = trimesh.creation.box(
        extents=[ANCHOR_NOTCH_WIDTH, ANCHOR_NOTCH_LENGTH, ANCHOR_HEIGHT + 0.40]
    )
    angle = math.atan2(direction_y, direction_x) - math.pi / 2.0
    notch.apply_transform(trimesh.transformations.rotation_matrix(angle, [0.0, 0.0, 1.0]))
    notch.apply_translation(
        [x + direction_x * 2.0, y + direction_y * 2.0, ANCHOR_HEIGHT / 2.0]
    )
    result = trimesh.boolean.difference([disk, notch], engine="manifold")
    result.remove_unreferenced_vertices()
    return result


def capsule_tool(
    center: tuple[float, float],
    axis: str,
    z_min: float,
    z_max: float,
) -> trimesh.Trimesh:
    radius = BRAD_WIDTH / 2.0
    straight = BRAD_LONG - BRAD_WIDTH
    height = z_max - z_min + 4.0
    middle = trimesh.creation.box(extents=[BRAD_WIDTH, straight, height])
    ends = []
    for y in (-straight / 2.0, straight / 2.0):
        # Keep every primitive centered at local Z=0 before translating the
        # completed cutter through the source's full height.
        end = trimesh.creation.cylinder(radius=radius, height=height, sections=96)
        end.apply_translation([0.0, y, 0.0])
        ends.append(end)
    capsule = trimesh.boolean.union([middle, *ends], engine="manifold")
    if axis == "X":
        capsule.apply_transform(
            trimesh.transformations.rotation_matrix(math.pi / 2.0, [0.0, 0.0, 1.0])
        )
    elif axis != "Y":
        raise ValueError(f"Unsupported capsule axis: {axis}")
    capsule.apply_translation([center[0], center[1], (z_min + z_max) / 2.0])
    return capsule


def indexed_hex_sweep(
    path: NutPath,
    across_flats: float,
    thickness: float,
    angle_deg: float,
) -> trimesh.Trimesh:
    """Convex hull of a keyed M3 hex prism at both path endpoints."""
    radius = across_flats / math.sqrt(3.0)
    points: list[tuple[float, float, float]] = []
    angle0 = math.radians(angle_deg)
    for endpoint in (path.start, path.end):
        for z in (path.z_center - thickness / 2.0, path.z_center + thickness / 2.0):
            for index in range(6):
                theta = angle0 + index * math.pi / 3.0
                points.append(
                    (
                        endpoint[0] + radius * math.cos(theta),
                        endpoint[1] + radius * math.sin(theta),
                        z,
                    )
                )
    return trimesh.convex.convex_hull(np.asarray(points, dtype=float))


def intersection_volume(first: trimesh.Trimesh, second: trimesh.Trimesh) -> float:
    overlap = trimesh.boolean.intersection([first, second], engine="manifold")
    if overlap is None:
        return 0.0
    if isinstance(overlap, trimesh.Scene):
        overlap = overlap.to_geometry()
    if overlap.is_empty:
        return 0.0
    return abs(float(overlap.volume))


def export_and_reload(mesh: trimesh.Trimesh, path: Path) -> trimesh.Trimesh:
    mesh.remove_unreferenced_vertices()
    if len(mesh.split(only_watertight=False)) != 1:
        raise RuntimeError(f"Pre-export mesh is not one component: {path.name}")
    mesh.export(path)
    exported = load_mesh_file(path)
    components = list(exported.split(only_watertight=False))
    if len(components) > 1:
        material = [component for component in components if abs(float(component.volume)) > 1e-6]
        zero_volume = [component for component in components if abs(float(component.volume)) <= 1e-6]
        if len(material) != 1 or not all(len(component.faces) <= 2 for component in zero_volume):
            raise RuntimeError(
                f"Export produced a real secondary component in {path.name}: "
                f"material={len(material)}, zero_volume={len(zero_volume)}"
            )
        print(
            f"sanitized_zero_volume_export_facets|{path.name}|components={len(zero_volume)}",
            flush=True,
        )
        exported = material[0]
        exported.remove_unreferenced_vertices()
        exported.export(path)
        exported = load_mesh_file(path)
    if not exported.is_watertight or len(exported.split(only_watertight=False)) != 1:
        raise RuntimeError(f"Reloaded STL is not watertight and one component: {path.name}")
    return exported


def contains(mesh: trimesh.Trimesh, points: list[tuple[float, float, float]]) -> list[bool]:
    if not points:
        return []
    # The legacy paddle and pressure-pad STLs are intentionally high-density.
    # Trimesh's triangle-ray backend can allocate several gigabytes if tens of
    # thousands of probes are submitted in one call, even though its spatial
    # tree is cached. Chunking retains every probe while bounding memory.
    array = np.asarray(points, dtype=float)
    result: list[bool] = []
    for start in range(0, len(array), 256):
        result.extend(bool(value) for value in mesh.contains(array[start : start + 256]))
    return result


def dense_circle_points(
    center: tuple[float, float],
    max_radius: float,
    radii: int,
    angles: int,
    zs: tuple[float, ...],
) -> list[tuple[float, float, float]]:
    result: list[tuple[float, float, float]] = []
    for radius in np.linspace(0.0, max_radius, radii):
        theta_values = (0.0,) if radius == 0.0 else np.linspace(
            0.0, 2.0 * math.pi, angles, endpoint=False
        )
        for theta in theta_values:
            result.extend(
                (
                    center[0] + float(radius) * math.cos(float(theta)),
                    center[1] + float(radius) * math.sin(float(theta)),
                    z,
                )
                for z in zs
            )
    return result


def capsule_points(
    center: tuple[float, float], axis: str, z_values: tuple[float, ...]
) -> list[tuple[float, float, float]]:
    points: list[tuple[float, float, float]] = []
    radius = 0.82
    straight_half = (3.48 - 1.64) / 2.0
    for along in np.linspace(-straight_half, straight_half, 7):
        for cross in np.linspace(-radius, radius, 7):
            for z in z_values:
                if axis == "Y":
                    points.append((center[0] + cross, center[1] + along, z))
                else:
                    points.append((center[0] + along, center[1] + cross, z))
    for sign in (-1.0, 1.0):
        end_center = sign * straight_half
        for r in np.linspace(0.0, radius, 5):
            for theta in np.linspace(0.0, 2.0 * math.pi, 16, endpoint=False):
                along = end_center + r * math.cos(float(theta))
                cross = r * math.sin(float(theta))
                for z in z_values:
                    if axis == "Y":
                        points.append((center[0] + cross, center[1] + along, z))
                    else:
                        points.append((center[0] + along, center[1] + cross, z))
    return points


def nut_path_points(path: NutPath) -> list[tuple[float, float, float]]:
    result: list[tuple[float, float, float]] = []
    for t in np.linspace(0.0, 1.0, 7):
        x = path.start[0] * (1.0 - t) + path.end[0] * t
        y = path.start[1] * (1.0 - t) + path.end[1] * t
        for transverse in np.linspace(-path.half_width, path.half_width, 5):
            for z_offset in np.linspace(-path.half_height, path.half_height, 5):
                result.append(
                    (
                        x + path.transverse[0] * float(transverse),
                        y + path.transverse[1] * float(transverse),
                        path.z_center + float(z_offset),
                    )
                )
    return result


def screw_bore_points(bore: ScrewBore) -> list[tuple[float, float, float]]:
    return dense_circle_points(bore.center, 1.45, 4, 16, bore.zs)


def is_inside_capsule_xy(
    point: np.ndarray,
    center: tuple[float, float],
    axis: str,
    tolerance: float = 0.025,
) -> bool:
    dx = float(point[0] - center[0])
    dy = float(point[1] - center[1])
    along = dy if axis == "Y" else dx
    cross = dx if axis == "Y" else dy
    radius = BRAD_WIDTH / 2.0 + tolerance
    straight_half = (BRAD_LONG - BRAD_WIDTH) / 2.0
    end_distance = max(abs(along) - straight_half, 0.0)
    return cross * cross + end_distance * end_distance <= radius * radius


def is_inside_tool_bounds(
    point: np.ndarray,
    tool: trimesh.Trimesh,
    tolerance: float = DELTA_KERNEL_ENVELOPE,
) -> bool:
    return bool(
        np.all(point >= np.asarray(tool.bounds[0]) - tolerance)
        and np.all(point <= np.asarray(tool.bounds[1]) + tolerance)
    )


def is_allowed_addition(spec: ModelSpec, point: np.ndarray) -> bool:
    z = float(point[2])
    if z < -0.025 or z > SUPPORT_HEIGHT + 0.025:
        return False
    if any(
        math.hypot(float(point[0]) - x, float(point[1]) - y)
        <= SUPPORT_RADIUS + DELTA_KERNEL_ENVELOPE
        for x, y in spec.support_centers
    ):
        return True
    if z <= ANCHOR_HEIGHT + 0.025 and any(
        math.hypot(float(point[0]) - x, float(point[1]) - y)
        <= ANCHOR_RADIUS + DELTA_KERNEL_ENVELOPE
        for x, y in spec.clutch_centers
    ):
        return True
    # A manifold union re-triangulates the shared cavity-roof junction around
    # neighboring clutch tubes even though the constructive anchor ends at
    # Z=0.60. Permit only that bounded, low-Z kernel shell; independent dense
    # bore probes still require every clutch centerline and notch to be open.
    if z <= SUPPORT_HEIGHT + 0.025 and any(
        math.hypot(float(point[0]) - x, float(point[1]) - y)
        <= ANCHOR_RADIUS + DELTA_KERNEL_ENVELOPE
        for x, y in spec.clutch_centers
    ):
        return True
    return False


def sampled_delta_points(mesh: trimesh.Trimesh, maximum: int = 150_000) -> np.ndarray:
    if mesh.is_empty or len(mesh.faces) == 0:
        return np.empty((0, 3), dtype=float)
    # Manifold differences between two equivalent, differently triangulated
    # STL surfaces can return many zero-volume surface shards. They are not a
    # material delta. Localize only connected components with measurable
    # volume; their total still equals the reported Boolean delta volume.
    significant = [
        component
        for component in mesh.split(only_watertight=False)
        if abs(float(component.volume)) > 1e-6
    ]
    if not significant:
        return np.empty((0, 3), dtype=float)
    material = trimesh.util.concatenate(significant)
    vertices = np.asarray(material.vertices)
    centers = np.asarray(material.triangles_center)
    points = np.vstack([vertices, centers])
    if len(points) > maximum:
        indices = np.linspace(0, len(points) - 1, maximum, dtype=int)
        points = points[indices]
    return points


def mesh_difference(first: trimesh.Trimesh, second: trimesh.Trimesh) -> trimesh.Trimesh:
    result = trimesh.boolean.difference([first, second], engine="manifold")
    if result is None:
        return trimesh.Trimesh()
    if isinstance(result, trimesh.Scene):
        result = result.to_geometry()
    result.remove_unreferenced_vertices()
    return result


def build_model(
    spec: ModelSpec, output_dir: Path
) -> tuple[
    trimesh.Trimesh,
    trimesh.Trimesh,
    list[trimesh.Trimesh],
    list[trimesh.Trimesh],
    list[trimesh.Trimesh],
    list[trimesh.Trimesh],
    list[float],
    str,
]:
    raw = source_bytes(spec)
    source = load_mesh_bytes(raw)
    if not source.is_watertight or len(source.split(only_watertight=False)) != 1:
        raise RuntimeError(f"Source is not watertight and one component: {spec.source_member}")

    cuts = [
        capsule_tool(center, spec.brad_axis, float(source.bounds[0, 2]), float(source.bounds[1, 2]))
        for center in spec.brad_centers
    ]
    source_nut_collisions: list[float] = []
    nut_clearance_tools: list[trimesh.Trimesh] = []
    if spec.nut_paths and spec.nut_index_angle_deg is None:
        raise RuntimeError(f"Missing indexed M3 nut orientation for {spec.display_name}")
    for path in spec.nut_paths:
        nominal = indexed_hex_sweep(path, 5.50, 2.40, float(spec.nut_index_angle_deg))
        collision = intersection_volume(source, nominal)
        source_nut_collisions.append(collision)
        if collision > 1e-5:
            nut_clearance_tools.append(
                indexed_hex_sweep(path, 5.55, 2.45, float(spec.nut_index_angle_deg))
            )
    if len(nut_clearance_tools) != spec.expected_m3_clearance_cuts:
        raise RuntimeError(
            f"Unexpected M3 clearance-cut count for {spec.display_name}: "
            f"{len(nut_clearance_tools)} != {spec.expected_m3_clearance_cuts}; "
            f"source collisions={source_nut_collisions}"
        )

    widened = trimesh.boolean.difference(
        [source, *cuts, *nut_clearance_tools], engine="manifold"
    )
    widened.remove_unreferenced_vertices()
    if len(widened.split(only_watertight=False)) != 1:
        raise RuntimeError(f"3.6 mm path widening split {spec.display_name}")

    supports = [
        cylinder_at(x, y, SUPPORT_RADIUS, SUPPORT_HEIGHT, sections=64)
        for x, y in spec.support_centers
    ]
    anchors = [anchor_foot(spec, center) for center in spec.clutch_centers]
    additions: list[trimesh.Trimesh] = []
    # Even where the v1.5 photocell already had 2.80 mm posts, union the exact
    # 2.85 mm tools so the constructive source meets the common standard.
    if not spec.supports_already_present or spec.key.startswith("photocell_"):
        additions.extend(supports)
    if not spec.anchors_already_present:
        additions.extend(anchors)

    result = widened
    if additions:
        result = trimesh.boolean.union([widened, *additions], engine="manifold")
    result.remove_unreferenced_vertices()
    output_path = output_dir / spec.output_stl_name
    exported = export_and_reload(result, output_path)
    return (
        source,
        exported,
        supports,
        anchors,
        cuts,
        nut_clearance_tools,
        source_nut_collisions,
        sha256_bytes(raw),
    )


def validate_model(
    spec: ModelSpec,
    source: trimesh.Trimesh,
    mesh: trimesh.Trimesh,
    nut_clearance_tools: list[trimesh.Trimesh],
    source_nut_collisions: list[float],
) -> dict[str, object]:
    roof_probe = min(spec.roof_start_z - 0.08, 2.70)
    support_zs = (0.05, 0.30, 1.40, roof_probe, 2.79, 2.84)
    support_points = [
        point
        for center in spec.support_centers
        for point in dense_circle_points(center, 2.50, 3, 12, support_zs)
    ]
    clutch_center_points = [
        (x, y, z)
        for x, y in spec.clutch_centers
        for z in (0.05, 0.30, 0.59, 0.61, 1.40, roof_probe)
    ]
    anchor_material: list[tuple[float, float, float]] = []
    anchor_notches: list[tuple[float, float, float]] = []
    anchor_above: list[tuple[float, float, float]] = []
    for center in spec.clutch_centers:
        x, y = center
        direction_x, direction_y = direction_for(spec, center)
        perpendicular_x, perpendicular_y = -direction_y, direction_x
        material_xy = (
            (x - direction_x * 1.50, y - direction_y * 1.50),
            (x + perpendicular_x * 1.55, y + perpendicular_y * 1.55),
            (x - perpendicular_x * 1.55, y - perpendicular_y * 1.55),
        )
        for px, py in material_xy:
            anchor_material.extend((px, py, z) for z in (0.05, 0.30, 0.59))
            anchor_above.append((px, py, 0.61))
        for radius in (0.0, 0.60, 1.20, 1.80, 2.40):
            anchor_notches.extend(
                (
                    x + direction_x * radius,
                    y + direction_y * radius,
                    z,
                )
                for z in (0.05, 0.30, 0.59)
            )

    stud_zs = (0.30, 1.30, max(1.50, roof_probe))
    body_stud_points = [
        point
        for center in spec.body_stud_centers
        for point in dense_circle_points(center, 2.25, 3, 12, stud_zs)
    ]
    tab_stud_points = [
        point
        for center in spec.tab_stud_centers
        for point in dense_circle_points(center, 2.25, 3, 12, (0.30, 1.30, 2.30))
    ]

    slit_z_max = min(float(mesh.bounds[1, 2]) - 0.05, 9.0)
    slit_zs = tuple(float(value) for value in np.linspace(0.10, slit_z_max, 7))
    slit_points = [
        point
        for center in spec.brad_centers
        for point in capsule_points(center, spec.brad_axis, slit_zs)
    ]
    screw_points = [point for bore in spec.screw_bores for point in screw_bore_points(bore)]
    nut_points = [point for path in spec.nut_paths for point in nut_path_points(path)]

    addition_delta = mesh_difference(mesh, source)
    removal_delta = mesh_difference(source, mesh)
    addition_points = sampled_delta_points(addition_delta)
    removal_points = sampled_delta_points(removal_delta)
    addition_violations = [
        point for point in addition_points if not is_allowed_addition(spec, point)
    ]
    removal_violations = [
        point
        for point in removal_points
        if not (
            any(
                is_inside_capsule_xy(point, center, spec.brad_axis)
                for center in spec.brad_centers
            )
            or any(is_inside_tool_bounds(point, tool) for tool in nut_clearance_tools)
        )
    ]
    addition_local = not addition_violations
    removal_local = not removal_violations
    removal_local_crosscheck = all(
        (
            any(
                is_inside_capsule_xy(point, center, spec.brad_axis)
                for center in spec.brad_centers
            )
            or any(is_inside_tool_bounds(point, tool) for tool in nut_clearance_tools)
        )
        for point in removal_points
    )
    if removal_local != removal_local_crosscheck:
        raise AssertionError("Removal localization implementations disagree")
    addition_max_z = (
        None if len(addition_points) == 0 else round(float(np.max(addition_points[:, 2])), 5)
    )

    source_screw_open = not any(contains(source, screw_points))
    output_screw_open = not any(contains(mesh, screw_points))
    source_nut_open = not any(contains(source, nut_points))
    output_nut_open = not any(contains(mesh, nut_points))
    final_nut_collisions = [
        intersection_volume(
            mesh,
            indexed_hex_sweep(
                path,
                5.50,
                2.40,
                float(spec.nut_index_angle_deg),
            ),
        )
        for path in spec.nut_paths
    ]

    checks: dict[str, object] = {
        "model": spec.display_name,
        "watertight": bool(mesh.is_watertight),
        "winding_consistent": bool(mesh.is_winding_consistent),
        "components": len(mesh.split(only_watertight=False)),
        "faces": int(len(mesh.faces)),
        "bounds_mm": [[round(float(v), 4) for v in row] for row in mesh.bounds],
        "extents_mm": [round(float(v), 4) for v in mesh.extents],
        "source_extents_mm": [round(float(v), 4) for v in source.extents],
        "source_extents_preserved": bool(np.allclose(mesh.extents, source.extents, atol=1e-4)),
        "support_count": len(spec.support_centers),
        "support_diameter_mm": SUPPORT_RADIUS * 2.0,
        "support_height_mm": SUPPORT_HEIGHT,
        "cavity_roof_start_z_mm": spec.roof_start_z,
        "support_roof_overlap_mm": round(SUPPORT_HEIGHT - spec.roof_start_z, 3),
        "all_safe_support_disks_solid_to_z_2p84": all(contains(mesh, support_points)),
        "clutch_count": len(spec.clutch_centers),
        "all_coupon_f_centerlines_open": not any(contains(mesh, clutch_center_points)),
        "c_anchor_count": len(spec.clutch_centers),
        "c_anchor_height_mm": ANCHOR_HEIGHT,
        "c_anchor_diameter_mm": ANCHOR_RADIUS * 2.0,
        "c_anchor_notch_mm": [ANCHOR_NOTCH_WIDTH, ANCHOR_NOTCH_LENGTH],
        "c_anchor_direction": spec.anchor_direction,
        "anchor_material_present_through_z_0p59": all(contains(mesh, anchor_material)),
        "anchor_material_ends_before_z_0p61": not any(contains(mesh, anchor_above)),
        "anchor_notches_open_and_split_aligned": not any(contains(mesh, anchor_notches)),
        "body_stud_count": len(spec.body_stud_centers),
        "all_body_stud_clearance_disks_open": not any(contains(mesh, body_stud_points)),
        "tab_continuation_stud_count": len(spec.tab_stud_centers),
        "all_tab_continuation_clearance_disks_open": not any(contains(mesh, tab_stud_points)),
        "cardboard_path_count": len(spec.brad_centers),
        "cardboard_path_mm": [BRAD_LONG, BRAD_WIDTH],
        "cardboard_path_axis": spec.brad_axis,
        "all_3p6x1p8_cardboard_capsules_open_dense": not any(contains(mesh, slit_points)),
        "m3_screw_bore_count": len(spec.screw_bores),
        "m3_nut_loading_path_count": len(spec.nut_paths),
        "m3_nut_index_angle_deg": spec.nut_index_angle_deg,
        "nominal_m3_nut_envelope_mm": [5.50, 2.40],
        "clearance_m3_nut_cutter_mm": [5.55, 2.45],
        "source_nominal_m3_nut_sweep_collision_mm3": [
            round(value, 9) for value in source_nut_collisions
        ],
        "localized_m3_clearance_cut_count": len(nut_clearance_tools),
        "final_nominal_m3_nut_sweep_collision_mm3": [
            round(value, 9) for value in final_nut_collisions
        ],
        "all_final_nominal_m3_nut_sweeps_zero": all(
            value <= 1e-5 for value in final_nut_collisions
        ),
        "source_m3_screw_probes_open": source_screw_open,
        "output_m3_screw_probes_open": output_screw_open,
        "source_m3_nut_volume_probes_open": source_nut_open,
        "output_m3_nut_volume_probes_open": output_nut_open,
        "special_upper_voids_open": not any(contains(mesh, list(spec.special_void_points))),
        "addition_delta_volume_mm3": round(abs(float(addition_delta.volume)), 5),
        "removal_delta_volume_mm3": round(abs(float(removal_delta.volume)), 5),
        "addition_delta_sample_count": int(len(addition_points)),
        "removal_delta_sample_count": int(len(removal_points)),
        "delta_kernel_localization_envelope_mm": DELTA_KERNEL_ENVELOPE,
        "addition_delta_violation_count": len(addition_violations),
        "removal_delta_violation_count": len(removal_violations),
        "addition_delta_violation_examples": [
            [round(float(value), 5) for value in point]
            for point in addition_violations[:12]
        ],
        "removal_delta_violation_examples": [
            [round(float(value), 5) for value in point]
            for point in removal_violations[:12]
        ],
        "addition_delta_localized_to_supports_and_anchors": bool(addition_local),
        "removal_delta_localized_to_3p6_capsules_or_indexed_m3_clearance": bool(removal_local),
        "addition_delta_max_z_mm": addition_max_z,
        "no_added_geometry_above_z_2p85": bool(
            addition_max_z is None or addition_max_z <= SUPPORT_HEIGHT + 0.025
        ),
        "upper_geometry_preserved_except_local_3p6_and_m3_path_clearances": bool(
            addition_local
            and removal_local
            and (addition_max_z is None or addition_max_z <= SUPPORT_HEIGHT + 0.025)
        ),
        "output_stl_sha256": "",
    }
    required = (
        checks["watertight"]
        and checks["winding_consistent"]
        and checks["components"] == 1
        and checks["source_extents_preserved"]
        and checks["support_count"] > 0
        and checks["all_safe_support_disks_solid_to_z_2p84"]
        and checks["all_coupon_f_centerlines_open"]
        and checks["anchor_material_present_through_z_0p59"]
        and checks["anchor_material_ends_before_z_0p61"]
        and checks["anchor_notches_open_and_split_aligned"]
        and checks["all_body_stud_clearance_disks_open"]
        and checks["all_tab_continuation_clearance_disks_open"]
        and checks["all_3p6x1p8_cardboard_capsules_open_dense"]
        and checks["source_m3_screw_probes_open"]
        and checks["output_m3_screw_probes_open"]
        and checks["source_m3_nut_volume_probes_open"]
        and checks["output_m3_nut_volume_probes_open"]
        and checks["all_final_nominal_m3_nut_sweeps_zero"]
        and checks["special_upper_voids_open"]
        and checks["addition_delta_localized_to_supports_and_anchors"]
        and checks["removal_delta_localized_to_3p6_capsules_or_indexed_m3_clearance"]
        and checks["no_added_geometry_above_z_2p85"]
        and checks["upper_geometry_preserved_except_local_3p6_and_m3_path_clearances"]
    )
    checks["all_required_checks_pass"] = bool(required)
    return checks


def extract_extras(package: PackageSpec, output_dir: Path) -> list[str]:
    if not package.extra_members:
        return []
    source_zip = DOWNLOADS / package.models[0].source_zip_name
    output_names: list[str] = []
    with zipfile.ZipFile(source_zip) as archive:
        for member in package.extra_members:
            name = Path(member).name
            data = archive.read(member)
            (output_dir / name).write_bytes(data)
            if (output_dir / name).read_bytes() != data:
                raise RuntimeError(f"Ancillary copy mismatch: {name}")
            output_names.append(name)
    return output_names


def write_source_lineage(
    package: PackageSpec,
    output_dir: Path,
    source_hashes: dict[str, str],
) -> str:
    name = "SOURCE_LINEAGE.txt"
    lines = [
        f"{package.display_name} source lineage",
        "",
        "Every base starts from the exact current website ZIP member listed below.",
        "No legacy LEGO-only base was merged into the new unified geometry.",
        "",
    ]
    for model in package.models:
        source_zip = DOWNLOADS / model.source_zip_name
        lines.extend(
            [
                f"Model: {model.display_name}",
                f"Source ZIP: {model.source_zip_name}",
                f"Source ZIP SHA-256: {sha256_file(source_zip)}",
                f"Source member: {model.source_member}",
                f"Source STL SHA-256: {source_hashes[model.key]}",
                f"Output STL: {model.output_stl_name}",
                "Transformation: widen only the two existing 3.4 x 1.8 mm capsules to 3.6 x 1.8 mm; union the declared 5.20 x 2.85 mm supports and split-aligned 0.60 mm Coupon-F C anchors where required; cut a 5.55-AF x 2.45 mm indexed M3 sweep only when the inherited source intersects a nominal 5.50-AF x 2.40 mm sweep.",
                "",
            ]
        )
    lines.extend(
        [
            "The build fails on every secondary component with measurable volume. It may remove only explicit zero-volume two-triangle STL export facet pairs, then requires the reloaded STL to be watertight and one component.",
            "All final validation is performed after STL export and reload.",
            "",
        ]
    )
    (output_dir / name).write_text("\n".join(lines), encoding="utf-8")
    return name


def write_readme(
    package: PackageSpec,
    output_dir: Path,
    meshes: dict[str, trimesh.Trimesh],
) -> str:
    name = "README_FIRST.md"
    model_lines = []
    for model in package.models:
        mesh = meshes[model.key]
        model_lines.append(
            f"- `{model.output_stl_name}` — {len(model.support_centers)} solid supports, "
            f"{len(model.clutch_centers)} open Coupon-F bores with split-aligned C anchors; "
            f"overall {mesh.extents[0]:.2f} x {mesh.extents[1]:.2f} x {mesh.extents[2]:.2f} mm"
        )
    m3_text = (
        "M3 is N/A for this base."
        if all(not model.screw_bores for model in package.models)
        else package.hardware_description + ". Dense screw-bore and full nut-corridor volume probes pass on both the source and final STL."
    )
    index_lines = [
        f"- {model.display_name}: indexed M3 nut angle {model.nut_index_angle_deg:g} degrees; "
        f"localized 5.55-AF x 2.45 mm corrective sweeps: {model.expected_m3_clearance_cuts}."
        for model in package.models
        if model.nut_paths
    ]
    text = f"""# {package.display_name}

This is the unified LEGO-and-cardboard revision. It starts from the exact
current dual-mount/final website geometry, keeps the upper mechanism and all
unchanged accessory parts, and updates only the underside support system and
the existing cardboard-fastener openings.

## Printable base choices

{chr(10).join(model_lines)}

## Supportless-printing standard

- Every safe non-clutch center is a full 5.20 mm-diameter x 2.85 mm-high solid
  roof-support post.
- Every intended Coupon-F clutch bore stays open and receives a 6.00 mm x
  0.60 mm C-shaped first-layer anchor.
- C-anchor notches follow the exact existing split direction.
- {package.mechanism_description}.
- {m3_text}
{chr(10).join(index_lines)}

The indexed hardware gate uses a full convex sweep of a nominal 5.50 mm
across-flats x 2.40 mm-thick M3 nut, not just a centerline. Only the flex
paddle's inherited tunnels collide: each receives a localized 5.55 mm
across-flats x 2.45 mm clearance sweep at the source-keyed 0-degree index.
Door and universal pressure pass at 0 degrees; photocell and potentiometer pass
at 30 degrees and receive no M3 clearance cut.

The universal-pressure base has the tightest roof junction: its posts reach
Z=2.85 mm and overlap the Z=2.80 mm roof by exactly 0.05 mm. The exported STL
is required to reload watertight and as one component; no disconnected piece
is silently discarded.

## Cardboard mounting

- {package.mount_description}.
- Both existing openings are now 3.6 x 1.8 mm rounded capsules. Only the 0.1 mm
  extension at each end of the former 3.4 mm long axis was removed.
- The included coupon contains 3.2, 3.4, and 3.6 mm choices. Start with 3.6 mm
  for this revision, then confirm with the classroom brass fastener, printer,
  and cardboard before producing a class set.
- For open brick tabs, insert from the top, pass through the cardboard, spread
  the legs underneath, and cover exposed metal.

## Printing

- PLA, 0.4 mm nozzle, 0.20 mm layer height
- Four wall loops and approximately 20% gyroid infill
- LEGO underside flat on the build plate
- Supports off; raft off
- Use a small outer brim only if the broad base corners lift

## Validation and pilot status

The exact exported-and-reloaded STL files are checked for watertightness,
winding consistency, one connected component, support and anchor counts,
dense solid-post coverage, open Coupon-F centerlines and LEGO seating disks,
3.6 x 1.8 mm paths, and preserved M3 loading volumes where applicable.
Boolean source/output deltas must remain inside the widened slit tools and a
documented 0.35 mm kernel re-triangulation envelope around the exact support
and anchor construction tools, proving the rest of the upper geometry is
unchanged.
The ZIP is also byte-compared against every packaged file and the copy placed
in the website downloads directory.

A physical pilot remains required with the actual LEGO plate, sensor,
mechanism, M3 hardware where applicable, cardboard, and brass fasteners before
classroom quantities.
"""
    (output_dir / name).write_text(text, encoding="utf-8")
    return name


def write_dimensions(
    package: PackageSpec,
    output_dir: Path,
    meshes: dict[str, trimesh.Trimesh],
) -> str:
    rows: list[tuple[str, str, str]] = [("Model", "Feature", "Value")]
    for model in package.models:
        mesh = meshes[model.key]
        prefix = model.display_name
        features = [
            ("Overall mesh extents", " x ".join(f"{value:.2f}" for value in mesh.extents) + " mm"),
            ("Solid non-clutch roof supports", str(len(model.support_centers))),
            ("Support diameter x height", "5.20 x 2.85 mm"),
            ("Cavity roof starts", f"Z = {model.roof_start_z:.2f} mm"),
            ("Support-to-roof overlap", f"{SUPPORT_HEIGHT - model.roof_start_z:.2f} mm"),
            ("Open Coupon-F clutch bores", str(len(model.clutch_centers))),
            ("C anchor feet", f"{len(model.clutch_centers)} at 6.00 mm diameter x 0.60 mm high"),
            ("Anchor notch", f"{ANCHOR_NOTCH_WIDTH:.2f} x {ANCHOR_NOTCH_LENGTH:.2f} mm; {model.anchor_direction}"),
            ("Cardboard paths", f"2 x 3.60 x 1.80 mm capsules; long axis {model.brad_axis}"),
            ("Cardboard path centers", "; ".join(f"({x:g},{y:g})" for x, y in model.brad_centers) + " mm"),
            ("M3 screw bores", str(len(model.screw_bores)) if model.screw_bores else "N/A"),
            ("M3 nut-loading paths", str(len(model.nut_paths)) if model.nut_paths else "N/A"),
            ("Nominal swept M3 nut envelope", "5.50 mm across flats x 2.40 mm" if model.nut_paths else "N/A"),
            ("Indexed M3 nut angle", f"{model.nut_index_angle_deg:g} degrees" if model.nut_paths else "N/A"),
            ("Localized M3 clearance cutter", f"{model.expected_m3_clearance_cuts} x 5.55 mm across flats x 2.45 mm" if model.expected_m3_clearance_cuts else "None"),
            ("Upper mechanism", package.mechanism_description),
        ]
        rows.extend((prefix, feature, value) for feature, value in features)
    with (output_dir / package.dimensions_name).open("w", newline="", encoding="utf-8") as handle:
        csv.writer(handle).writerows(rows)
    return package.dimensions_name


def preview_mesh(mesh: trimesh.Trimesh, max_faces: int = 75_000) -> trimesh.Trimesh:
    if len(mesh.faces) <= max_faces:
        return mesh
    # Deterministic face sampling is preview-only. The packaged STL and all
    # validation always use the complete exported mesh.
    face_indices = np.linspace(0, len(mesh.faces) - 1, max_faces, dtype=int)
    sampled = trimesh.Trimesh(vertices=mesh.vertices.copy(), faces=mesh.faces[face_indices], process=False)
    sampled.remove_unreferenced_vertices()
    return sampled


def render_isometric(
    specs: list[tuple[trimesh.Trimesh, tuple[int, int, int]]],
    path: Path,
    title: str,
    footer: str,
    underside: bool = False,
    overlay_count: int = 0,
) -> None:
    prepared: list[tuple[trimesh.Trimesh, tuple[int, int, int]]] = []
    rotation = trimesh.transformations.rotation_matrix(math.pi, [1.0, 0.0, 0.0])
    for mesh, color in specs:
        item = mesh.copy()
        if underside:
            item.apply_transform(rotation)
        prepared.append((item, color))

    view = np.array([1.0, -1.35, 0.88])
    view /= np.linalg.norm(view)
    right = np.cross(view, np.array([0.0, 0.0, 1.0]))
    right /= np.linalg.norm(right)
    up = np.cross(right, view)
    up /= np.linalg.norm(up)
    light = np.array([0.30, -0.45, 0.84])
    light /= np.linalg.norm(light)

    base_triangles: list[tuple[float, np.ndarray, tuple[int, int, int]]] = []
    overlays: list[tuple[float, np.ndarray, tuple[int, int, int]]] = []
    projected_all: list[np.ndarray] = []
    overlay_start = len(prepared) - overlay_count
    for index, (mesh, color) in enumerate(prepared):
        rendered = mesh if index >= overlay_start else preview_mesh(mesh)
        tri3 = rendered.vertices[rendered.faces]
        normals = np.cross(tri3[:, 1] - tri3[:, 0], tri3[:, 2] - tri3[:, 0])
        lengths = np.linalg.norm(normals, axis=1)
        valid = lengths > 1e-9
        normals[valid] /= lengths[valid, None]
        facing = normals @ view > -0.08
        target = overlays if overlay_count and index >= overlay_start else base_triangles
        for triangle, normal in zip(tri3[facing], normals[facing]):
            projected = np.column_stack((triangle @ right, -(triangle @ up)))
            depth = float(np.mean(triangle @ view))
            shade = 0.68 + 0.32 * max(0.0, float(normal @ light))
            shaded = tuple(max(0, min(255, int(channel * shade))) for channel in color)
            target.append((depth, projected, shaded))
            projected_all.append(projected)

    all_points = np.vstack(projected_all)
    low = all_points.min(axis=0)
    high = all_points.max(axis=0)
    canvas = (1500, 1000)
    margin = 110
    scale = min(
        (canvas[0] - 2 * margin) / max(high[0] - low[0], 1e-6),
        (canvas[1] - 2 * margin - 100) / max(high[1] - low[1], 1e-6),
    )
    offset = np.array(
        [
            (canvas[0] - (high[0] - low[0]) * scale) / 2.0 - low[0] * scale,
            100.0 + (canvas[1] - 175 - (high[1] - low[1]) * scale) / 2.0 - low[1] * scale,
        ]
    )
    image = Image.new("RGB", canvas, (247, 249, 252))
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    draw.text((45, 28), title, fill=(30, 40, 54), font=font)
    for collection in (base_triangles, overlays):
        for _depth, projected, color in sorted(collection, key=lambda item: item[0]):
            points = [
                (float(x * scale + offset[0]), float(y * scale + offset[1]))
                for x, y in projected
            ]
            draw.polygon(points, fill=color)
    draw.text((45, 955), footer, fill=(30, 40, 54), font=font)
    image.save(path)


def render_previews(
    package: PackageSpec,
    output_dir: Path,
    meshes: dict[str, trimesh.Trimesh],
    supports: dict[str, list[trimesh.Trimesh]],
    anchors: dict[str, list[trimesh.Trimesh]],
) -> list[str]:
    names: list[str] = []
    for model in package.models:
        # Keep preview paths comfortably below the legacy Windows MAX_PATH
        # limit even inside the descriptive OneDrive testbed hierarchy.
        prefix = model.key
        top_name = f"{prefix}_Top_Preview.png"
        underside_name = f"{prefix}_Underside_Preview.png"
        assembly_name = f"{prefix}_Assembly_Preview.png"
        render_isometric(
            [(meshes[model.key], (166, 180, 194))],
            output_dir / assembly_name,
            f"{model.display_name.upper()} - ASSEMBLY REFERENCE",
            "Use with the unchanged mechanism and accessory parts included in this package.",
        )
        render_isometric(
            [(meshes[model.key], (174, 184, 194))],
            output_dir / top_name,
            f"{model.display_name.upper()} - PRINTABLE BASE",
            "Exact current mechanism retained; only support/anchor and 3.6 mm path regions changed.",
        )
        support_overlay = trimesh.util.concatenate([item.copy() for item in supports[model.key]])
        anchor_overlay = trimesh.util.concatenate([item.copy() for item in anchors[model.key]])
        render_isometric(
            [
                (meshes[model.key], (174, 184, 194)),
                (support_overlay, (82, 151, 104)),
                (anchor_overlay, (62, 113, 168)),
            ],
            output_dir / underside_name,
            f"{model.display_name.upper()} - SUPPORTLESS UNDERSIDE",
            f"Green = {len(model.support_centers)} full roof supports; blue = {len(model.clutch_centers)} open C anchors.",
            underside=True,
            overlay_count=2,
        )
        names.extend([assembly_name, top_name, underside_name])
    for stale in output_dir.glob("*_Preview.png"):
        if stale.name not in names:
            stale.unlink()
    return names


def write_package_pass_marker(
    package: PackageSpec,
    output_dir: Path,
    checks: dict[str, dict[str, object]],
) -> str:
    name = "FINAL_PACKAGE_PASS.md"
    lines = [
        f"# FINAL PASS — {package.display_name}",
        "",
        "Stable output marker: every model below passed the exact exported-and-reloaded geometry gate.",
        "The packaging stage separately byte-compares every named artifact and the website-download ZIP copy.",
        "",
    ]
    for model in package.models:
        item = checks[model.key]
        lines.append(
            f"- `{model.key}`: PASS — supports {item['support_count']}; open Coupon-F bores/C anchors {item['clutch_count']}; M3 nut paths {item['m3_nut_loading_path_count']}; watertight one-component STL."
        )
    lines.extend(
        [
            "",
            "Common cardboard path: 3.60 x 1.80 mm. Recommended coupon choice: 3.60 mm.",
            "Physical pilot status: still required before classroom quantities.",
            "",
        ]
    )
    (output_dir / name).write_text("\n".join(lines), encoding="utf-8")
    return name


def write_validation(
    package: PackageSpec,
    output_dir: Path,
    checks: dict[str, dict[str, object]],
    package_exact: bool,
    public_exact: bool,
) -> tuple[str, str]:
    json_name = "MESH_AND_CLEARANCE_VALIDATION.json"
    md_name = "MESH_AND_CLEARANCE_VALIDATION.md"
    payload = {
        "package": package.display_name,
        "version": package.version,
        "common_standard": {
            "support_diameter_mm": 5.20,
            "support_height_mm": 2.85,
            "anchor_diameter_mm": 6.00,
            "anchor_height_mm": 0.60,
            "anchor_notch_mm": [1.55, 4.20],
            "cardboard_capsule_mm": [3.60, 1.80],
            "coupon_sizes_mm": [3.20, 3.40, 3.60],
            "recommended_coupon_size_mm": 3.60,
            "delta_kernel_localization_envelope_mm": DELTA_KERNEL_ENVELOPE,
            "nominal_m3_nut_sweep_mm": [5.50, 2.40],
            "localized_m3_clearance_cutter_mm": [5.55, 2.45],
        },
        "models": checks,
        "package_embeds_exact_files": package_exact,
        "public_download_bytes_match_package": public_exact,
        "all_required_checks_pass": bool(
            all(item["all_required_checks_pass"] for item in checks.values())
            and package_exact
            and public_exact
        ),
    }
    (output_dir / json_name).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    lines = [
        f"# {package.display_name} mesh and clearance validation",
        "",
        "All geometry checks use the exact STL after export and reload.",
        "",
    ]
    for model in package.models:
        item = checks[model.key]
        lines.extend(
            [
                f"## {model.display_name}",
                "",
                f"- Watertight / winding-consistent / one component: `{item['watertight']}` / `{item['winding_consistent']}` / `{item['components']}`",
                f"- Full supports: `{item['support_count']}` at `5.20 x 2.85 mm`; dense probes pass: `{item['all_safe_support_disks_solid_to_z_2p84']}`",
                f"- Open Coupon-F bores / aligned C anchors: `{item['clutch_count']}` / `{item['c_anchor_count']}`",
                f"- Clutch centerlines open: `{item['all_coupon_f_centerlines_open']}`",
                f"- Anchor material/notches/alignment pass: `{item['anchor_material_present_through_z_0p59']}` / `{item['anchor_notches_open_and_split_aligned']}` / `{item['c_anchor_direction']}`",
                f"- Body and tab LEGO seating disks open: `{item['all_body_stud_clearance_disks_open']}` / `{item['all_tab_continuation_clearance_disks_open']}`",
                f"- Two dense 3.6 x 1.8 mm path probes pass: `{item['all_3p6x1p8_cardboard_capsules_open_dense']}`",
                f"- Source/final M3 screw probes open: `{item['source_m3_screw_probes_open']}` / `{item['output_m3_screw_probes_open']}`",
                f"- Source/final M3 nut-volume probes open: `{item['source_m3_nut_volume_probes_open']}` / `{item['output_m3_nut_volume_probes_open']}`",
                f"- Indexed nominal M3 nut sweep angle/collisions after rebuild: `{item['m3_nut_index_angle_deg']}` / `{item['final_nominal_m3_nut_sweep_collision_mm3']}`",
                f"- Full nominal M3 nut sweeps clear: `{item['all_final_nominal_m3_nut_sweeps_zero']}`",
                f"- Added/removed delta localization pass: `{item['addition_delta_localized_to_supports_and_anchors']}` / `{item['removal_delta_localized_to_3p6_capsules_or_indexed_m3_clearance']}`",
                f"- No addition above Z=2.85 mm: `{item['no_added_geometry_above_z_2p85']}`",
                f"- Upper geometry preserved except localized cardboard/M3 path clearances: `{item['upper_geometry_preserved_except_local_3p6_and_m3_path_clearances']}`",
                f"- All required model checks pass: `{item['all_required_checks_pass']}`",
                "",
            ]
        )
    lines.extend(
        [
            f"- ZIP embeds exact current files: `{package_exact}`",
            f"- Website-download copy matches ZIP bytes: `{public_exact}`",
            f"- All package checks pass: `{payload['all_required_checks_pass']}`",
            "",
            "A physical pilot remains required before classroom quantities.",
            "",
        ]
    )
    (output_dir / md_name).write_text("\n".join(lines), encoding="utf-8")
    return json_name, md_name


def create_zip(
    package: PackageSpec,
    output_dir: Path,
    filenames: list[str],
) -> Path:
    zip_path = output_dir / package.zip_name
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in filenames:
            archive.write(output_dir / name, f"{package.archive_root}/{name}")
        archive.write(Path(__file__), f"{package.archive_root}/SOURCE/{Path(__file__).name}")
    return zip_path


def zip_embeds_exact_files(
    package: PackageSpec,
    output_dir: Path,
    filenames: list[str],
) -> bool:
    zip_path = output_dir / package.zip_name
    with zipfile.ZipFile(zip_path) as archive:
        return all(
            archive.read(f"{package.archive_root}/{name}") == (output_dir / name).read_bytes()
            for name in filenames
        ) and archive.read(
            f"{package.archive_root}/SOURCE/{Path(__file__).name}"
        ) == Path(__file__).read_bytes()


def public_copy_exact(zip_path: Path) -> bool:
    public_path = DOWNLOADS / zip_path.name
    shutil.copyfile(zip_path, public_path)
    return public_path.read_bytes() == zip_path.read_bytes()


def build_package(package: PackageSpec) -> dict[str, object]:
    output_dir = OUTPUT_ROOT / package.directory_name
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / COUPON_NAME).write_bytes(COUPON_SOURCE.read_bytes())

    meshes: dict[str, trimesh.Trimesh] = {}
    supports: dict[str, list[trimesh.Trimesh]] = {}
    anchors: dict[str, list[trimesh.Trimesh]] = {}
    checks: dict[str, dict[str, object]] = {}
    source_hashes: dict[str, str] = {}
    generated_names: list[str] = []

    for model in package.models:
        print(f"building|{model.key}", flush=True)
        (
            source,
            mesh,
            model_supports,
            model_anchors,
            _cuts,
            nut_clearance_tools,
            source_nut_collisions,
            source_hash,
        ) = build_model(model, output_dir)
        meshes[model.key] = mesh
        supports[model.key] = model_supports
        anchors[model.key] = model_anchors
        source_hashes[model.key] = source_hash
        item = validate_model(
            model,
            source,
            mesh,
            nut_clearance_tools,
            source_nut_collisions,
        )
        item["source_zip_name"] = model.source_zip_name
        item["source_member"] = model.source_member
        item["source_stl_sha256"] = source_hash
        item["output_stl_sha256"] = sha256_file(output_dir / model.output_stl_name)
        if len(model.support_centers) != package.expected_supports:
            raise RuntimeError(f"Unexpected support count for {model.key}")
        if len(model.clutch_centers) != package.expected_clutches:
            raise RuntimeError(f"Unexpected clutch count for {model.key}")
        if not item["all_required_checks_pass"]:
            (output_dir / f"FAILED_{model.key}_VALIDATION.json").write_text(
                json.dumps(item, indent=2) + "\n", encoding="utf-8"
            )
            failed = [key for key, value in item.items() if isinstance(value, bool) and not value]
            raise RuntimeError(f"{model.display_name} failed loudly: {', '.join(failed)}")
        (output_dir / f"FAILED_{model.key}_VALIDATION.json").unlink(missing_ok=True)
        checks[model.key] = item
        generated_names.append(model.output_stl_name)
        print(
            f"validated|{model.key}|supports={len(model.support_centers)}|"
            f"clutches={len(model.clutch_centers)}|faces={len(mesh.faces)}",
            flush=True,
        )

    extras = extract_extras(package, output_dir)
    lineage_name = write_source_lineage(package, output_dir, source_hashes)
    readme_name = write_readme(package, output_dir, meshes)
    dimensions_name = write_dimensions(package, output_dir, meshes)
    preview_names = render_previews(package, output_dir, meshes, supports, anchors)
    pass_marker_name = write_package_pass_marker(package, output_dir, checks)
    generated_names.extend(
        extras
        + [COUPON_NAME, lineage_name, readme_name, dimensions_name, pass_marker_name]
        + preview_names
    )

    json_name, md_name = write_validation(package, output_dir, checks, False, False)
    generated_names.extend([json_name, md_name])
    create_zip(package, output_dir, generated_names)
    package_exact = zip_embeds_exact_files(package, output_dir, generated_names)
    write_validation(package, output_dir, checks, package_exact, False)
    create_zip(package, output_dir, generated_names)
    package_exact = zip_embeds_exact_files(package, output_dir, generated_names)
    public_exact = public_copy_exact(output_dir / package.zip_name)
    write_validation(package, output_dir, checks, package_exact, public_exact)
    create_zip(package, output_dir, generated_names)
    package_exact = zip_embeds_exact_files(package, output_dir, generated_names)
    public_exact = public_copy_exact(output_dir / package.zip_name)

    if not package_exact or not public_exact:
        raise RuntimeError(f"Byte-exact packaging failed: {package.zip_name}")
    validation = json.loads((output_dir / json_name).read_text(encoding="utf-8"))
    if not validation["all_required_checks_pass"]:
        raise RuntimeError(f"Final package validation failed: {package.zip_name}")

    return {
        "package": package.display_name,
        "zip": str(output_dir / package.zip_name),
        "public_zip": str(DOWNLOADS / package.zip_name),
        "sha256": sha256_file(output_dir / package.zip_name),
        "models": {
            key: {
                "supports": value["support_count"],
                "clutches": value["clutch_count"],
                "m3_paths": value["m3_nut_loading_path_count"],
                "watertight": value["watertight"],
                "components": value["components"],
                "pass": value["all_required_checks_pass"],
            }
            for key, value in checks.items()
        },
        "package_exact": package_exact,
        "public_exact": public_exact,
    }


def write_root_pass_marker(summary: dict[str, object]) -> None:
    expected = {package.key for package in PACKAGES}
    if not expected.issubset(summary):
        return
    lines = [
        "# FINAL BUILD PASS — Sensor & Input Supportless 3.6 mm Upgrades",
        "",
        "All six versioned packages passed their exact exported-STL and byte-exact packaging gates.",
        "",
    ]
    for package in PACKAGES:
        item = summary[package.key]
        if not isinstance(item, dict):
            raise RuntimeError(f"Invalid summary entry: {package.key}")
        if not item.get("package_exact") or not item.get("public_exact"):
            raise RuntimeError(f"Non-final summary entry: {package.key}")
        lines.extend(
            [
                f"## {package.display_name}",
                "",
                f"- Package: `{package.zip_name}`",
                f"- SHA-256: `{item['sha256']}`",
            ]
        )
        models = item.get("models", {})
        for model_key, model_result in models.items():
            lines.append(
                f"- `{model_key}`: PASS; supports {model_result['supports']}; "
                f"open Coupon-F/C anchors {model_result['clutches']}; "
                f"M3 paths {model_result['m3_paths']}"
            )
        lines.append("")
    lines.extend(
        [
            "Website catalog code was not changed by this build.",
            "Every website-download ZIP copy is byte-identical to its testbed package.",
            "Physical pilot prints remain required before classroom quantities.",
            "",
        ]
    )
    (OUTPUT_ROOT / "FINAL_BUILD_PASS.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    if not COUPON_SOURCE.exists():
        raise FileNotFoundError(COUPON_SOURCE)
    for package in PACKAGES:
        for model in package.models:
            source_zip = DOWNLOADS / model.source_zip_name
            if not source_zip.exists():
                raise FileNotFoundError(source_zip)

    requested = set(sys.argv[1:])
    known = {package.key for package in PACKAGES}
    unknown = requested - known
    if unknown:
        raise SystemExit(f"Unknown package key(s): {', '.join(sorted(unknown))}")
    selected = [package for package in PACKAGES if not requested or package.key in requested]

    summary_path = OUTPUT_ROOT / "BUILD_SUMMARY.json"
    if summary_path.exists():
        try:
            summary: dict[str, object] = json.loads(summary_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            summary = {}
    else:
        summary = {}
    for package in selected:
        print(f"package_start|{package.key}", flush=True)
        summary[package.key] = build_package(package)
        print(f"package_pass|{package.key}|{package.zip_name}", flush=True)

    summary_path.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    write_root_pass_marker(summary)
    print(f"all_sensor_input_revisions_pass|summary={summary_path}", flush=True)


if __name__ == "__main__":
    main()

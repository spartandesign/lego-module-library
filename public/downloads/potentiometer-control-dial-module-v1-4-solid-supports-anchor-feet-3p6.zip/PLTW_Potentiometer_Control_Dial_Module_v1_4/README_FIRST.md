# PLTW Potentiometer Control Dial Module v1.4

This is the unified LEGO-and-cardboard revision. It starts from the exact
current dual-mount/final website geometry, keeps the upper mechanism and all
unchanged accessory parts, and updates only the underside support system and
the existing cardboard-fastener openings.

## Printable base choices

- `PLTW_Potentiometer_v1_4_SolidSupports_AnchorFeet_3p6x1p8.stl` — 11 solid supports, 4 open Coupon-F bores with split-aligned C anchors; overall 48.00 x 65.00 x 38.00 mm

## Supportless-printing standard

- Every safe non-clutch center is a full 5.20 mm-diameter x 2.85 mm-high solid
  roof-support post.
- Every intended Coupon-F clutch bore stays open and receives a 6.00 mm x
  0.60 mm C-shaped first-layer anchor.
- C-anchor notches follow the exact existing split direction.
- Panel, bushing opening, terminal labels, knobs, and fit coupons are unchanged.
- All three +X M3 nut-loading paths are preserved. Dense screw-bore and full nut-corridor volume probes pass on both the source and final STL.
- PLTW Potentiometer Control Dial Module v1.4: indexed M3 nut angle 30 degrees; localized 5.55-AF x 2.45 mm corrective sweeps: 0.

The indexed hardware gate uses a full convex sweep of a nominal 5.50 mm
across-flats x 2.40 mm-thick M3 nut, not just a centerline. Only the flex
paddle's inherited tunnels collide: each receives a localized 5.55 mm
across-flats x 2.45 mm clearance sweep at the source-keyed 0-degree index.
Door and universal pressure pass at 0 degrees; photocell and potentiometer pass
at 30 degrees and receive no M3 clearance cut.

The universal-pressure base has the tightest roof junction: its posts reach
Z=2.85 mm and overlap the Z=2.80 mm roof by exactly 0.05 mm. The exported STL
is required to reload watertight and as one component; no disconnected piece
is silently discarded.

## Cardboard mounting

- Two open brick tabs centered at (-4,-24) and (-4,24) mm.
- Both existing openings are now 3.6 x 1.8 mm rounded capsules. Only the 0.1 mm
  extension at each end of the former 3.4 mm long axis was removed.
- The included coupon contains 3.2, 3.4, and 3.6 mm choices. Start with 3.6 mm
  for this revision, then confirm with the classroom brass fastener, printer,
  and cardboard before producing a class set.
- For open brick tabs, insert from the top, pass through the cardboard, spread
  the legs underneath, and cover exposed metal.

## Printing

- PLA, 0.4 mm nozzle, 0.20 mm layer height
- Four wall loops and approximately 20% gyroid infill
- LEGO underside flat on the build plate
- Supports off; raft off
- Use a small outer brim only if the broad base corners lift

## Validation and pilot status

The exact exported-and-reloaded STL files are checked for watertightness,
winding consistency, one connected component, support and anchor counts,
dense solid-post coverage, open Coupon-F centerlines and LEGO seating disks,
3.6 x 1.8 mm paths, and preserved M3 loading volumes where applicable.
Boolean source/output deltas must remain inside the widened slit tools and a
documented 0.35 mm kernel re-triangulation envelope around the exact support
and anchor construction tools, proving the rest of the upper geometry is
unchanged.
The ZIP is also byte-compared against every packaged file and the copy placed
in the website downloads directory.

A physical pilot remains required with the actual LEGO plate, sensor,
mechanism, M3 hardware where applicable, cardboard, and brass fasteners before
classroom quantities.

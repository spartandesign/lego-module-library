from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import sys
import zipfile
from pathlib import Path


CAD_DEPS = Path(r"C:\Users\trira\.codex\tmp\cad_pydeps")
sys.path.insert(0, str(CAD_DEPS))

import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont


OUTPUT_DIR = Path(__file__).resolve().parent
LATEST_DIR = OUTPUT_DIR.parent
FAMILY_DIR = LATEST_DIR / "18_All_Modules_InternalBrad_3Dot_v0_1"
SOURCE_V53 = (
    FAMILY_DIR
    / "STL"
    / "PLTW_Microbit_Stand_v5_3_InternalBrad_FFit_3p4x1p8_8p5Head.stl"
)
SOURCE_PACKAGE = (
    FAMILY_DIR
    / "packages"
    / "microbit-original-guide-stand-v5-3-dual-mount-3p4.zip"
)

OUTPUT_STL = OUTPUT_DIR / (
    "PLTW_Microbit_Stand_v5_4_InternalBrad_FFit_"
    "AnchoredCouponFFeet_3p4x1p8.stl"
)
OUTPUT_ZIP = OUTPUT_DIR / (
    "PLTW_Microbit_Original_Guide_Stand_v5_4_"
    "Internal_Paths_Anchor_Feet.zip"
)

GUIDE_NAME = "Microbit_Alligator_Clip_Guide_v2.stl"
ATTRIBUTION_NAME = "THIRD_PARTY_ATTRIBUTION.md"
COUPON_NAME = "PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl"

ANCHOR_FOOT_RADIUS = 3.00
ANCHOR_FOOT_HEIGHT = 0.60
ANCHOR_NOTCH_LENGTH = 4.20
ANCHOR_NOTCH_WIDTH = 1.55

# Circle-fitted centers from the actual v5.3 mesh, not nominal grid positions.
CLUTCH_CENTERS = [
    (-16.05, -32.00),
    (-16.05, 0.10),
    (-16.05, 31.90),
    (16.05, -32.00),
    (16.05, 0.10),
    (16.05, 31.90),
]

TUBE_GRID = [
    (x, y)
    for x in (-16.0, -8.0, 0.0, 8.0, 16.0)
    for y in (-32.0, -24.0, -16.0, -8.0, 0.0, 8.0, 16.0, 24.0, 32.0)
]
NON_CLUTCH_CENTERS = [
    (x, y)
    for x, y in TUBE_GRID
    if not (abs(abs(x) - 16.0) < 0.2 and min(abs(y + 32.0), abs(y), abs(y - 32.0)) < 0.2)
]
STUD_CENTERS = [
    (x, y)
    for x in (-20.0, -12.0, -4.0, 4.0, 12.0, 20.0)
    for y in (-36.0, -28.0, -20.0, -12.0, -4.0, 4.0, 12.0, 20.0, 28.0, 36.0)
]
BRAD_CENTERS = [(12.0, -12.0), (12.0, 12.0)]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cylinder_at(
    x: float,
    y: float,
    radius: float,
    height: float,
    z0: float = 0.0,
    sections: int = 64,
) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(
        radius=radius,
        height=height,
        sections=sections,
    )
    mesh.apply_translation([x, y, z0 + height / 2.0])
    return mesh


def inward_direction(x: float, y: float) -> tuple[float, float]:
    length = math.hypot(x, y)
    return (-x / length, -y / length)


def coupon_f_anchor_foot(x: float, y: float) -> trimesh.Trimesh:
    """Create a first-layer C pad aligned to the ring's measured inward split."""
    direction_x, direction_y = inward_direction(x, y)
    angle = math.atan2(direction_y, direction_x)

    disk = cylinder_at(
        x,
        y,
        ANCHOR_FOOT_RADIUS,
        ANCHOR_FOOT_HEIGHT,
    )
    notch = trimesh.creation.box(
        extents=[
            ANCHOR_NOTCH_LENGTH,
            ANCHOR_NOTCH_WIDTH,
            ANCHOR_FOOT_HEIGHT + 0.40,
        ]
    )
    notch.apply_transform(
        trimesh.transformations.rotation_matrix(
            angle,
            [0.0, 0.0, 1.0],
        )
    )
    notch.apply_translation(
        [
            x + direction_x * 2.0,
            y + direction_y * 2.0,
            ANCHOR_FOOT_HEIGHT / 2.0,
        ]
    )
    return trimesh.boolean.difference(
        [disk, notch],
        engine="manifold",
    )


def extract_package_assets() -> dict[str, str]:
    entries = {
        GUIDE_NAME: GUIDE_NAME,
        ATTRIBUTION_NAME: ATTRIBUTION_NAME,
        (
            "CARDBOARD_DUAL_MOUNT_V5_3/"
            "PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl"
        ): COUPON_NAME,
    }
    with zipfile.ZipFile(SOURCE_PACKAGE) as archive:
        for source_name, output_name in entries.items():
            (OUTPUT_DIR / output_name).write_bytes(archive.read(source_name))
    return {
        name: sha256(OUTPUT_DIR / name)
        for name in (GUIDE_NAME, ATTRIBUTION_NAME, COUPON_NAME)
    }


def build_base() -> tuple[trimesh.Trimesh, trimesh.Trimesh, list[trimesh.Trimesh]]:
    source = trimesh.load_mesh(SOURCE_V53)
    anchor_feet = [
        coupon_f_anchor_foot(x, y)
        for x, y in CLUTCH_CENTERS
    ]
    result = trimesh.boolean.union(
        [source, *anchor_feet],
        engine="manifold",
    )
    result.remove_unreferenced_vertices()
    result.export(OUTPUT_STL)
    return source, result, anchor_feet


def evaluate_point_queries(
    mesh: trimesh.Trimesh,
    queries: dict[str, list[tuple[float, float, float]]],
) -> dict[str, list[bool]]:
    names = list(queries)
    all_points: list[tuple[float, float, float]] = []
    ranges: dict[str, tuple[int, int]] = {}
    for name in names:
        start = len(all_points)
        all_points.extend(queries[name])
        ranges[name] = (start, len(all_points))
    occupancy = [
        bool(value)
        for value in mesh.contains(np.asarray(all_points))
    ]
    return {
        name: occupancy[start:end]
        for name, (start, end) in ranges.items()
    }


def validate(
    source: trimesh.Trimesh,
    mesh: trimesh.Trimesh,
    anchor_feet: list[trimesh.Trimesh],
    asset_hashes: dict[str, str],
) -> dict[str, object]:
    anchor_material_points = []
    anchor_above_points = []
    anchor_notch_points = []
    for x, y in CLUTCH_CENTERS:
        direction_x, direction_y = inward_direction(x, y)
        perpendicular_x, perpendicular_y = -direction_y, direction_x
        material_xy = [
            (x - direction_x * 1.50, y - direction_y * 1.50),
            (x + perpendicular_x * 1.60, y + perpendicular_y * 1.60),
            (x - perpendicular_x * 1.60, y - perpendicular_y * 1.60),
        ]
        for point_x, point_y in material_xy:
            for z in (0.05, 0.30, 0.59):
                anchor_material_points.append((point_x, point_y, z))
            anchor_above_points.append((point_x, point_y, 0.61))
        for radius in (0.0, 0.75, 1.50, 2.50):
            for z in (0.05, 0.30, 0.59):
                anchor_notch_points.append(
                    (
                        x + direction_x * radius,
                        y + direction_y * radius,
                        z,
                    )
                )

    tube_points = [
        (x, y, z)
        for x, y in TUBE_GRID
        for z in (0.05, 0.30, 0.59, 0.61, 1.40, 2.30)
    ]
    non_clutch_points = [
        (x, y, z)
        for x, y in NON_CLUTCH_CENTERS
        for z in (0.05, 0.30, 0.59, 0.61, 1.40, 2.30)
    ]
    stud_points = [(x, y, 1.40) for x, y in STUD_CENTERS]
    brad_slit_points = [
        (x, y + offset, z)
        for x, y in BRAD_CENTERS
        for offset in (-1.20, 0.0, 1.20)
        for z in (0.10, 1.40, 3.00, 5.50, 7.90)
    ]
    head_pocket_points = [
        (x + offset_x, y + offset_y, z)
        for x, y in BRAD_CENTERS
        for offset_x, offset_y in ((0.0, 0.0), (3.0, 0.0), (0.0, 3.0))
        for z in (5.50, 7.90)
    ]
    pocket_floor_points = [
        (x + offset_x, y + offset_y, 5.00)
        for x, y in BRAD_CENTERS
        for offset_x, offset_y in ((3.0, 0.0), (0.0, 3.0))
    ]

    occupancy = evaluate_point_queries(
        mesh,
        {
            "anchor_material": anchor_material_points,
            "anchor_above": anchor_above_points,
            "anchor_notches": anchor_notch_points,
            "tube_bores": tube_points,
            "non_clutch_bores": non_clutch_points,
            "studs": stud_points,
            "brad_slits": brad_slit_points,
            "head_pockets": head_pocket_points,
            "pocket_floors": pocket_floor_points,
        },
    )

    components = len(mesh.split(only_watertight=False))
    anchor_geometry_max_z = max(
        float(foot.bounds[1, 2])
        for foot in anchor_feet
    )
    anchor_geometry_confined = anchor_geometry_max_z <= 0.600001
    checks: dict[str, object] = {
        "watertight": bool(mesh.is_watertight),
        "winding_consistent": bool(mesh.is_winding_consistent),
        "components": components,
        "faces": int(len(mesh.faces)),
        "extents_mm": [round(float(value), 3) for value in mesh.extents],
        "bounds_mm": [
            [round(float(value), 3) for value in row]
            for row in mesh.bounds
        ],
        "anchor_feet_expected": len(CLUTCH_CENTERS),
        "anchor_foot_material_present_through_z_0p59": all(
            occupancy["anchor_material"]
        ),
        "anchor_foot_material_ends_before_z_0p61": not any(
            occupancy["anchor_above"]
        ),
        "anchor_notches_open_toward_center": not any(
            occupancy["anchor_notches"]
        ),
        "all_45_tube_centerlines_open": not any(
            occupancy["tube_bores"]
        ),
        "all_39_non_clutch_tube_centerlines_open": not any(
            occupancy["non_clutch_bores"]
        ),
        "all_60_stud_centers_open": not any(
            occupancy["studs"]
        ),
        "both_3p4x1p8_brad_slits_open": not any(
            occupancy["brad_slits"]
        ),
        "both_top_open_head_pockets_clear": not any(
            occupancy["head_pockets"]
        ),
        "solid_floor_retained_around_slits": all(
            occupancy["pocket_floors"]
        ),
        "source_extents_preserved": bool(
            np.allclose(mesh.extents, source.extents, atol=1e-6)
        ),
        "added_anchor_volume_mm3": round(
            float(mesh.volume - source.volume),
            3,
        ),
        "anchor_geometry_max_z_mm": round(anchor_geometry_max_z, 3),
        "anchor_geometry_confined_to_z_0p60": bool(
            anchor_geometry_confined
        ),
        "original_geometry_above_z_0p60_retained": bool(
            anchor_geometry_confined
        ),
        "brad_centers_mm": [[12.0, -12.0], [12.0, 12.0]],
        "brad_slit_mm": [3.4, 1.8],
        "head_pocket_diameter_mm": 8.5,
        "actual_head_pocket_depth_mm_approx": 2.85,
        "asset_sha256": asset_hashes,
    }

    required = (
        checks["watertight"]
        and checks["winding_consistent"]
        and components == 1
        and checks["anchor_foot_material_present_through_z_0p59"]
        and checks["anchor_foot_material_ends_before_z_0p61"]
        and checks["anchor_notches_open_toward_center"]
        and checks["all_45_tube_centerlines_open"]
        and checks["all_39_non_clutch_tube_centerlines_open"]
        and checks["all_60_stud_centers_open"]
        and checks["both_3p4x1p8_brad_slits_open"]
        and checks["both_top_open_head_pockets_clear"]
        and checks["solid_floor_retained_around_slits"]
        and checks["source_extents_preserved"]
        and checks["anchor_geometry_confined_to_z_0p60"]
    )
    checks["all_required_checks_pass"] = bool(required)
    return checks


def write_validation(checks: dict[str, object]) -> None:
    (OUTPUT_DIR / "MESH_AND_CLEARANCE_VALIDATION.json").write_text(
        json.dumps(checks, indent=2) + "\n",
        encoding="utf-8",
    )
    lines = [
        "# micro:bit stand v5.4 mesh and clearance validation",
        "",
        f"- Watertight: `{checks['watertight']}`",
        f"- Winding consistent: `{checks['winding_consistent']}`",
        f"- Connected components: `{checks['components']}`",
        f"- Mesh extents: `{checks['extents_mm']} mm`",
        f"- Coupon-F C-shaped anchor feet: `{checks['anchor_feet_expected']}`",
        f"- Anchor material present through Z=0.59 mm: `{checks['anchor_foot_material_present_through_z_0p59']}`",
        f"- Anchor material ends before Z=0.61 mm: `{checks['anchor_foot_material_ends_before_z_0p61']}`",
        f"- Added anchor geometry is confined to Z=0.60 mm: `{checks['anchor_geometry_confined_to_z_0p60']}`",
        f"- All inward anchor notches open: `{checks['anchor_notches_open_toward_center']}`",
        f"- All 45 tube centerlines open: `{checks['all_45_tube_centerlines_open']}`",
        f"- All 39 non-clutch tube centerlines open: `{checks['all_39_non_clutch_tube_centerlines_open']}`",
        f"- All 60 LEGO stud centers open: `{checks['all_60_stud_centers_open']}`",
        f"- Both 3.4 x 1.8 mm internal brad paths open: `{checks['both_3p4x1p8_brad_slits_open']}`",
        f"- Both top-open head pockets clear: `{checks['both_top_open_head_pockets_clear']}`",
        f"- Solid pocket floor retained outside each slit: `{checks['solid_floor_retained_around_slits']}`",
        f"- Package embeds the exact exported STL: `{checks.get('package_embeds_exact_stl', False)}`",
        f"- All required automated checks pass: `{checks['all_required_checks_pass']}`",
        "",
        "The v5.3 cardboard paths are retained because their vertical through-cuts and top-open head pockets already print without support.",
        "The only added geometry is below Z=0.60 mm at the six Coupon-F rings; the exact-guide cradle and stand geometry are unchanged.",
        "These checks do not replace a pilot print with the classroom LEGO plate, exact guide, micro:bit, cardboard, and brass fasteners.",
        "",
    ]
    (OUTPUT_DIR / "MESH_AND_CLEARANCE_VALIDATION.md").write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def write_dimensions(mesh: trimesh.Trimesh) -> None:
    rows = [
        ("Feature", "Value"),
        ("LEGO footprint", "6 x 10 studs / 48 x 80 mm nominal"),
        (
            "Overall stand",
            f"{mesh.extents[0]:.1f} x {mesh.extents[1]:.1f} x {mesh.extents[2]:.1f} mm",
        ),
        ("Exact guide", "5.85 x 56.0 x 11.2 mm included STL"),
        ("Open-top cradle", "6.7 x 56.8 mm original v5.1 geometry retained"),
        ("LEGO interface", "Six Coupon-F split clutch tubes with C anchor feet"),
        ("Original underside tube bores", "All 45 centerlines remain open"),
        ("Non-clutch support tubes", "39 hollow original tubes retained"),
        ("Anchor foot diameter x height", "6.00 x 0.60 mm"),
        ("Anchor notch", "4.20 x 1.55 mm, aligned with each inward split"),
        ("Cardboard paths", "Two top-open internal recessed paths"),
        ("Path centers", "X = 12 mm; Y = -12 mm and +12 mm"),
        ("Brass-fastener slit", "3.4 x 1.8 mm capsule"),
        ("Head pocket", "8.5 mm diameter x approximately 2.85 mm actual depth"),
        ("Print orientation", "LEGO underside on the build plate"),
        ("Supports", "Off"),
    ]
    with (OUTPUT_DIR / "PLTW_Microbit_Stand_v5_4_Dimensions.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        csv.writer(handle).writerows(rows)


def render_isometric(
    specs: list[tuple[trimesh.Trimesh, tuple[int, int, int]]],
    filename: str,
    title: str,
    footer: str,
    overlay_count: int = 0,
) -> None:
    view = np.array([1.0, -1.35, 0.90])
    view /= np.linalg.norm(view)
    right = np.cross(view, np.array([0.0, 0.0, 1.0]))
    right /= np.linalg.norm(right)
    up = np.cross(right, view)
    up /= np.linalg.norm(up)
    light = np.array([0.30, -0.45, 0.84])
    light /= np.linalg.norm(light)

    triangles = []
    overlay_triangles = []
    projected_all = []
    overlay_start = len(specs) - overlay_count
    for spec_index, (mesh, color) in enumerate(specs):
        triangle_vertices = mesh.vertices[mesh.faces]
        normals = np.cross(
            triangle_vertices[:, 1] - triangle_vertices[:, 0],
            triangle_vertices[:, 2] - triangle_vertices[:, 0],
        )
        lengths = np.linalg.norm(normals, axis=1)
        valid = lengths > 1e-9
        normals[valid] /= lengths[valid, None]
        facing = normals @ view > -0.10
        for triangle, normal in zip(
            triangle_vertices[facing],
            normals[facing],
        ):
            projected = np.column_stack(
                (triangle @ right, -(triangle @ up))
            )
            depth = float(np.mean(triangle @ view))
            shade = 0.70 + 0.30 * max(0.0, float(normal @ light))
            shaded = tuple(
                max(0, min(255, int(channel * shade)))
                for channel in color
            )
            target = (
                overlay_triangles
                if spec_index >= overlay_start and overlay_count
                else triangles
            )
            target.append((depth, projected, shaded))
            projected_all.append(projected)

    all_points = np.vstack(projected_all)
    low = all_points.min(axis=0)
    high = all_points.max(axis=0)
    canvas = (1500, 1000)
    margin = 110
    scale = min(
        (canvas[0] - 2 * margin) / (high[0] - low[0]),
        (canvas[1] - 2 * margin - 100) / (high[1] - low[1]),
    )
    offset = np.array(
        [
            (canvas[0] - (high[0] - low[0]) * scale) / 2
            - low[0] * scale,
            100
            + (canvas[1] - 175 - (high[1] - low[1]) * scale) / 2
            - low[1] * scale,
        ]
    )

    image = Image.new("RGB", canvas, (247, 249, 252))
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    draw.text((45, 28), title, fill=(30, 40, 54), font=font)
    for _, projected, color in sorted(
        triangles,
        key=lambda item: item[0],
    ):
        points = [
            (
                float(x * scale + offset[0]),
                float(y * scale + offset[1]),
            )
            for x, y in projected
        ]
        draw.polygon(points, fill=color)
    # Colored technical callouts are drawn last so coplanar final-model faces
    # cannot create a false z-fighting pattern in the static preview.
    for _, projected, color in sorted(
        overlay_triangles,
        key=lambda item: item[0],
    ):
        points = [
            (
                float(x * scale + offset[0]),
                float(y * scale + offset[1]),
            )
            for x, y in projected
        ]
        draw.polygon(points, fill=color)
    draw.text((45, 955), footer, fill=(30, 40, 54), font=font)
    image.save(OUTPUT_DIR / filename)


def simplified(mesh: trimesh.Trimesh, face_count: int = 90000) -> trimesh.Trimesh:
    if len(mesh.faces) <= face_count:
        return mesh.copy()
    try:
        return mesh.simplify_quadric_decimation(
            face_count=face_count,
            aggression=4,
        )
    except ModuleNotFoundError:
        # The optional fast-simplification wheel is not required for rebuilding
        # the CAD. Rendering the full mesh is slower but preserves every detail.
        return mesh.copy()


def create_microbit_preview() -> trimesh.Trimesh:
    board = trimesh.creation.box(extents=[1.60, 52.0, 43.0])
    board.apply_translation([0.0, 0.0, 34.25])
    return board


def render_previews(
    base: trimesh.Trimesh,
    anchor_feet: list[trimesh.Trimesh],
) -> None:
    display_base = simplified(base)
    guide = trimesh.load_mesh(OUTPUT_DIR / GUIDE_NAME)
    guide.apply_translation([-90.0, -90.0, 8.50])
    board = create_microbit_preview()

    render_isometric(
        [
            (display_base, (174, 184, 194)),
            (guide, (225, 155, 62)),
            (board, (55, 122, 96)),
        ],
        "PLTW_Microbit_Stand_v5_4_Assembly_Preview.png",
        "MICRO:BIT STAND v5.4 - INTERNAL PATHS + ANCHOR FEET",
        "Exact guide retained; compact top-open 3.4 x 1.8 mm cardboard paths; supports off.",
    )

    render_isometric(
        [(display_base, (174, 184, 194))],
        "PLTW_Microbit_Stand_v5_4_Top_Preview.png",
        "MICRO:BIT STAND v5.4 - PRINTABLE STAND",
        "Print upright with the LEGO underside on the build plate; keep supports and raft off.",
    )

    underside = display_base.copy()
    rotation = trimesh.transformations.rotation_matrix(
        math.radians(180.0),
        [1.0, 0.0, 0.0],
    )
    underside.apply_transform(rotation)
    anchor_overlay = trimesh.util.concatenate(
        [foot.copy() for foot in anchor_feet]
    )
    anchor_overlay.apply_transform(rotation)
    # Lift the colored callout a hair toward the camera-facing underside so
    # the preview does not z-fight with the identical final-model surface.
    anchor_overlay.apply_translation([0.0, 0.0, 0.02])
    render_isometric(
        [
            (underside, (174, 184, 194)),
            (anchor_overlay, (65, 116, 168)),
        ],
        "PLTW_Microbit_Stand_v5_4_Underside_Preview.png",
        "MICRO:BIT STAND v5.4 - LEGO UNDERSIDE",
        "All 45 tube centerlines remain open; six Coupon-F rings gain aligned 0.60 mm C anchors.",
        overlay_count=1,
    )


def create_package() -> None:
    package_names = [
        "README_FIRST.md",
        OUTPUT_STL.name,
        GUIDE_NAME,
        ATTRIBUTION_NAME,
        COUPON_NAME,
        "PLTW_Microbit_Stand_v5_4_Dimensions.csv",
        "MESH_AND_CLEARANCE_VALIDATION.md",
        "MESH_AND_CLEARANCE_VALIDATION.json",
        "PLTW_Microbit_Stand_v5_4_Assembly_Preview.png",
        "PLTW_Microbit_Stand_v5_4_Top_Preview.png",
        "PLTW_Microbit_Stand_v5_4_Underside_Preview.png",
    ]
    prefix = "PLTW_Microbit_Original_Guide_Stand_v5_4"
    with zipfile.ZipFile(
        OUTPUT_ZIP,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for name in package_names:
            archive.write(OUTPUT_DIR / name, f"{prefix}/{name}")
        archive.write(
            Path(__file__),
            f"{prefix}/SOURCE/{Path(__file__).name}",
        )


def package_embeds_exact_stl() -> bool:
    prefix = "PLTW_Microbit_Original_Guide_Stand_v5_4"
    with zipfile.ZipFile(OUTPUT_ZIP) as archive:
        embedded = archive.read(f"{prefix}/{OUTPUT_STL.name}")
    return embedded == OUTPUT_STL.read_bytes()


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    asset_hashes = extract_package_assets()
    source, base, anchor_feet = build_base()
    checks = validate(source, base, anchor_feet, asset_hashes)
    write_dimensions(base)
    render_previews(base, anchor_feet)

    checks["package_embeds_exact_stl"] = False
    write_validation(checks)
    create_package()
    checks["package_embeds_exact_stl"] = package_embeds_exact_stl()
    write_validation(checks)
    create_package()

    print(f"output_stl={OUTPUT_STL}")
    print(f"output_zip={OUTPUT_ZIP}")
    print(f"stl_sha256={sha256(OUTPUT_STL)}")
    print(f"watertight={checks['watertight']}")
    print(f"winding={checks['winding_consistent']}")
    print(f"components={checks['components']}")
    print(f"extents_mm={checks['extents_mm']}")
    print(f"anchor_feet={checks['anchor_feet_expected']}")
    print(f"package_embeds_exact_stl={package_embeds_exact_stl()}")
    print(f"all_required_checks_pass={checks['all_required_checks_pass']}")

    if not checks["all_required_checks_pass"]:
        raise SystemExit("Required mesh or clearance validation failed")
    if not package_embeds_exact_stl():
        raise SystemExit("ZIP package STL does not match the exported STL")


if __name__ == "__main__":
    main()

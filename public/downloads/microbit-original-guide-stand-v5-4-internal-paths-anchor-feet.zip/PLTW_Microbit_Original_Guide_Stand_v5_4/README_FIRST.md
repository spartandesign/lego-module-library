# PLTW micro:bit Original-Guide Stand v5.4

This revision keeps the physically successful v5.1 exact-guide stand and the
compact v5.3 cardboard-fastener paths. It adds first-layer anchors beneath the
six Coupon-F clutch tubes so the stand can be printed upright with the LEGO
underside on the build plate and supports turned off.

## What changed

- Added one 0.60 mm C-shaped first-layer anchor foot beneath each of the six
  Coupon-F clutch tubes.
- Aligned every foot notch with the clutch tube's existing inward split.
- Kept all 45 original underside tube centerlines open, including all 39
  non-clutch support tubes; no solid plugs were added.
- Retained both internal 3.4 x 1.8 mm brass-fastener slits from v5.3.
- Retained both 8.5 mm top-open head pockets and their solid floors.
- Preserved the 48 x 80.1 mm footprint and all upper stand/cradle geometry.
- Bundled the exact `Microbit Alligator Clip Guide v2` and its original
  attribution without modification.

The internal cardboard paths already print without support: each slit is a
vertical through-cut into an existing LEGO cavity, and each head pocket opens
from the top. The pocket floor is supported by solid material below; it is not
a suspended ceiling. External tabs would only enlarge the stand and are not
needed for this design.

## Included files

- The v5.4 supportless stand STL
- `Microbit_Alligator_Clip_Guide_v2.stl`
- Third-party guide attribution
- 3.2 / 3.4 / 3.6 mm brass-fastener slit coupon
- Dimensions and automated mesh/clearance reports
- Assembly, printable-stand, and underside previews
- Rebuild source

## Printing

- Bambu A1 mini or comparable printer
- PLA with a 0.4 mm nozzle
- Bambu 0.20 mm Standard profile
- Keep the remaining process settings at their defaults
- Stand upright with the LEGO underside on the build plate
- Supports off; raft off
- Do not lay the tall stand on its side

## Assembly

1. Print the slit coupon first and confirm the classroom fastener fits the
   3.4 x 1.8 mm opening.
2. Slide the micro:bit into the included alligator-clip guide.
3. Lower the guide and board into the stand with the LED display facing the
   open front.
4. For cardboard use, insert both brass fasteners through the top-open pockets,
   pass their legs through the cardboard, spread the legs, and cover exposed
   metal with tape.

## Pilot-print status

The exact guide relationship and v5.1 LEGO interface were physically reported
working. Automated checks confirm that the v5.4 mesh is watertight and one
component, all six anchor feet and aligned notches are present, every original
tube and LEGO stud center remains open, and both cardboard paths remain clear.

The combined anchor-foot and cardboard revision still needs one complete pilot
before classroom quantities. Confirm first-layer adhesion, full LEGO seating
and removal, exact-guide fit, micro:bit access, cardboard seating, and both
classroom brass fasteners.

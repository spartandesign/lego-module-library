# Third-Party Attribution

## Microbit Alligator Clip Guide v2

- Model title: Microbit Alligator Clip Guide
- Remix author shown on supplied listing: jimting
- Source platform shown on supplied listing: MakerWorld
- Original inspiration: [Thingiverse thing 3026674](https://www.thingiverse.com/thing:3026674) by TuncusEnc
- License shown on supplied listing: Creative Commons Attribution-ShareAlike (CC BY-SA)

The guide was included without geometric modification. Its measured size is approximately 5.85 × 56.0 × 11.2 mm in the supplied print orientation.

Please retain this attribution file with redistributed copies. If the exact MakerWorld model URL becomes available, add it to this notice.


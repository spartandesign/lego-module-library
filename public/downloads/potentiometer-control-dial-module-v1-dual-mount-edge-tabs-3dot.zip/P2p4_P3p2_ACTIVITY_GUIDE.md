# P2.4 and P3.2 activity ideas

## P2.4 Secrets and Safes

Treat the potentiometer as a combination dial.

1. Read the SIG terminal on a micro:bit analog pin.
2. Convert the 0-1023 reading into ten stable dial positions.
3. Store a three-position combination such as 2-7-4.
4. Require the user to visit the positions in order.
5. Unlock with the standard-servo module or confirm success with LEDs.
6. Reset the sequence after an incorrect entry or timeout.

Use ranges rather than exact analog numbers. For ten positions, each
band is roughly 102 analog counts wide. Add hysteresis so a reading at
the edge of two bands does not flicker between them.

## P3.2 Interactions

The same dial can provide continuous and reversible interaction:

- LED brightness from 0-255
- Standard-servo position from 0-180 degrees
- Buzzer pitch or tempo
- LED animation speed
- Menu or display selection
- Adjustable alarm threshold

The larger wing knob is the accessible option. Students can compare it
with the compact knob and collect user feedback about grip, precision,
visibility, and required hand movement.

## Wiring

- Pot pin 1 -> GND terminal
- Pot pin 2, the center wiper -> SIG terminal
- Pot pin 3 -> 3V terminal

Connect SIG to P0, P1, or P2. Swap the two outer wires when the desired
clockwise direction is reversed.

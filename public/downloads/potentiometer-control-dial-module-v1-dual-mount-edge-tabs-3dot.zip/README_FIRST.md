# PLTW potentiometer LEGO control-dial module v1

This compact module adds a continuous rotary input to the LEGO testbed.
It is designed around a common 16 mm, 10 kOhm linear panel potentiometer,
including the BI Technologies P160KN sold as Adafruit Product 562 and
similarly sized WH148-style parts.

The three fragile potentiometer pins stay behind the reinforced panel.
Short wires connect them to large M3 washer terminals labeled 3V, SIG,
and GND. Students attach alligator clips to the metal terminals rather
than to the potentiometer pins.

## Why it helps

- P2.4 Secrets and Safes: use the compact knob as a combination dial.
  Divide the analog reading into numbered bands and require a sequence
  before a servo unlocks or a buzzer sounds.
- P3.2 Interactions: map the analog value to LED brightness, servo
  position, sound, animation choice, or another continuous interaction.
  Use the larger wing knob when a broader, easier-to-grip control helps.

## Print first

1. Bushing coupon A/B/C: 7.4, 7.6, and 7.8 mm.
2. Shaft coupon A/B/C: 5.7, 5.9, and 6.1 mm.
3. M3 nut-trap coupon.

The full base uses the 7.8 mm panel opening. Both knob styles are supplied
in A/B/C bores matching the shaft coupon: 5.7, 5.9, and 6.1 mm. Start
with B, the 5.9 mm version. Potentiometer shafts vary, so use the
manufacturer's knob instead when it fits better.

## A1 mini

- PLA and 0.4 mm nozzle
- 0.20 mm Standard
- Four wall loops
- 20% gyroid; 100% infill is optional for the knobs
- Supports off
- Base: LEGO underside on the build plate
- Knobs: shaft-hole opening on the build plate
- Keep the supplied orientations; do not use automatic orientation

The panel's main opening has a 45-degree teardrop roof so the integrated
upright panel prints without support.

## Hardware

- One 10 kOhm linear 16 mm panel potentiometer
- Potentiometer's supplied M7 washer and nut
- Three standard M3 hex nuts
- Three M3 x 6 mm screws
- Three 9-10 mm M3 washers
- Three short pieces of small insulated wire

## Assembly

1. Insert the potentiometer from behind the upright panel.
2. Align its anti-rotation tab with the small opening when present.
3. Install the potentiometer's washer and nut from the knob side.
4. Tighten the panel nut gently. Do not crush the printed panel.
5. Slide three M3 nuts into the right-side openings in the base.
6. Solder or securely attach one short wire to each potentiometer pin.
7. Route the wires through the three shallow top channels.
8. Clamp each wire loop beneath its labeled M3 washer and screw.
9. Press the selected knob onto the 6 mm shaft.

Viewed from the shaft side, the reference potentiometer drawing numbers
the pins 1, 2, and 3 from left to right. Connect pin 1 to GND, center
wiper pin 2 to SIG, and pin 3 to 3V. If clockwise motion produces the
opposite value change you want, exchange the 3V and GND outer pins.

## micro:bit connection

- 3V terminal to micro:bit 3V
- SIG terminal to P0, P1, or P2
- GND terminal to micro:bit GND

Read SIG as an analog value. A small deadband or short moving average
can prevent the display or servo from jittering between adjacent values.

## First prototype

Confirm the panel bushing fit, anti-rotation tab location, knob fit,
terminal wiring, rotation direction, and LEGO clutch before printing
classroom quantities. Other 16 mm potentiometers can differ in bushing
length, pin shape, and shaft style.

Reference:
- Adafruit Product 562: https://www.adafruit.com/product/562
- BI Technologies P160 datasheet:
  https://cdn-shop.adafruit.com/product-files/562/p160.pdf

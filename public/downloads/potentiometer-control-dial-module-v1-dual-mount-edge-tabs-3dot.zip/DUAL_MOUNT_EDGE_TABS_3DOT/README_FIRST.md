# Compact Cardboard Edge-Tab Variant

This package adds two integrated cardboard-mount tabs to the original Coupon-F LEGO module.

## Tab geometry

- Two flat-shank slits: 2.8 × 1.4 mm
- Two recessed brad-head pockets: 8.5 mm diameter × 3.0 mm deep
- Tab pads: 12 mm diameter
- Loose LEGO-stud clearance beneath each tab: 6.2 mm diameter
- Original Coupon-F clutch geometry remains unchanged

## Cardboard assembly

1. Insert each medium paper brad from the top of the printed module.
2. Mark the two slit locations on the cardboard.
3. Have an adult make two narrow openings in the cardboard.
4. Push the brad legs through and spread them on the inside.
5. Cover exposed legs with tape when students can touch the inside surface.

Use 14 mm or longer prongs; 15–20 mm is preferred for corrugated cardboard.

## LEGO use

The tabs align with the next 8 mm stud column. The loose socket beneath each tab allows that stud to enter without gripping it. The original Coupon-F tubes provide the module's clutch.

## Printing

- Bambu A1 mini, 0.20 mm Standard
- PLA, 0.4 mm nozzle
- Four walls, 20% gyroid
- Supports off
- Keep the LEGO underside on the build plate

This edge-tab combination is a prototype. Print and test one complete module on both the classroom LEGO plate and the intended cardboard before making classroom quantities.

# PLTW Flex Paddle Module v3.5 mesh and clearance validation

All geometry checks use the exact STL after export and reload.

## PLTW Flex Paddle Module v3.5

- Watertight / winding-consistent / one component: `True` / `True` / `1`
- Full supports: `30` at `5.20 x 2.85 mm`; dense probes pass: `True`
- Open Coupon-F bores / aligned C anchors: `6` / `6`
- Clutch centerlines open: `True`
- Anchor material/notches/alignment pass: `True` / `True` / `inward`
- Body and tab LEGO seating disks open: `True` / `True`
- Two dense 3.6 x 1.8 mm path probes pass: `True`
- Source/final M3 screw probes open: `True` / `True`
- Source/final M3 nut-volume probes open: `True` / `True`
- Indexed nominal M3 nut sweep angle/collisions after rebuild: `0.0` / `[0.0, 0.0]`
- Full nominal M3 nut sweeps clear: `True`
- Added/removed delta localization pass: `True` / `True`
- No addition above Z=2.85 mm: `True`
- Upper geometry preserved except localized cardboard/M3 path clearances: `True`
- All required model checks pass: `True`

- ZIP embeds exact current files: `True`
- Website-download copy matches ZIP bytes: `True`
- All package checks pass: `True`

A physical pilot remains required before classroom quantities.

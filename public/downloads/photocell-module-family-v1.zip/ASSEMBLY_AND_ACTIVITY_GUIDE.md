# Assembly and classroom use

## Hardware

- One 5 mm GL5516 or GL5528 photoresistor
- Two standard M3 nuts
- Two M3 × 6 mm screws
- Two conductive M3 washers, preferably 9–11 mm OD

## Install the terminals

1. Slide each M3 nut through its opening in the corresponding short end.
2. Align it beneath the 3.4 mm top hole.
3. Do not force an M3 screw into PLA; it must thread into the metal nut.

## Install the photocell

For COVER and AMBIENT, gently bend the leads approximately 90 degrees with a generous bend radius. Seat the round face upward and route each lead through its separate shallow channel.

For BEAM, slide the sensor into the open-top vertical cradle with its face pointing into the tunnel. Route the leads down and rearward through the two channels.

Place one lead beneath each washer and tighten the M3 × 6 mm screw gently. Do not wind the lead tightly around the screw and do not overtighten.

## Wiring with the existing 47K resistor module

1. Connect either photocell terminal to 3V.
2. Connect the other photocell terminal to the shared P0/resistor terminal.
3. Connect the other side of the 47K resistor to GND.

The photocell is non-polarized. With this arrangement, the P0 reading generally rises as light increases. Record a baseline in the actual classroom before choosing program thresholds.

## Activity applications

- Project 2.4 notebook or safe: COVER.
- Project 2.4 restricted area: BEAM.
- Problem 3.2 after-dark safety: AMBIENT.
- Problem 3.2 interactive art or dispenser: BEAM or COVER depending on the interaction.

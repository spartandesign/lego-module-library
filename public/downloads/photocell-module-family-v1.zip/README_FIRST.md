# PLTW GL55 Photocell LEGO Module Family v1

Three compact modules support the photocell interactions in Project 2.4 Secrets and Safes and Problem 3.2 Interactions.

## Versions

- **COVER (recessed C):** the sensor faces upward in a deep well. Cover it with a notebook, lid, or object. Opening or removing the object admits light.
- **BEAM (recessed B):** the sensor stands vertically behind a directional hood. Aim a flashlight or LED into the opening; interrupting the beam changes the reading.
- **AMBIENT (recessed A):** the sensor faces upward behind a low guard. Use it for room-light, shadow, or after-dark thresholds.

All versions use the proven Coupon-F LEGO interface and the compact resistor module's end-loaded M3 nut approach.

## Print

- Bambu A1 mini, PLA, 0.4 mm nozzle
- 0.20 mm Standard
- Four walls
- 20% gyroid
- Supports off
- LEGO cavity directly on the build plate
- Do not use automatic orientation

Print the sensor-pocket, lead-channel, and M3 coupons before classroom quantities.

# PLTW LEGO modules — proven F-fit underside

These revisions use the fit selected by physical testing on the classroom
16 x 16 baseplate:

- 6.60 mm OD split clutch rings
- 4.80 mm ring ID
- 0.90 mm inward radial flexure split
- skirt is alignment-only, with 0.15 mm nominal clearance per side
- 8.000 mm stud pitch and 4.966 mm measured stud diameter

## Revised modules included

1. SG90 servo module v1.1, 27.5 mm mounting holes (6 x 5 studs)
2. Flex sensor brick-style baseline v2.8.1 (13 x 4 studs)
3. Flex sensor zip-tie module v3.1.1 (13 x 4 studs)
4. FSR402 pressure pad v1.2 wider stem (10 x 6 studs)
5. Resistor module v1.1 (8 x 4 studs)
6. Compact resistor module v2.1 (5 x 3 studs)
7. micro:bit exact-guide stand v5.1 (6 x 10 studs)
8. Three-LED M3 polarity-label module v2.3 (7 x 5 studs)

The upper functional geometry of each source module is retained. Only the
LEGO-contact skirt and clutch rings are revised.

## Bambu A1 mini

- PLA
- 0.20 mm Standard
- Four wall loops
- 20% gyroid
- Supports OFF
- LEGO underside on the build plate
- Use the same elephant-foot compensation that produced coupon F

Test one revised module before printing classroom quantities.

## Still needed

The buzzer production STL was not available and therefore was not reconstructed
from memory. Attach its current STL to receive the same F-fit retrofit without
changing its upper geometry.

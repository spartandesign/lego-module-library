from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
import zipfile
from pathlib import Path


CAD_DEPS = Path(r"C:\Users\trira\.codex\tmp\cad_pydeps")
sys.path.insert(0, str(CAD_DEPS))

import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont


OUTPUT_DIR = Path(__file__).resolve().parent
LATEST_DIR = OUTPUT_DIR.parent
SOURCE_V26 = (
    LATEST_DIR
    / "30_Three_LED_v2_6_OpenTabs_AnchorFeet"
    / "PLTW_Three_LED_LEGO_Module_v2_6_FFit_DualMount_"
    "OpenBrickTabs_AnchoredCouponFFeet_3p4x1p8.stl"
)
BRAD_COUPON_SOURCE = (
    LATEST_DIR
    / "18_All_Modules_InternalBrad_3Dot_v0_1"
    / "STL"
    / "PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl"
)

FILE_PREFIX = "PLTW_Three_LED_v2_7"
ARCHIVE_ROOT = "PLTW_Three_LED_M3_Module_v2_7"
OUTPUT_STL_NAME = (
    "PLTW_Three_LED_LEGO_Module_v2_7_FFit_DualMount_OpenBrickTabs_"
    "SolidRoofSupports_AnchoredCouponFFeet_3p4x1p8.stl"
)
OUTPUT_STL = OUTPUT_DIR / OUTPUT_STL_NAME
OUTPUT_ZIP = OUTPUT_DIR / (
    "three-led-m3-module-v2-7-open-tabs-solid-supports-anchor-feet.zip"
)
BRAD_COUPON_NAME = BRAD_COUPON_SOURCE.name

CLUTCH_CENTERS = (
    (-20.0, -12.0),
    (-20.0, 12.0),
    (-4.0, -4.0),
    (4.0, 4.0),
    (20.0, -12.0),
    (20.0, 12.0),
)
TUBE_GRID = tuple(
    (x, y)
    for x in (-20.0, -12.0, -4.0, 4.0, 12.0, 20.0)
    for y in (-12.0, -4.0, 4.0, 12.0)
)
SUPPORT_CENTERS = tuple(
    point for point in TUBE_GRID if point not in CLUTCH_CENTERS
)
BODY_STUD_CENTERS = tuple(
    (x, y)
    for x in (-24.0, -16.0, -8.0, 0.0, 8.0, 16.0, 24.0)
    for y in (-16.0, -8.0, 0.0, 8.0, 16.0)
)
TAB_STUD_CENTERS = (
    (-40.0, 0.0),
    (-32.0, 0.0),
    (32.0, 0.0),
    (40.0, 0.0),
)
TERMINAL_X = (-16.0, 0.0, 16.0)
TERMINAL_Y = (-11.5, 11.5)
LED_CENTERS = ((-16.0, 0.0), (0.0, 0.0), (16.0, 0.0))

SUPPORT_RADIUS = 2.60
SUPPORT_HEIGHT = 2.85
ROOF_START_Z = 2.46
ROOF_OVERLAP = SUPPORT_HEIGHT - ROOF_START_Z
ANCHOR_RADIUS = 3.00
ANCHOR_HEIGHT = 0.60
LED_POCKET_RADIUS = 2.625
LEGO_STUD_CLEARANCE_RADIUS = 2.40
MIN_STUD_RADIAL_GAP = (
    math.hypot(4.0, 4.0) - SUPPORT_RADIUS - LEGO_STUD_CLEARANCE_RADIUS
)
MIN_LED_RADIAL_GAP = math.hypot(4.0, 4.0) - SUPPORT_RADIUS - LED_POCKET_RADIUS
M3_GEOMETRY_MIN_Z = 3.45
M3_VERTICAL_GAP = M3_GEOMETRY_MIN_Z - SUPPORT_HEIGHT


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_mesh(path: Path) -> trimesh.Trimesh:
    loaded = trimesh.load(path, force="mesh", process=True)
    if isinstance(loaded, trimesh.Scene):
        loaded = loaded.to_geometry()
    if not isinstance(loaded, trimesh.Trimesh):
        raise TypeError(f"Expected a mesh at {path}, got {type(loaded)!r}")
    loaded.remove_unreferenced_vertices()
    return loaded


def cylinder_at(
    x: float,
    y: float,
    radius: float,
    height: float,
    z0: float = 0.0,
    sections: int = 96,
) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(
        radius=radius,
        height=height,
        sections=sections,
    )
    mesh.apply_translation([x, y, z0 + height / 2.0])
    return mesh


def inward_direction(x: float, y: float) -> tuple[float, float]:
    length = math.hypot(x, y)
    return (-x / length, -y / length)


def export_and_reload(mesh: trimesh.Trimesh, path: Path) -> trimesh.Trimesh:
    mesh.remove_unreferenced_vertices()
    mesh.export(path)
    exported = load_mesh(path)
    nondegenerate = exported.nondegenerate_faces()
    if not bool(np.all(nondegenerate)):
        exported.update_faces(nondegenerate)
        exported.remove_unreferenced_vertices()
        exported.export(path)
        exported = load_mesh(path)
    return exported


def build_module() -> tuple[
    trimesh.Trimesh,
    trimesh.Trimesh,
    list[trimesh.Trimesh],
    list[trimesh.Trimesh],
]:
    source = load_mesh(SOURCE_V26)
    supports = [
        # Sixty-four sides matches the proven supportless-family union.  The
        # wider angular facets survive STL float32 export without the tiny
        # coplanar seams seen with a denser 96-side plug.
        cylinder_at(x, y, SUPPORT_RADIUS, SUPPORT_HEIGHT, sections=64)
        for x, y in SUPPORT_CENTERS
    ]
    result = trimesh.boolean.union([source, *supports], engine="manifold")
    exported = export_and_reload(result, OUTPUT_STL)

    # Exact first-layer source geometry is used as the blue preview overlay.
    anchors = [
        trimesh.boolean.intersection(
            [source, cylinder_at(x, y, 3.05, ANCHOR_HEIGHT, sections=96)],
            engine="manifold",
        )
        for x, y in CLUTCH_CENTERS
    ]
    return source, exported, supports, anchors


def contains(
    mesh: trimesh.Trimesh,
    points: list[tuple[float, float, float]],
) -> list[bool]:
    if not points:
        return []
    return [bool(value) for value in mesh.contains(np.asarray(points))]


def dense_circle_points(
    center: tuple[float, float],
    max_radius: float,
    radii: int,
    angles: int,
    zs: tuple[float, ...],
) -> list[tuple[float, float, float]]:
    points: list[tuple[float, float, float]] = []
    for radius in np.linspace(0.0, max_radius, radii):
        angle_values = (0.0,) if radius == 0.0 else np.linspace(
            0.0,
            2.0 * math.pi,
            angles,
            endpoint=False,
        )
        for angle in angle_values:
            for z in zs:
                points.append(
                    (
                        center[0] + float(radius) * math.cos(float(angle)),
                        center[1] + float(radius) * math.sin(float(angle)),
                        z,
                    )
                )
    return points


def validate(source: trimesh.Trimesh, mesh: trimesh.Trimesh) -> dict[str, object]:
    support_points = [
        point
        for center in SUPPORT_CENTERS
        for point in dense_circle_points(
            center,
            2.50,
            9,
            32,
            (0.05, 0.30, 1.40, 2.30, 2.44, 2.79, 2.84),
        )
    ]
    clutch_bores = [
        (x, y, z)
        for x, y in CLUTCH_CENTERS
        for z in (0.05, 0.30, 0.59, 0.61, 1.40, 2.30)
    ]

    anchor_material: list[tuple[float, float, float]] = []
    anchor_above: list[tuple[float, float, float]] = []
    anchor_notches: list[tuple[float, float, float]] = []
    for x, y in CLUTCH_CENTERS:
        direction_x, direction_y = inward_direction(x, y)
        perpendicular_x, perpendicular_y = -direction_y, direction_x
        material_xy = (
            (x - direction_x * 1.50, y - direction_y * 1.50),
            (x + perpendicular_x * 1.60, y + perpendicular_y * 1.60),
            (x - perpendicular_x * 1.60, y - perpendicular_y * 1.60),
        )
        for point_x, point_y in material_xy:
            anchor_material.extend(
                (point_x, point_y, z) for z in (0.05, 0.30, 0.59)
            )
            anchor_above.append((point_x, point_y, 0.61))
        for radius in (0.0, 0.75, 1.50, 2.50):
            anchor_notches.extend(
                (
                    x + direction_x * radius,
                    y + direction_y * radius,
                    z,
                )
                for z in (0.05, 0.30, 0.59)
            )

    body_stud_clearance_points = [
        point
        for center in BODY_STUD_CENTERS
        for point in dense_circle_points(
            center,
            2.28,
            5,
            20,
            (0.30, 1.40, 2.30),
        )
    ]
    tab_stud_clearance_points = [
        point
        for center in TAB_STUD_CENTERS
        for point in dense_circle_points(
            center,
            2.28,
            5,
            20,
            (0.30, 1.40, 2.30),
        )
    ]
    tab_portal_points = [
        (sign * x, y, z)
        for sign in (-1.0, 1.0)
        for x in (28.0, 29.0, 32.0, 36.0, 40.0)
        for y in (-2.30, 0.0, 2.30)
        for z in (0.30, 1.40, 2.30)
    ]
    tab_slit_points = [
        (sign * 36.0, y, z)
        for sign in (-1.0, 1.0)
        for y in (-0.70, 0.0, 0.70)
        for z in (0.10, 4.75, 9.00)
    ]

    # The v2.6 side-loaded nut traps remain completely above the added posts.
    # Probe a dense central prism continuously from each long-side opening to
    # its captive trap; the exact source geometry above Z=2.85 is unchanged.
    nut_corridor_points: list[tuple[float, float, float]] = []
    for terminal_x in TERMINAL_X:
        for sign in (-1.0, 1.0):
            path_y = np.linspace(sign * 20.50, sign * 11.50, 49)
            nut_corridor_points.extend(
                (
                    terminal_x + x_offset,
                    float(y),
                    5.75 + z_offset,
                )
                for y in path_y
                for x_offset in (-1.20, -0.60, 0.0, 0.60, 1.20)
                for z_offset in (-0.75, 0.0, 0.75)
            )

    screw_bore_points = [
        point
        for terminal_x in TERMINAL_X
        for terminal_y in TERMINAL_Y
        for point in dense_circle_points(
            (terminal_x, terminal_y),
            1.40,
            5,
            24,
            (3.50, 5.75, 8.00, 10.00, 12.00),
        )
    ]
    led_pocket_points = [
        point
        for center in LED_CENTERS
        for point in dense_circle_points(
            center,
            2.55,
            9,
            32,
            (10.00, 11.00, 12.00),
        )
    ]

    checks: dict[str, object] = {
        "watertight": bool(mesh.is_watertight),
        "winding_consistent": bool(mesh.is_winding_consistent),
        "components": len(mesh.split(only_watertight=False)),
        "faces": int(len(mesh.faces)),
        "bounds_mm": [[round(float(value), 3) for value in row] for row in mesh.bounds],
        "extents_mm": [round(float(value), 3) for value in mesh.extents],
        "source_extents_mm": [round(float(value), 3) for value in source.extents],
        "source_v2_6_sha256": sha256(SOURCE_V26),
        "output_stl_sha256": sha256(OUTPUT_STL),
        "added_support_volume_mm3": round(float(mesh.volume - source.volume), 3),
        "source_extents_preserved": bool(np.allclose(mesh.extents, source.extents, atol=1e-5)),
        "geometry_above_z_2p85_preserved_by_construction": True,
        "support_count": len(SUPPORT_CENTERS),
        "support_diameter_mm": SUPPORT_RADIUS * 2.0,
        "support_max_z_mm": SUPPORT_HEIGHT,
        "cavity_roof_start_z_mm": ROOF_START_Z,
        "support_roof_overlap_mm": round(ROOF_OVERLAP, 3),
        "dense_support_samples": len(support_points),
        "all_18_support_disks_solid_to_roof": all(contains(mesh, support_points)),
        "clutch_count": len(CLUTCH_CENTERS),
        "all_six_coupon_f_centerlines_open": not any(contains(mesh, clutch_bores)),
        "anchor_material_present_through_z_0p59": all(contains(mesh, anchor_material)),
        "anchor_material_ends_before_z_0p61": not any(contains(mesh, anchor_above)),
        "all_six_anchor_notches_open_inward": not any(contains(mesh, anchor_notches)),
        "all_35_body_stud_clearance_disks_open_dense": not any(
            contains(mesh, body_stud_clearance_points)
        ),
        "four_tab_continuation_clearance_disks_open_dense": not any(
            contains(mesh, tab_stud_clearance_points)
        ),
        "both_tab_cavities_and_portals_open_dense": not any(
            contains(mesh, tab_portal_points)
        ),
        "both_3p4x1p8_brad_slits_open_dense": not any(
            contains(mesh, tab_slit_points)
        ),
        "all_six_m3_nut_loading_center_corridors_open_dense": not any(
            contains(mesh, nut_corridor_points)
        ),
        "all_six_m3_screw_bores_open_dense": not any(
            contains(mesh, screw_bore_points)
        ),
        "all_three_5p25_led_pockets_open_dense": not any(
            contains(mesh, led_pocket_points)
        ),
        "minimum_support_to_lego_stud_radial_gap_mm": round(MIN_STUD_RADIAL_GAP, 3),
        "support_to_lego_stud_gap_positive": MIN_STUD_RADIAL_GAP > 0.60,
        "minimum_support_to_led_pocket_radial_gap_mm": round(MIN_LED_RADIAL_GAP, 3),
        "support_to_led_pocket_gap_positive": MIN_LED_RADIAL_GAP > 0.40,
        "m3_geometry_min_z_mm": M3_GEOMETRY_MIN_Z,
        "support_to_m3_vertical_gap_mm": round(M3_VERTICAL_GAP, 3),
        "support_to_m3_vertical_gap_positive": M3_VERTICAL_GAP >= 0.60,
    }
    checks["all_required_checks_pass"] = bool(
        checks["watertight"]
        and checks["winding_consistent"]
        and checks["components"] == 1
        and checks["source_extents_preserved"]
        and checks["all_18_support_disks_solid_to_roof"]
        and checks["all_six_coupon_f_centerlines_open"]
        and checks["anchor_material_present_through_z_0p59"]
        and checks["anchor_material_ends_before_z_0p61"]
        and checks["all_six_anchor_notches_open_inward"]
        and checks["all_35_body_stud_clearance_disks_open_dense"]
        and checks["four_tab_continuation_clearance_disks_open_dense"]
        and checks["both_tab_cavities_and_portals_open_dense"]
        and checks["both_3p4x1p8_brad_slits_open_dense"]
        and checks["all_six_m3_nut_loading_center_corridors_open_dense"]
        and checks["all_six_m3_screw_bores_open_dense"]
        and checks["all_three_5p25_led_pockets_open_dense"]
        and checks["support_to_lego_stud_gap_positive"]
        and checks["support_to_led_pocket_gap_positive"]
        and checks["support_to_m3_vertical_gap_positive"]
    )
    return checks


def write_readme(mesh: trimesh.Trimesh) -> None:
    text = f"""# PLTW Three-LED M3 Terminal Module v2.7

This revision adds solid cavity-roof support to the exact v2.6 module while
preserving its physically successful three-LED layout, six M3 terminals,
polarity labels, Coupon-F clutch interface, C anchor feet, and open cardboard
tabs.

## Supportless underside upgrade

- All 18 non-clutch underside tube centers now use full 5.20 mm-diameter solid
  posts from Z=0 to Z=2.85 mm.
- The cavity roof begins at Z=2.46 mm, giving each post {ROOF_OVERLAP:.2f} mm of
  positive overlap into the roof.
- All six Coupon-F clutch centerlines remain open.
- All six existing 0.60 mm inward-split C anchor feet remain unchanged.
- The nearest calculated support-to-LEGO-stud radial gap is
  {MIN_STUD_RADIAL_GAP:.3f} mm.
- The nearest support-to-LED-pocket radial gap is {MIN_LED_RADIAL_GAP:.3f} mm.
- M3 geometry begins at Z={M3_GEOMETRY_MIN_Z:.2f} mm, leaving a
  {M3_VERTICAL_GAP:.2f} mm vertical gap above the added posts.

The added geometry stops at Z=2.85 mm. Every LED, terminal, label, nut tunnel,
screw bore, tab, portal, slit, recess, and top feature above that plane is the
exact v2.6 geometry.

## Retained geometry

- 7 x 5-stud / 56 x 40 mm LEGO body
- Three centered 5.25 mm LED pockets at X=-16, 0, and +16 mm
- Six side-loaded captive-nut M3 terminals
- Two open short-X-end cardboard tabs
- Continuous 6.4 mm tab cavities and portals
- Two 3.4 x 1.8 mm brass-fastener slits with shallow head recesses
- Overall printable mesh: {mesh.extents[0]:.2f} x {mesh.extents[1]:.2f} x {mesh.extents[2]:.2f} mm

The tabs stay on the X ends because all six M3 nuts load from the two long Y
sides. Moving the tabs to the Y sides would obstruct those loading paths.

## Hardware

- Three standard 5 mm LEDs
- Six M3 x 6 mm screws
- Six standard M3 hex nuts
- Six 9-10 mm M3 washers
- One current-limiting resistor for every LED circuit
- Two classroom brass fasteners for direct cardboard mounting

## Assembly

1. Test the included 3.2 / 3.4 / 3.6 mm brass-fastener coupon.
2. Insert all six M3 nuts through the long-Y-side loading openings.
3. Install each LED with its longer anode routed toward `+` and its shorter
   cathode / flat side routed toward `-`.
4. Capture each lead beneath a conductive washer and tighten gently.
5. Always include an appropriate current-limiting resistor in every LED circuit.
6. For cardboard mounting, insert both brass fasteners from the top, pass their
   legs through the cardboard, spread the legs, and cover exposed metal.

## Printing

- Bambu A1 mini or comparable printer
- PLA, 0.4 mm nozzle, 0.20 mm Standard profile
- Four wall loops and 20% gyroid
- LEGO underside on the build plate
- Supports off; raft off
- Use a small outer brim if corner lifting occurs

## Pilot status

The exact exported-and-reloaded STL is watertight and one component. Dense
automated probes confirm all 18 solid support disks, all six open clutch bores
and C anchors, LEGO seating, both cardboard paths, six M3 nut corridors and
screw bores, and all three LED pockets.

A physical pilot with the classroom printer, LEGO plate, LEDs, M3 hardware,
cardboard, and brass fasteners is still required before classroom quantities.
"""
    (OUTPUT_DIR / "README_FIRST.md").write_text(text, encoding="utf-8")


def write_dimensions(mesh: trimesh.Trimesh) -> None:
    rows = [
        ("Feature", "Value"),
        ("Module", "PLTW Three-LED M3 Terminal Module v2.7"),
        ("LEGO body footprint", "7 x 5 studs / 56 x 40 mm"),
        ("Overall mesh extents", " x ".join(f"{value:.2f}" for value in mesh.extents) + " mm"),
        ("Solid non-clutch roof supports", "18"),
        ("Support diameter x height", "5.20 x 2.85 mm"),
        ("Cavity roof starts", "Z = 2.46 mm"),
        ("Support-to-roof overlap", f"{ROOF_OVERLAP:.2f} mm"),
        ("Minimum support-to-stud radial gap", f"{MIN_STUD_RADIAL_GAP:.3f} mm"),
        ("Minimum support-to-LED radial gap", f"{MIN_LED_RADIAL_GAP:.3f} mm"),
        ("Support-to-M3 vertical gap", f"{M3_VERTICAL_GAP:.2f} mm"),
        ("Coupon-F clutch bores", "6 open"),
        ("C anchor feet", "6 at 6.00 mm diameter x 0.60 mm high"),
        ("Anchor notch", "4.20 x 1.55 mm, aligned inward with each split"),
        ("LED pockets", "Three 5.25 mm pockets at X = -16, 0, +16 mm"),
        ("M3 terminals", "Six preserved side-loaded captive-nut terminals"),
        ("M3 hardware", "6 x M3 x 6 mm screws, nuts, and washers"),
        ("Cardboard tabs", "Two open one-stud-wide x two-stud-long X-end tabs"),
        ("Tab centers", "X = -36 and +36 mm; Y = 0"),
        ("Brass-fastener slit", "3.4 x 1.8 mm capsule"),
        ("Brad head recess", "9.1 mm diameter x 1.22 mm deep"),
        ("Tab underside cavity", "16.0 x 6.4 x 2.72 mm"),
        ("Tab-to-base portal", "4.0 x 6.4 x 2.72 mm"),
    ]
    with (OUTPUT_DIR / f"{FILE_PREFIX}_Dimensions.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        csv.writer(handle).writerows(rows)


def render_isometric(
    specs: list[tuple[trimesh.Trimesh, tuple[int, int, int]]],
    path: Path,
    title: str,
    footer: str,
    overlay_count: int = 0,
) -> None:
    view = np.array([1.0, -1.35, 0.90])
    view /= np.linalg.norm(view)
    right = np.cross(view, np.array([0.0, 0.0, 1.0]))
    right /= np.linalg.norm(right)
    up = np.cross(right, view)
    up /= np.linalg.norm(up)
    light = np.array([0.30, -0.45, 0.84])
    light /= np.linalg.norm(light)

    triangles: list[tuple[float, np.ndarray, tuple[int, int, int]]] = []
    overlays: list[tuple[float, np.ndarray, tuple[int, int, int]]] = []
    projected_all: list[np.ndarray] = []
    overlay_start = len(specs) - overlay_count
    for index, (mesh, color) in enumerate(specs):
        tri3 = mesh.vertices[mesh.faces]
        normals = np.cross(tri3[:, 1] - tri3[:, 0], tri3[:, 2] - tri3[:, 0])
        lengths = np.linalg.norm(normals, axis=1)
        valid = lengths > 1e-9
        normals[valid] /= lengths[valid, None]
        facing = normals @ view > -0.10
        for triangle, normal in zip(tri3[facing], normals[facing]):
            projected = np.column_stack((triangle @ right, -(triangle @ up)))
            depth = float(np.mean(triangle @ view))
            shade = 0.70 + 0.30 * max(0.0, float(normal @ light))
            shaded = tuple(
                max(0, min(255, int(channel * shade))) for channel in color
            )
            target = overlays if overlay_count and index >= overlay_start else triangles
            target.append((depth, projected, shaded))
            projected_all.append(projected)

    all_points = np.vstack(projected_all)
    low = all_points.min(axis=0)
    high = all_points.max(axis=0)
    canvas = (1500, 1000)
    margin = 110
    scale = min(
        (canvas[0] - 2 * margin) / (high[0] - low[0]),
        (canvas[1] - 2 * margin - 100) / (high[1] - low[1]),
    )
    offset = np.array(
        [
            (canvas[0] - (high[0] - low[0]) * scale) / 2.0 - low[0] * scale,
            100.0
            + (canvas[1] - 175 - (high[1] - low[1]) * scale) / 2.0
            - low[1] * scale,
        ]
    )
    image = Image.new("RGB", canvas, (247, 249, 252))
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    draw.text((45, 28), title, fill=(30, 40, 54), font=font)
    for collection in (triangles, overlays):
        for _depth, projected, color in sorted(collection, key=lambda item: item[0]):
            points = [
                (float(x * scale + offset[0]), float(y * scale + offset[1]))
                for x, y in projected
            ]
            draw.polygon(points, fill=color)
    draw.text((45, 955), footer, fill=(30, 40, 54), font=font)
    image.save(path)


def led_assembly_proxy() -> trimesh.Trimesh:
    parts: list[trimesh.Trimesh] = []
    for x, _y in LED_CENTERS:
        body = cylinder_at(x, 0.0, 2.45, 5.4, z0=9.65, sections=72)
        dome = trimesh.creation.uv_sphere(radius=2.45, count=[36, 18])
        dome.apply_translation([x, 0.0, 15.05])
        negative_lead = trimesh.creation.box(extents=[0.65, 8.0, 0.65])
        negative_lead.apply_translation([x, -7.0, 10.40])
        positive_lead = trimesh.creation.box(extents=[0.65, 8.0, 0.65])
        positive_lead.apply_translation([x, 7.0, 10.40])
        parts.extend([body, dome, negative_lead, positive_lead])
        parts.extend(
            cylinder_at(x, y, 4.0, 0.55, z0=12.15)
            for y in TERMINAL_Y
        )
    return trimesh.util.concatenate(parts)


def render_previews(
    mesh: trimesh.Trimesh,
    supports: list[trimesh.Trimesh],
    anchors: list[trimesh.Trimesh],
) -> None:
    render_isometric(
        [(mesh, (174, 184, 194)), (led_assembly_proxy(), (55, 122, 96))],
        OUTPUT_DIR / f"{FILE_PREFIX}_Assembly_Preview.png",
        "THREE-LED v2.7 - ASSEMBLY REFERENCE",
        "Three 5 mm LEDs; route each long lead to + and short lead / flat side to -.",
    )
    render_isometric(
        [(mesh, (174, 184, 194))],
        OUTPUT_DIR / f"{FILE_PREFIX}_Top_Preview.png",
        "THREE-LED v2.7 - PRINTABLE MODULE",
        "All LED, M3 terminal, polarity-label, and open-tab geometry is exact v2.6.",
    )

    rotation = trimesh.transformations.rotation_matrix(math.pi, [1.0, 0.0, 0.0])
    underside = mesh.copy()
    underside.apply_transform(rotation)
    support_overlay = trimesh.util.concatenate([item.copy() for item in supports])
    support_overlay.apply_transform(rotation)
    support_overlay.apply_translation([0.0, 0.0, 0.03])
    anchor_overlay = trimesh.util.concatenate([item.copy() for item in anchors])
    anchor_overlay.apply_transform(rotation)
    anchor_overlay.apply_translation([0.0, 0.0, 0.05])
    render_isometric(
        [
            (underside, (174, 184, 194)),
            (support_overlay, (93, 151, 105)),
            (anchor_overlay, (65, 116, 168)),
        ],
        OUTPUT_DIR / f"{FILE_PREFIX}_Underside_Preview.png",
        "THREE-LED v2.7 - SUPPORTED UNDERSIDE",
        "Green = 18 solid roof posts; blue = six preserved open Coupon-F C anchors.",
        overlay_count=2,
    )


def write_validation(checks: dict[str, object]) -> None:
    (OUTPUT_DIR / "MESH_AND_CLEARANCE_VALIDATION.json").write_text(
        json.dumps(checks, indent=2) + "\n",
        encoding="utf-8",
    )
    lines = [
        "# Three-LED v2.7 mesh and clearance validation",
        "",
        f"- Watertight: `{checks['watertight']}`",
        f"- Winding consistent: `{checks['winding_consistent']}`",
        f"- Connected components: `{checks['components']}`",
        f"- Exported mesh extents: `{checks['extents_mm']} mm`",
        f"- Source extents preserved: `{checks['source_extents_preserved']}`",
        f"- Solid supports: `{checks['support_count']}` at `{checks['support_diameter_mm']} mm` diameter",
        f"- Dense support samples: `{checks['dense_support_samples']}`",
        f"- All 18 support disks solid through Z=2.84: `{checks['all_18_support_disks_solid_to_roof']}`",
        f"- Support-to-roof overlap: `{checks['support_roof_overlap_mm']} mm`",
        f"- Six Coupon-F centerlines open: `{checks['all_six_coupon_f_centerlines_open']}`",
        f"- Six C anchors present through Z=0.59: `{checks['anchor_material_present_through_z_0p59']}`",
        f"- C anchors end before Z=0.61: `{checks['anchor_material_ends_before_z_0p61']}`",
        f"- Six inward anchor notches open: `{checks['all_six_anchor_notches_open_inward']}`",
        f"- Thirty-five LEGO seating disks open: `{checks['all_35_body_stud_clearance_disks_open_dense']}`",
        f"- Four tab continuation seating disks open: `{checks['four_tab_continuation_clearance_disks_open_dense']}`",
        f"- Both tab cavities and portals open: `{checks['both_tab_cavities_and_portals_open_dense']}`",
        f"- Both 3.4 x 1.8 mm brad slits open: `{checks['both_3p4x1p8_brad_slits_open_dense']}`",
        f"- Six M3 nut-loading center corridors open: `{checks['all_six_m3_nut_loading_center_corridors_open_dense']}`",
        f"- Six M3 screw bores open: `{checks['all_six_m3_screw_bores_open_dense']}`",
        f"- Three 5.25 mm LED pockets open: `{checks['all_three_5p25_led_pockets_open_dense']}`",
        f"- Minimum support-to-stud radial gap: `{checks['minimum_support_to_lego_stud_radial_gap_mm']} mm`",
        f"- Minimum support-to-LED radial gap: `{checks['minimum_support_to_led_pocket_radial_gap_mm']} mm`",
        f"- Support-to-M3 vertical gap: `{checks['support_to_m3_vertical_gap_mm']} mm`",
        f"- Package embeds exact output files: `{checks.get('package_embeds_exact_files', False)}`",
        f"- All required automated checks pass: `{checks['all_required_checks_pass']}`",
        "",
        "All checks use the exact STL after export and reload.",
        "A complete physical pilot remains required before classroom quantities.",
        "",
    ]
    (OUTPUT_DIR / "MESH_AND_CLEARANCE_VALIDATION.md").write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def package_files() -> list[str]:
    return [
        "README_FIRST.md",
        OUTPUT_STL_NAME,
        BRAD_COUPON_NAME,
        f"{FILE_PREFIX}_Dimensions.csv",
        "MESH_AND_CLEARANCE_VALIDATION.md",
        "MESH_AND_CLEARANCE_VALIDATION.json",
        f"{FILE_PREFIX}_Assembly_Preview.png",
        f"{FILE_PREFIX}_Top_Preview.png",
        f"{FILE_PREFIX}_Underside_Preview.png",
    ]


def create_package() -> None:
    with zipfile.ZipFile(
        OUTPUT_ZIP,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for name in package_files():
            archive.write(OUTPUT_DIR / name, f"{ARCHIVE_ROOT}/{name}")
        archive.write(
            Path(__file__),
            f"{ARCHIVE_ROOT}/SOURCE/{Path(__file__).name}",
        )


def package_embeds_exact_files() -> bool:
    with zipfile.ZipFile(OUTPUT_ZIP) as archive:
        return all(
            archive.read(f"{ARCHIVE_ROOT}/{name}") == (OUTPUT_DIR / name).read_bytes()
            for name in package_files()
        )


def main() -> None:
    for source in (SOURCE_V26, BRAD_COUPON_SOURCE):
        if not source.exists():
            raise FileNotFoundError(source)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    (OUTPUT_DIR / BRAD_COUPON_NAME).write_bytes(BRAD_COUPON_SOURCE.read_bytes())

    source, mesh, supports, anchors = build_module()
    checks = validate(source, mesh)
    write_readme(mesh)
    write_dimensions(mesh)
    render_previews(mesh, supports, anchors)
    checks["package_embeds_exact_files"] = False
    write_validation(checks)
    create_package()
    checks["package_embeds_exact_files"] = package_embeds_exact_files()
    checks["all_required_checks_pass"] = bool(
        checks["all_required_checks_pass"] and checks["package_embeds_exact_files"]
    )
    write_validation(checks)
    create_package()

    exact = package_embeds_exact_files()
    if not checks["all_required_checks_pass"] or not exact:
        failed = [
            key
            for key, value in checks.items()
            if isinstance(value, bool) and not value
        ]
        raise SystemExit(
            "Three-LED v2.7 validation failed loudly: " + ", ".join(failed)
        )

    print(
        "three_led_v2_7|pass=True|"
        f"watertight={checks['watertight']}|components={checks['components']}|"
        f"supports={checks['support_count']}|clutches={checks['clutch_count']}|"
        f"extents={checks['extents_mm']}|zip={OUTPUT_ZIP}"
    )


if __name__ == "__main__":
    main()

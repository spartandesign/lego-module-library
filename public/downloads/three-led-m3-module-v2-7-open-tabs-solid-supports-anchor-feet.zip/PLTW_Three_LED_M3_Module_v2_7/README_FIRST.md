# PLTW Three-LED M3 Terminal Module v2.7

This revision adds solid cavity-roof support to the exact v2.6 module while
preserving its physically successful three-LED layout, six M3 terminals,
polarity labels, Coupon-F clutch interface, C anchor feet, and open cardboard
tabs.

## Supportless underside upgrade

- All 18 non-clutch underside tube centers now use full 5.20 mm-diameter solid
  posts from Z=0 to Z=2.85 mm.
- The cavity roof begins at Z=2.46 mm, giving each post 0.39 mm of
  positive overlap into the roof.
- All six Coupon-F clutch centerlines remain open.
- All six existing 0.60 mm inward-split C anchor feet remain unchanged.
- The nearest calculated support-to-LEGO-stud radial gap is
  0.657 mm.
- The nearest support-to-LED-pocket radial gap is 0.432 mm.
- M3 geometry begins at Z=3.45 mm, leaving a
  0.60 mm vertical gap above the added posts.

The added geometry stops at Z=2.85 mm. Every LED, terminal, label, nut tunnel,
screw bore, tab, portal, slit, recess, and top feature above that plane is the
exact v2.6 geometry.

## Retained geometry

- 7 x 5-stud / 56 x 40 mm LEGO body
- Three centered 5.25 mm LED pockets at X=-16, 0, and +16 mm
- Six side-loaded captive-nut M3 terminals
- Two open short-X-end cardboard tabs
- Continuous 6.4 mm tab cavities and portals
- Two 3.4 x 1.8 mm brass-fastener slits with shallow head recesses
- Overall printable mesh: 89.00 x 40.00 x 12.30 mm

The tabs stay on the X ends because all six M3 nuts load from the two long Y
sides. Moving the tabs to the Y sides would obstruct those loading paths.

## Hardware

- Three standard 5 mm LEDs
- Six M3 x 6 mm screws
- Six standard M3 hex nuts
- Six 9-10 mm M3 washers
- One current-limiting resistor for every LED circuit
- Two classroom brass fasteners for direct cardboard mounting

## Assembly

1. Test the included 3.2 / 3.4 / 3.6 mm brass-fastener coupon.
2. Insert all six M3 nuts through the long-Y-side loading openings.
3. Install each LED with its longer anode routed toward `+` and its shorter
   cathode / flat side routed toward `-`.
4. Capture each lead beneath a conductive washer and tighten gently.
5. Always include an appropriate current-limiting resistor in every LED circuit.
6. For cardboard mounting, insert both brass fasteners from the top, pass their
   legs through the cardboard, spread the legs, and cover exposed metal.

## Printing

- Bambu A1 mini or comparable printer
- PLA, 0.4 mm nozzle, 0.20 mm Standard profile
- Four wall loops and 20% gyroid
- LEGO underside on the build plate
- Supports off; raft off
- Use a small outer brim if corner lifting occurs

## Pilot status

The exact exported-and-reloaded STL is watertight and one component. Dense
automated probes confirm all 18 solid support disks, all six open clutch bores
and C anchors, LEGO seating, both cardboard paths, six M3 nut corridors and
screw bores, and all three LED pockets.

A physical pilot with the classroom printer, LEGO plate, LEDs, M3 hardware,
cardboard, and brass fasteners is still required before classroom quantities.

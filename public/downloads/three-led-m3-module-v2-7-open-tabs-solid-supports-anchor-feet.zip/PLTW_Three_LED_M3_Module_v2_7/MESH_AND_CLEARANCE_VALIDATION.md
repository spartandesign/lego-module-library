# Three-LED v2.7 mesh and clearance validation

- Watertight: `True`
- Winding consistent: `True`
- Connected components: `1`
- Exported mesh extents: `[89.0, 40.0, 12.3] mm`
- Source extents preserved: `True`
- Solid supports: `18` at `5.2 mm` diameter
- Dense support samples: `32382`
- All 18 support disks solid through Z=2.84: `True`
- Support-to-roof overlap: `0.39 mm`
- Six Coupon-F centerlines open: `True`
- Six C anchors present through Z=0.59: `True`
- C anchors end before Z=0.61: `True`
- Six inward anchor notches open: `True`
- Thirty-five LEGO seating disks open: `True`
- Four tab continuation seating disks open: `True`
- Both tab cavities and portals open: `True`
- Both 3.4 x 1.8 mm brad slits open: `True`
- Six M3 nut-loading center corridors open: `True`
- Six M3 screw bores open: `True`
- Three 5.25 mm LED pockets open: `True`
- Minimum support-to-stud radial gap: `0.657 mm`
- Minimum support-to-LED radial gap: `0.432 mm`
- Support-to-M3 vertical gap: `0.6 mm`
- Package embeds exact output files: `True`
- All required automated checks pass: `True`

All checks use the exact STL after export and reload.
A complete physical pilot remains required before classroom quantities.

# micro:bit Original-Guide Stand v5.1

This pack contains the v5.1 stand with the project-standard Coupon-F LEGO underside and the exact alligator-clip guide used to design its cradle.

The included guide measures approximately 5.85 x 56.0 x 11.2 mm. Its licensing and remix attribution are preserved in `THIRD_PARTY_ATTRIBUTION.md`.

## Assembly

1. Slide the micro:bit into the included clip guide with the display facing forward.
2. Lower the guide and board together into the stand's open-top continuous cradle.
3. Confirm P0, P1, P2, 3V, and GND remain accessible before attaching clips.

## Print

- Bambu A1 mini, 0.20 mm Standard
- PLA, 0.4 mm nozzle
- Four walls, 20% gyroid
- Supports off
- Print both parts in their supplied orientations

Status: the stand was dimensioned from the exact guide mesh, and Coupon-F is the preferred tested LEGO interface. Pilot the final v5.1 combination before printing a classroom set.

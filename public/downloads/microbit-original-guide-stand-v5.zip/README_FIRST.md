# PLTW micro:bit LEGO Stand Module v5 — Original Clip Guide Retrofit

This download contains both parts needed for the assembly:

- `PLTW_Microbit_Stand_v5_ExactGuide_LEGO_Base.stl`
- `Microbit_Alligator_Clip_Guide_v2.stl`

The stand was built around the supplied clip guide's measured slicer orientation:

- Thickness: 5.85 mm
- Length: 56.00 mm
- Height: 11.20 mm

The guide drops into a continuous 56.8 mm open-top cradle. The cradle is 6.70 mm wide, supports the guide along its lower rail, and keeps all five micro:bit connections accessible: P0, P1, P2, 3V, and GND.

## Print settings

- PLA
- 0.4 mm nozzle
- 0.20 mm Standard
- 4 walls for the stand
- 15–20% infill
- supports off
- brim off initially

Print the stand with its LEGO underside on the build plate. Print the guide in its supplied flat orientation.

## Assembly

1. Slide the micro:bit into the clip guide with its five large connection pads aligned to the five guide openings.
2. Lower the guide and micro:bit into the stand together.
3. Face the micro:bit display toward the open front.
4. Attach alligator clips through the guide openings.
5. Confirm that each clip grips the micro:bit pad rather than only gripping the printed guide.

## Attribution and license

The included guide is the **Microbit Alligator Clip Guide** remix shown in the supplied MakerWorld listing, credited there to **jimting**. The listing states that it was inspired by [Thingiverse model 3026674](https://www.thingiverse.com/thing:3026674) by **TuncusEnc**.

The supplied listing displays a **Creative Commons Attribution-ShareAlike (CC BY-SA)** license. The guide remains subject to that license. Retain `THIRD_PARTY_ATTRIBUTION.md` whenever redistributing the guide or this download pack.

The LEGO-compatible stand is the project-specific retrofit designed around the guide's measured geometry.


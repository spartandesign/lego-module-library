# PLTW micro:bit LEGO Stand Module v5 — Exact Original Guide Retrofit

This revision was rebuilt around the exact uploaded `Microbit_Alligator_Clip_Guide_v2(3).3mf` rather than estimated cradle dimensions.

## What was wrong with v4

The uploaded 3MF includes a build rotation. In Bambu Studio its dimensions are approximately:

- X thickness: 5.85 mm
- Y length: 56.00 mm
- Z height: 11.20 mm

Version 4 expected the 56 mm direction to run across the 80 mm base. The original 3MF imports with that direction running front-to-back, so the visual alignment and end pockets did not match.

## What v5 changes

- The LEGO base is rotated to a 48 x 80 mm footprint.
- The guide drops into a continuous 56.8 mm-long open-top cradle.
- The production cradle is 6.70 mm wide around the guide's measured 5.85 mm thickness.
- Five front openings align with P0, P1, P2, 3V, and GND.
- Solid rear stabilizers resist clip-removal loads.
- The exact guide is not modified and no replacement guide is required.

## Fit test

Print `PLTW_Microbit_v5_Guide_Fit_Coupon_6p70mm.stl` first.

- Use 6.70 mm if the guide slides in easily without visible side-to-side wobble.
- If too tight, try 6.90 mm.
- If unusually loose, try 6.50 mm.

The full base uses 6.70 mm.

## Bambu A1 mini

- PLA
- 0.4 mm nozzle
- 0.20 mm Standard
- 4 walls
- 20% gyroid
- supports OFF
- LEGO underside on build plate
- do not use automatic orientation

## Reference files

`Original_Alligator_Guide_Aligned_Reference_Not_For_Print.stl` is the exact uploaded guide transformed into the v5 stand coordinates. It is for slicer inspection only.

`Assembly_Check_Stand_Plus_Exact_Guide_Not_For_Print.stl` contains the stand and exact guide together so the fit and alignment can be examined. Do not print that assembly file.

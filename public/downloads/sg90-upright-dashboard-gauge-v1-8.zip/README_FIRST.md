# SG90 upright dashboard gauge v1.8 - primary label-up version

This is the primary label-up dashboard version. The panel holders and horn
clearance are moved to the opposite side of the servo. When facing the panel,
the 18 mm opening is on the right and the SG90 label faces upward.

The successful Version 1.7 panel fit is unchanged: 60.0 mm panel width, 1.5 mm
engagement in each holder, and 0.25 mm clearance before each closed spine.
Because the holders have moved to the opposite side, the Version 1.8 base must
be printed; a Version 1.7 base cannot provide this label-up orientation.

The horn opening is reduced from 24 mm to 18 mm. It still surrounds the SG90
output hub but hides substantially more of the servo body. The robust 0.55 mm
single-stroke lettering and 0.6 mm marking height from Version 1.4 remain.

## Included panels

- Generic 0 / 90 / 180 degree panel
- P2.4 SAFE / ARMED / ALERT panel
- P3.2 READY / ACTIVE / DONE panel

## Assembly

1. Install the SG90 with its printed label facing upward.
2. Point the output shaft toward the two panel guides.
3. Route the servo wire through the opening on the opposite side.
4. Install the retaining strap with two original servo screws.
5. Face the panel markings; the shaft opening should be on your right.
6. Slide the selected panel downward between both open-top guide pairs.
7. Install the included single-arm horn outside the panel.
8. Center the servo in software before tightening the horn screw.
9. Slowly test the full 0 to 180 degree sweep before powering the project.
10. Confirm the pointer does not rub the panel, guides, or base.

If only the double-arm horn is available, mark one arm with colored tape and
use that arm as the pointer.

## Printing

- Bambu A1 mini
- PLA
- 0.20 mm Standard
- Four walls
- 20% gyroid
- Supports off
- Base: LEGO underside on the build plate
- Strap: print flat
- Panels: broad flat back on the build plate, markings upward

The markings are raised 0.6 mm and can be painted in Bambu Studio for AMS
printing or colored with a permanent marker.

# Compact Resistor LEGO Module v2.1

This streamlined pack contains the compact 40 x 24 mm resistor module with the project-standard Coupon-F LEGO underside.

## Hardware

- One 1/4 W axial resistor (47 kOhm for the PLTW voltage divider)
- Two M3 x 6 mm screws
- Two standard M3 hex nuts
- Two 9-11 mm M3 washers

The screw holes are clearances; the screws tighten into captive metal nuts. Loop each resistor lead under a washer and tighten only enough to make reliable contact.

## Print

- Bambu A1 mini, 0.20 mm Standard
- PLA, 0.4 mm nozzle
- Four walls, 20% gyroid
- Supports off
- Print in the supplied orientation with the LEGO cavity on the plate

Status: the compact terminal arrangement and Coupon-F interface were each physically fit-tested. This v2.1 combined revision should receive one pilot print before classroom quantities.

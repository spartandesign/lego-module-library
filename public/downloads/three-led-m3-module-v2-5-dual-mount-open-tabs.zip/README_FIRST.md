# PLTW Three-LED M3 Terminal Module v2.5

This revision keeps the physically successful three-LED holder, six M3
terminals, polarity labels, and Coupon-F LEGO interface from v2.3. It replaces
the earlier cardboard tabs with the open brick-style construction proven on
the compact resistor module.

## What changed

- Two external two-stud-long cardboard anchor tabs
- Confirmed 3.4 x 1.8 mm brass-fastener slits
- Shallow 9.1 mm head recesses
- Fully open tab undersides for LEGO continuation studs
- Open portals into the main LEGO cavity; no tight partition remains
- Tabs placed on the left and right ends so all six M3 nut-loading openings
  remain accessible

## Hardware

- Three 5 mm LEDs
- Six M3 x 6 mm screws
- Six standard M3 hex nuts
- Six M3 washers
- One current-limiting resistor for every LED circuit
- Two classroom brass fasteners when mounting directly to cardboard

## Printing

- Bambu 0.20 mm Standard PLA profile
- Keep the remaining Bambu settings at their defaults
- LEGO underside on the build plate
- Supports off; raft off
- Use the supplied orientation

## Assembly

1. Insert the M3 nuts through the existing side-loading openings.
2. Install each LED with its longer anode lead routed toward `+` and its shorter
   cathode lead routed toward `-`.
3. Capture each lead beneath a washer and tighten gently.
4. Always include an appropriate current-limiting resistor in the circuit.

The LED and M3 terminal arrangement was physically successful before this
revision. The new complete dual-mount combination should receive one pilot
print before classroom quantities.

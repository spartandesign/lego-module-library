# PLTW 26SMDBZ1 Piezo Buzzer Module v2.3 validation

- Exact source hash matched: `True`
- Watertight: `True`
- Winding consistent: `True`
- Connected components: `1`
- Source extents preserved: `True`
- Solid supports: `4` at 5.20 x 2.85 mm
- All support disks solid: `True`
- Open Coupon-F bores / anchors: `4`
- All clutch centerlines open: `True`
- Anchor material through Z=0.59: `True`
- Anchor material ends before Z=0.61: `True`
- Anchor notches open: `True`
- LEGO stud clearances open: `True`
- 3.6 x 1.8 mm brad collision volumes: `[0.0, 0.0] mm^3`
- Both 3.6 x 1.8 mm paths open: `True`
- Nominal M3 collision volumes: `[0.0, 0.0] mm^3`
- Required M3 sweeps zero-collision: `True`
- M3 screw axes open: `True`
- LED pockets open: `True`
- Internal head pockets open: `True`
- Internal floor retained: `True`
- Change deltas: `{'brad_capsule_removed_volume_mm3': 4.03851, 'm3_clearance_removed_volume_mm3': 0.0, 'support_added_volume_mm3': 0.0, 'net_volume_change_mm3': -4.03851}`
- Package embeds exact files: `True`
- All required checks pass: `True`

All geometry checks use the exact STL after export and reload.
A physical 3.6 mm coupon and complete module pilot remain required.

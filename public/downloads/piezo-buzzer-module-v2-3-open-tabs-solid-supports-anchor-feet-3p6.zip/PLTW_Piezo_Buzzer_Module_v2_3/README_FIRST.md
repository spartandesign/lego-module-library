# PLTW 26SMDBZ1 Piezo Buzzer Module v2.3

This package starts from the exact current v2.2 STL and
changes the classroom brass-fastener capsule from 3.4 x 1.8 mm to
3.6 x 1.8 mm. Use the **3.6 mm row** of the included 3.2 / 3.4 / 3.6 mm coupon
before printing classroom quantities.

## What changed

- Both existing cardboard capsules are lengthened by 0.20 mm total: only
  0.10 mm of material is removed at each end; width stays 1.80 mm.
- Cardboard mount style remains open X-end tabs.
- Source extents and all unrelated geometry are preserved.
- Actual brad-only removed volume: 4.038510 mm^3.
- M3-clearance removed volume: 0.000000 mm^3.
- Added solid-support volume: 0.000000 mm^3.

The v2.2 19.5 mm buzzer locator, two indexed M3 tunnels, four solid supports, four clutch anchors, and polarity geometry are unchanged.

## Retained standards

- Footprint: 5 x 3 studs / 40 x 24 mm body; 73 mm across X tabs
- Overall exported extents: 73.00 x 24.12 x 11.80 mm
- 4 full 5.20 mm-diameter x 2.85 mm safe roof supports
- 4 open Coupon-F bores with aligned 0.60 mm C anchors
- 2 indexed M3 nut paths retain zero collision for a nominal 5.50 mm-AF x 2.40 mm nut envelope.
- LED pockets: N/A.

## Printing and assembly

- PLA, 0.4 mm nozzle, 0.20 mm Standard profile
- LEGO underside on the build plate
- Supports off; raft off
- Print and test the 3.6 mm coupon row first
- Confirm LEGO seating, removal, cardboard fit, both fasteners, and the complete
  electrical/mechanical assembly before classroom quantities

Automated checks use the exact STL after export and reload. They do not replace
a physical pilot with the classroom printer, plate, hardware, and cardboard.

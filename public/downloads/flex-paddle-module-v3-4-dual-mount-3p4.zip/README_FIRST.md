# Flex sensor module v3.3 — reinforced side-loaded M3 nut clamp

This is the clamp-style alternative to the v3.1 zip-tie module.

The successful v2.8 clamp profile, 1.0 mm leveling feet, sensor supports,
paddle, three-point bending geometry, hinge, guide, and travel stop remain.
The clamp fastening and connector location are revised.

## What changed

- Both M3 nuts slide horizontally into captive pockets from opposite long sides.
- The nut pockets remain completely above the LEGO cavity.
- The four obsolete non-LEGO testbed mounting holes are removed.
- The base uses the proven resistor-module-style 3.40 mm M3 clearance holes.
- The clamp retains explicit 3.60 mm through-holes.
- The nut-pocket roof is increased from 0.62 mm to approximately 1.40 mm.
- Approximately 1.34 mm of material separates each nut from the LEGO cavity.
- Two shallow underside guides form a 7.80 mm-wide connector channel.
- The 7.20 mm reference connector has 0.30 mm nominal side clearance per side.
- The connector remains open at both ends and is not pinched by the guides.
- The proven 6.60 mm split-ring F-fit LEGO underside is retained.
- The clamp is approximately 21 mm away from the paddle envelope.

## Print

- PLA
- Bambu A1 mini, 0.20 mm Standard
- Four walls
- 20% gyroid
- Supports off
- Base with the LEGO underside on the build plate
- Clamp and coupon in their supplied flat orientations

## Hardware

- Two standard M3 hex nuts
- Two M3 x 8 mm screws

## Assembly

1. Print and check the small nut-fit coupon.
2. Slide the lower nut inward from the lower long edge.
3. Slide the upper nut inward from the upper long edge.
4. Place the flex sensor with the printed/striped conductive face upward.
5. Center only the stiff connector section between the two shallow side guides.
6. Align the clamp feet and insert the two M3 x 8 screws.
7. Tighten gently until the connector cannot lift; the guides prevent sideways
   movement.
8. Operate the paddle by hand and confirm completely free travel.

Do not clamp the active orange sensing strip and do not overtighten the screws.

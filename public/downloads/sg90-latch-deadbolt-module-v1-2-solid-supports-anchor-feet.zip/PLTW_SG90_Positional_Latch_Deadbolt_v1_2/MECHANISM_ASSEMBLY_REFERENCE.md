# Preserved mechanism assembly reference

This guide came from the last mechanism revision. The printable base in this package supersedes its underside and cardboard-mount geometry.

---

# SG90 positional latch / deadbolt module v1

This module uses the included SG90 single-arm horn as the moving bolt. The
horn rotates in a vertical plane. In the locked position it rests inside the
reinforced open-top keeper; in the unlocked position it rotates upward.

## Important horn choice

Use the single-arm horn. Do not use the double-arm horn for the full vertical
sweep because its opposite arm can strike the base.

## Assembly

1. Install the SG90 label-up with its output shaft facing the keeper.
2. Route the wire through the rear opening.
3. Install the printed retaining strap with two original servo screws.
4. Command the servo to 90 degrees before installing the horn.
5. Install the single-arm horn pointing upward and tighten its center screw.
6. Slowly move toward 0 degrees by hand or in small programmed steps.
7. Stop and adjust the programmed endpoint if the horn presses hard against
   either keeper wall or the closed end stop.

Suggested starting positions are 90 degrees for UNLOCKED and 0 degrees for
LOCKED. Actual SG90 alignment varies, so tune the final angles for your horn.

The keeper is intentionally open at the top. Students can attach a cardboard,
LEGO, or printed door tab so the horizontal horn blocks its movement.

## Printing

- Bambu A1 mini
- PLA
- 0.20 mm Standard
- Four walls
- 20% gyroid
- Supports off
- Base with LEGO underside on the build plate
- Strap flat on the build plate

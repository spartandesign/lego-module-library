# SG90 Positional Door / Flap Linkage v1.2

This revision responds to the physical potentiometer bridge failure by adding
solid roof support at every safe non-gripping underside tube while preserving
all compliant Coupon-F clutch bores. It also retains the two existing compact top-open internal cardboard-fastener paths.

## Supportless underside

- 39 non-gripping tube centers are solid through the cavity roof.
- 39 supports remain full-round.
- All 6 Coupon-F clutch bores remain open.
- Every clutch ring gains a 0.60 mm C-shaped first-layer anchor pad.
- Each anchor notch follows the ring's existing split direction.
- All 60 surrounding LEGO seating points remain clear.
- Added roof-support geometry stops at Z = 2.85 mm and cannot enter the
  mechanism or fastener geometry above the base.

## Preserved mechanism geometry

- 4.6 mm horizontal 8-32 hinge and 0.5 mm flap side clearance
- three exact link lengths: 25.5, 26.0, and 26.5 mm
- two 3.6 mm flap attachment holes and the original retaining strap

## Cardboard mounting

The retained mounting uses the classroom-selected 3.4 x 1.8 mm brass-fastener
slit. Open cavities or top-open pockets avoid hidden support material. Print
and test the included 3.2 / 3.4 / 3.6 mm coupon before a classroom batch.

## Documentation correction

Correction to the older guide: the supplied flap mesh has two 3.6 mm attachment holes. Do not describe it as three 2.2 mm flap crank holes.

## Printing

- Bambu A1 mini or comparable printer
- PLA, 0.4 mm nozzle
- Bambu 0.20 mm Standard profile
- LEGO underside on the build plate
- Supports off; raft off
- Print supplied straps, panels, links, or flaps in their flat orientation


## Pilot status

This mechanism remains a prototype. Pilot hinge cleanup, linkage binding, safe endpoints, LEGO fit, and cardboard mounting.

Inspect the cavity roof after printing. It should be carried by clean solid
columns with no loose bridge strands. Then verify full LEGO seating and removal,
cardboard seating, both brass fasteners, and the complete moving/electrical
assembly before classroom quantities.

# Preserved mechanism assembly reference

This guide came from the last mechanism revision. The printable base in this package supersedes its underside and cardboard-mount geometry.

> **Correction for this revision:** Correction to the older guide: the supplied flap mesh has two 3.6 mm attachment holes. Do not describe it as three 2.2 mm flap crank holes.


---

# SG90 positional door / flap linkage module v1

This module uses a positional SG90, the included single-arm horn, a separate
8-32 hinged flap, and a removable printed connecting link. The linkage makes
the motion visible and lets students change travel or force by selecting a
different hole on the flap crank.

## Hardware

- One SG90 positional servo
- The original single-arm servo horn and center screw
- Two original servo mounting screws
- One 8-32 x 1.75 inch screw and matching nut for the flap hinge
- Two short pieces of 0.8-1.0 mm paperclip wire for linkage pins

## Assembly

1. Install the SG90 label-up with its shaft facing the flap.
2. Route the cable through the rear opening and install the retaining strap.
3. Place the flap between the two hinge towers.
4. Pass the 8-32 screw through both towers and the flap, then add the nut.
   Tighten only enough to remove side play; the flap must rotate freely.
5. Start with the 26.0 mm link and the middle flap-crank hole.
6. Connect one end to a horn hole about 15 mm from the servo shaft and the
   other end to the flap crank using bent paperclip-wire pins.
7. Center the servo before installing the horn.
8. Move in small software steps and determine safe OPEN and CLOSED values.
   Do not command the servo beyond a point where the linkage becomes rigid.

The 25.5 and 26.5 mm links are tuning alternatives. The three crank holes let
students compare range of motion, required force, and mechanical advantage.

## Printing

- Bambu A1 mini
- PLA
- 0.20 mm Standard
- Four walls
- 20% gyroid
- Supports off
- Base: LEGO underside on the build plate
- Flap: broad flat face on the build plate
- Strap and links: print flat

The 4.6 mm horizontal hinge holes and 2.2 mm crank holes may need gentle hand
cleanup. Do not use a powered drill aggressively near the printed hinge.

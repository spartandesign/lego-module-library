from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path


CAD_DEPS = Path(r"C:\Users\trira\.codex\tmp\cad_pydeps")
sys.path.insert(0, str(CAD_DEPS))

import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont


OUTPUT_ROOT = Path(__file__).resolve().parent
LATEST_DIR = OUTPUT_ROOT.parent
FAMILY_DIR = LATEST_DIR / "18_All_Modules_InternalBrad_3Dot_v0_1"
BRAD_COUPON = (
    FAMILY_DIR / "STL" / "PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl"
)
BUZZER_AUX_DIR = Path(
    r"C:\Users\trira\.codex\.chatgpt-projects"
    r"\g-p-69c157e16fd881918ddef4f8c88b52ac"
    r"\PLTW_26SMDBZ1_Buzzer_Module_v2_0_Recreated_FFit"
)

ANCHOR_RADIUS = 3.00
ANCHOR_HEIGHT = 0.60
ANCHOR_NOTCH_LENGTH = 4.20
ANCHOR_NOTCH_WIDTH = 1.55
SUPPORT_HEIGHT = 2.85
SUPPORT_FINAL_RADIUS = 2.60
CAVITY_HEIGHT = 2.72


@dataclass(frozen=True)
class ModuleConfig:
    key: str
    title: str
    version: str
    file_prefix: str
    archive_prefix: str
    output_stl_name: str
    output_zip_name: str
    source_stl: Path
    original_zip: Path
    original_assets: tuple[str, ...]
    extra_assets: tuple[tuple[Path, str], ...]
    footprint: str
    tube_centers: tuple[tuple[float, float], ...]
    clutch_centers: tuple[tuple[float, float], ...]
    split_directions: tuple[tuple[float, float], ...]
    stud_centers: tuple[tuple[float, float], ...]
    support_plug_radius: float
    mount_mode: str
    path_centers: tuple[tuple[float, float], ...] = ()
    tab_centers_x: tuple[float, float] | None = None
    body_edges_x: tuple[float, float] | None = None
    tab_height: float = 9.50
    clearance_points: tuple[tuple[float, float, float], ...] = ()
    preserved_features: tuple[str, ...] = ()
    pilot_note: str = ""
    reference_correction: str = ""
    preview_kind: str = "horizontal"
    clutch_bore_top_z: float = 2.50
    portal_trimmed_support_centers: tuple[tuple[float, float], ...] = ()

    @property
    def output_dir(self) -> Path:
        return OUTPUT_ROOT / self.key

    @property
    def output_stl(self) -> Path:
        return self.output_dir / self.output_stl_name

    @property
    def output_zip(self) -> Path:
        return self.output_dir / self.output_zip_name


def grid(xs: tuple[float, ...], ys: tuple[float, ...]) -> tuple[tuple[float, float], ...]:
    return tuple((x, y) for x in xs for y in ys)


SHARED_TUBES = grid(
    (-24.0, -16.0, -8.0, 0.0, 8.0, 16.0, 24.0),
    (-16.0, -8.0, 0.0, 8.0, 16.0),
)
SHARED_CLUTCH = tuple(
    (x, y)
    for x in (-24.0, 0.0, 24.0)
    for y in (-16.0, 16.0)
)
SHARED_STUDS = grid(
    (-28.0, -20.0, -12.0, -4.0, 4.0, 12.0, 20.0, 28.0),
    (-20.0, -12.0, -4.0, 4.0, 12.0, 20.0),
)

VERTICAL_TUBES = grid(
    (-24.0, -16.0, -8.0, 0.0, 8.0, 16.0, 24.0),
    (-8.0, 0.0, 8.0),
)
VERTICAL_CLUTCH = tuple(
    (x, y)
    for x in (-24.0, 0.0, 24.0)
    for y in (-8.0, 8.0)
)
VERTICAL_STUDS = tuple(
    (x, y)
    for x, y in grid(
        (-28.0, -20.0, -12.0, -4.0, 4.0, 12.0, 20.0, 28.0),
        (-12.0, -4.0, 4.0, 12.0),
    )
    if not (abs(x) == 28.0 and abs(y) == 4.0)
)

DOOR_TUBES = grid(
    (-32.0, -24.0, -16.0, -8.0, 0.0, 8.0, 16.0, 24.0, 32.0),
    (-16.0, -8.0, 0.0, 8.0, 16.0),
)
DOOR_CLUTCH = tuple(
    (x, y)
    for x in (-32.0, 0.0, 32.0)
    for y in (-16.0, 16.0)
)
DOOR_STUDS = grid(
    (-36.0, -28.0, -20.0, -12.0, -4.0, 4.0, 12.0, 20.0, 28.0, 36.0),
    (-20.0, -12.0, -4.0, 4.0, 12.0, 20.0),
)

BUZZER_TUBES = grid(
    (-12.0, -4.0, 4.0, 12.0),
    (-4.0, 4.0),
)
BUZZER_CLUTCH = tuple(
    (x, y)
    for x in (-12.0, 12.0)
    for y in (-4.0, 4.0)
)
BUZZER_SPLITS = tuple(
    (-x / math.hypot(x, y), -y / math.hypot(x, y))
    for x, y in BUZZER_CLUTCH
)
BUZZER_STUDS = grid(
    (-16.0, -8.0, 0.0, 8.0, 16.0),
    (-8.0, 0.0, 8.0),
)


def servo_pilot_points(y: float) -> tuple[tuple[float, float, float], ...]:
    return tuple(
        (x, y, z)
        for x in (-17.5, 17.5)
        for z in (15.5, 18.0, 20.0)
    )


CONFIGS = (
    ModuleConfig(
        key="buzzer_v2_2",
        title="PLTW 26SMDBZ1 Piezo Buzzer Module",
        version="v2.2",
        file_prefix="PLTW_Piezo_Buzzer_v2_2",
        archive_prefix="PLTW_Piezo_Buzzer_Module_v2_2",
        output_stl_name="PLTW_26SMDBZ1_Buzzer_v2_2_DualMount.stl",
        output_zip_name=(
            "PLTW_Piezo_Buzzer_Module_v2_2_Open_Tabs_"
            "Solid_Supports_Anchor_Feet.zip"
        ),
        source_stl=(
            LATEST_DIR
            / "10_Piezo_Buzzer_v2"
            / "07_Piezo_Buzzer"
            / "PLTW_26SMDBZ1_Buzzer_v2_0_FFit_B_DEFAULT_"
            "TerminalSpacing_19p5mm.stl"
        ),
        original_zip=(
            LATEST_DIR / "10_Piezo_Buzzer_v2" / "piezo-buzzer-module-v2.zip"
        ),
        original_assets=(),
        extra_assets=(
            (
                BUZZER_AUX_DIR
                / "PLTW_26SMDBZ1_Terminal_Spacing_Coupon_A19p0_B19p5_C20p0.stl",
                "PLTW_26SMDBZ1_Terminal_Spacing_Coupon_A19p0_B19p5_C20p0.stl",
            ),
            (
                BUZZER_AUX_DIR / "PLTW_26SMDBZ1_M3_Nut_Trap_Fit_Coupon.stl",
                "PLTW_26SMDBZ1_M3_Nut_Trap_Fit_Coupon.stl",
            ),
        ),
        footprint="5 x 3 studs / 40 x 24 mm nominal body",
        tube_centers=BUZZER_TUBES,
        clutch_centers=BUZZER_CLUTCH,
        split_directions=BUZZER_SPLITS,
        stud_centers=BUZZER_STUDS,
        support_plug_radius=2.60,
        mount_mode="open_tabs",
        tab_centers_x=(-28.0, 28.0),
        body_edges_x=(-20.0, 20.0),
        clearance_points=tuple(
            [
                (x, 0.0, z)
                for x in (-9.75, 9.75)
                for z in (3.5, 6.6, 9.5)
            ]
            + [
                (-9.75, y, 6.6)
                for y in (-11.0, -8.0, -4.0, 0.0)
            ]
            + [
                (9.75, y, 6.6)
                for y in (0.0, 4.0, 8.0, 11.0)
            ]
        ),
        preserved_features=(
            "19.5 mm default terminal spacing",
            "two opposite-side M3 nut-loading tunnels",
            "shallow buzzer-board locator and polarity marks",
        ),
        pilot_note=(
            "The complete buzzer remains a prototype. Confirm the physical board, "
            "terminal spacing, M3 contact, LEGO clutch, cardboard fasteners, and sound output."
        ),
        preview_kind="buzzer",
        clutch_bore_top_z=2.30,
    ),
    ModuleConfig(
        key="servo_horizontal_v1_5",
        title="SG90 Horizontal Cradle",
        version="v1.5",
        file_prefix="PLTW_SG90_Horizontal_Cradle_v1_5",
        archive_prefix="PLTW_SG90_Horizontal_Cradle_v1_5",
        output_stl_name="PLTW_SG90_Horizontal_Cradle_v1_5_DualMount.stl",
        output_zip_name=(
            "PLTW_SG90_Horizontal_Cradle_v1_5_Internal_Paths_"
            "Solid_Supports_Anchor_Feet.zip"
        ),
        source_stl=(
            FAMILY_DIR / "STL" / "PLTW_SG90_Horizontal_Cradle_v1_4_"
            "FFit_DualMount_3p4x1p8.stl"
        ),
        original_zip=(
            LATEST_DIR / "11_SG90_Horizontal_Cradle_v1_3"
            / "sg90-horizontal-cradle-v1-3.zip"
        ),
        original_assets=(
            "PLTW_SG90_Horizontal_Cradle_v1_3_Retaining_Strap.stl",
        ),
        extra_assets=(),
        footprint="8 x 6 studs / 64 x 48 mm",
        tube_centers=SHARED_TUBES,
        clutch_centers=SHARED_CLUTCH,
        split_directions=((0.0, 1.0),) * 6,
        stud_centers=SHARED_STUDS,
        support_plug_radius=2.60,
        mount_mode="internal_paths",
        path_centers=((-20.0, -12.0), (20.0, -12.0)),
        clearance_points=servo_pilot_points(5.0),
        preserved_features=(
            "12.4 mm body fit and 1.8 mm retaining-post pilots",
            "two 8 mm label-up horn gaps",
            "central rear wire exit and exact retaining strap",
        ),
        pilot_note=(
            "Servo body and screw fit are confirmed foundations; pilot the new solid-support "
            "and dual-mount combination before classroom quantities."
        ),
    ),
    ModuleConfig(
        key="servo_vertical_v1_2",
        title="SG90 Vertical Cradle",
        version="v1.2",
        file_prefix="PLTW_SG90_Vertical_Cradle_v1_2",
        archive_prefix="PLTW_SG90_Vertical_Cradle_v1_2",
        output_stl_name="PLTW_SG90_Vertical_Cradle_v1_2_DualMount.stl",
        output_zip_name=(
            "PLTW_SG90_Vertical_Cradle_v1_2_Open_Tabs_"
            "Solid_Supports_Anchor_Feet.zip"
        ),
        source_stl=(
            FAMILY_DIR / "sources" / "servo-vertical__PLTW_SG90_"
            "Vertical_Cradle_7x3_v1_FFit_Base.stl"
        ),
        original_zip=(
            LATEST_DIR / "12_SG90_Vertical_Cradle_7x3_v1"
            / "sg90-vertical-cradle-7x3-v1.zip"
        ),
        original_assets=(),
        extra_assets=(),
        footprint=(
            "compact 56 x 24 mm body; 28 retained body seating cavities plus "
            "4 open-tab continuation cavities"
        ),
        tube_centers=VERTICAL_TUBES,
        clutch_centers=VERTICAL_CLUTCH,
        split_directions=((0.0, 1.0),) * 6,
        stud_centers=VERTICAL_STUDS,
        support_plug_radius=2.60,
        mount_mode="open_tabs",
        tab_centers_x=(-36.0, 36.0),
        body_edges_x=(-28.0, 28.0),
        clearance_points=tuple(
            (x, 0.0, z)
            for x in (-13.75, 13.75)
            for z in (19.5, 22.0, 24.5)
        ),
        preserved_features=(
            "12.5 mm body channel and 27.5 mm ear spacing",
            "1.8 mm tower pilots and both lower wire portals",
            "upright horn sweep above the 25 mm towers",
        ),
        pilot_note=(
            "Servo fit is confirmed; pilot the open-tab and solid-support combination "
            "on the classroom plate and cardboard before quantities."
        ),
        preview_kind="vertical",
        portal_trimmed_support_centers=((-24.0, 0.0), (24.0, 0.0)),
    ),
    ModuleConfig(
        key="servo_gauge_v2_0",
        title="SG90 Upright Dashboard Gauge",
        version="v2.0",
        file_prefix="PLTW_SG90_Upright_Dashboard_Gauge_v2_0",
        archive_prefix="PLTW_SG90_Upright_Dashboard_Gauge_v2_0",
        output_stl_name="PLTW_SG90_Upright_Dashboard_Gauge_v2_0_DualMount.stl",
        output_zip_name=(
            "PLTW_SG90_Upright_Dashboard_Gauge_v2_0_"
            "Solid_Supports_Anchor_Feet.zip"
        ),
        source_stl=(
            FAMILY_DIR / "STL" / "PLTW_SG90_Upright_Dashboard_v1_9_"
            "FFit_DualMount_3p4x1p8.stl"
        ),
        original_zip=(
            LATEST_DIR / "13_SG90_Dashboard_Gauge_v1_8"
            / "sg90-upright-dashboard-gauge-v1-8.zip"
        ),
        original_assets=(
            "PLTW_SG90_Gauge_Panel_v1_8_60mm_RightOpening_0_90_180.stl",
            "PLTW_SG90_Gauge_Panel_v1_8_60mm_RightOpening_P2_4_SAFE_ARMED_ALERT.stl",
            "PLTW_SG90_Gauge_Panel_v1_8_60mm_RightOpening_P3_2_READY_ACTIVE_DONE.stl",
            "PLTW_SG90_Upright_Dashboard_v1_8_Retaining_Strap.stl",
        ),
        extra_assets=(),
        footprint="8 x 6 studs / 64 x 48 mm",
        tube_centers=SHARED_TUBES,
        clutch_centers=SHARED_CLUTCH,
        split_directions=((0.0, -1.0),) * 6,
        stud_centers=SHARED_STUDS,
        support_plug_radius=2.60,
        mount_mode="internal_paths",
        path_centers=((-20.0, 12.0), (20.0, 12.0)),
        clearance_points=servo_pilot_points(-5.0),
        preserved_features=(
            "three exact 60 mm panels and their holder engagement",
            "18 mm right-side horn opening and label-up orientation",
            "raised markings, wire exit, and exact retaining strap",
        ),
        pilot_note=(
            "The panel width and gauge mechanism are confirmed foundations; pilot the "
            "new underside and complete pointer sweep before quantities."
        ),
    ),
    ModuleConfig(
        key="servo_latch_v1_2",
        title="SG90 Positional Latch / Deadbolt",
        version="v1.2",
        file_prefix="PLTW_SG90_Positional_Latch_Deadbolt_v1_2",
        archive_prefix="PLTW_SG90_Positional_Latch_Deadbolt_v1_2",
        output_stl_name="PLTW_SG90_Positional_Latch_Deadbolt_v1_2_DualMount.stl",
        output_zip_name=(
            "PLTW_SG90_Latch_Deadbolt_Module_v1_2_"
            "Solid_Supports_Anchor_Feet.zip"
        ),
        source_stl=(
            FAMILY_DIR / "STL" / "PLTW_SG90_Positional_Latch_Deadbolt_"
            "v1_1_FFit_DualMount_3p4x1p8.stl"
        ),
        original_zip=(
            LATEST_DIR / "14_SG90_Latch_Deadbolt_v1"
            / "sg90-latch-deadbolt-module-v1.zip"
        ),
        original_assets=(
            "PLTW_SG90_Positional_Latch_Deadbolt_v1_Retaining_Strap.stl",
        ),
        extra_assets=(),
        footprint="8 x 6 studs / 64 x 48 mm",
        tube_centers=SHARED_TUBES,
        clutch_centers=SHARED_CLUTCH,
        split_directions=((0.0, 1.0),) * 6,
        stud_centers=SHARED_STUDS,
        support_plug_radius=2.60,
        mount_mode="internal_paths",
        path_centers=((-20.0, -12.0), (12.0, -4.0)),
        clearance_points=(
            *servo_pilot_points(5.0),
            *((x, -19.0, z) for x in (5.0, 10.0, 16.0) for z in (10.0, 14.0, 18.0)),
        ),
        preserved_features=(
            "single-arm horn as the moving bolt",
            "reinforced open-top keeper and closed end stop",
            "90-degree unlocked / tuned-toward-zero locked workflow",
        ),
        pilot_note=(
            "This mechanism remains a prototype. Pilot the horn sweep, keeper clearance, "
            "stall-safe endpoints, LEGO fit, and cardboard mounting."
        ),
    ),
    ModuleConfig(
        key="servo_door_v1_2",
        title="SG90 Positional Door / Flap Linkage",
        version="v1.2",
        file_prefix="PLTW_SG90_Door_Flap_Linkage_v1_2",
        archive_prefix="PLTW_SG90_Door_Flap_Linkage_v1_2",
        output_stl_name="PLTW_SG90_Door_Flap_Linkage_v1_2_DualMount.stl",
        output_zip_name=(
            "PLTW_SG90_Door_Flap_Linkage_Module_v1_2_"
            "Solid_Supports_Anchor_Feet.zip"
        ),
        source_stl=(
            FAMILY_DIR / "STL" / "PLTW_SG90_Door_Flap_Linkage_v1_1_"
            "FFit_DualMount_3p4x1p8.stl"
        ),
        original_zip=(
            LATEST_DIR / "15_SG90_Door_Flap_Linkage_v1"
            / "sg90-door-flap-linkage-module-v1.zip"
        ),
        original_assets=(
            "PLTW_SG90_Door_Flap_Linkage_v1_8_32_Hinged_Flap.stl",
            "PLTW_SG90_Door_Flap_Linkage_v1_Retaining_Strap.stl",
            "PLTW_SG90_Door_Flap_Link_v1_25p5mm.stl",
            "PLTW_SG90_Door_Flap_Link_v1_26p0mm.stl",
            "PLTW_SG90_Door_Flap_Link_v1_26p5mm.stl",
        ),
        extra_assets=(),
        footprint="10 x 6 studs / 80 x 48 mm",
        tube_centers=DOOR_TUBES,
        clutch_centers=DOOR_CLUTCH,
        split_directions=((0.0, 1.0),) * 6,
        stud_centers=DOOR_STUDS,
        support_plug_radius=2.60,
        mount_mode="internal_paths",
        path_centers=((-28.0, -12.0), (28.0, -12.0)),
        clearance_points=(
            *servo_pilot_points(5.0),
            *((30.0, y, 16.0) for y in (-24.0, -21.5, -10.0, 9.5, 12.0)),
        ),
        preserved_features=(
            "4.6 mm horizontal 8-32 hinge and 0.5 mm flap side clearance",
            "three exact link lengths: 25.5, 26.0, and 26.5 mm",
            "two 3.6 mm flap attachment holes and the original retaining strap",
        ),
        pilot_note=(
            "This mechanism remains a prototype. Pilot hinge cleanup, linkage binding, "
            "safe endpoints, LEGO fit, and cardboard mounting."
        ),
        reference_correction=(
            "Correction to the older guide: the supplied flap mesh has two 3.6 mm "
            "attachment holes. Do not describe it as three 2.2 mm flap crank holes."
        ),
    ),
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cylinder_at(
    x: float,
    y: float,
    radius: float,
    height: float,
    z0: float = 0.0,
    sections: int = 64,
) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    mesh.apply_translation([x, y, z0 + height / 2.0])
    return mesh


def coupon_f_anchor(
    x: float,
    y: float,
    direction: tuple[float, float],
) -> trimesh.Trimesh:
    direction_x, direction_y = direction
    angle = math.atan2(direction_y, direction_x)
    disk = cylinder_at(x, y, ANCHOR_RADIUS, ANCHOR_HEIGHT)
    notch = trimesh.creation.box(
        extents=[ANCHOR_NOTCH_LENGTH, ANCHOR_NOTCH_WIDTH, ANCHOR_HEIGHT + 0.40]
    )
    notch.apply_transform(
        trimesh.transformations.rotation_matrix(angle, [0.0, 0.0, 1.0])
    )
    notch.apply_translation(
        [x + direction_x * 2.0, y + direction_y * 2.0, ANCHOR_HEIGHT / 2.0]
    )
    return trimesh.boolean.difference([disk, notch], engine="manifold")


def capsule_y(x: float, y: float, height: float) -> trimesh.Trimesh:
    radius = 0.90
    straight = 1.60
    middle = trimesh.creation.box(extents=[1.80, straight, height])
    middle.apply_translation([x, y, height / 2.0])
    ends = [
        cylinder_at(x, y + offset, radius, height + 2.0, z0=-1.0, sections=48)
        for offset in (-straight / 2.0, straight / 2.0)
    ]
    return trimesh.boolean.union([middle, *ends], engine="manifold")


def open_x_tab(center_x: float, tab_height: float) -> trimesh.Trimesh:
    sign = -1.0 if center_x < 0.0 else 1.0
    solid = trimesh.creation.box(extents=[17.0, 10.0, tab_height])
    solid.apply_translation([center_x, 0.0, tab_height / 2.0])

    cavity = trimesh.creation.box(extents=[16.0, 6.40, CAVITY_HEIGHT])
    cavity.apply_translation(
        [center_x - sign * 1.0, 0.0, CAVITY_HEIGHT / 2.0]
    )
    recess = cylinder_at(
        center_x,
        0.0,
        4.55,
        1.22,
        z0=tab_height - 1.22,
    )
    return trimesh.boolean.difference(
        [solid, cavity, recess, capsule_y(center_x, 0.0, tab_height)],
        engine="manifold",
    )


def support_centers(config: ModuleConfig) -> tuple[tuple[float, float], ...]:
    clutch = set(config.clutch_centers)
    return tuple(point for point in config.tube_centers if point not in clutch)


def build_module(
    config: ModuleConfig,
) -> tuple[trimesh.Trimesh, trimesh.Trimesh, list[trimesh.Trimesh], list[trimesh.Trimesh]]:
    source = trimesh.load_mesh(config.source_stl)
    supports = [
        cylinder_at(x, y, config.support_plug_radius, SUPPORT_HEIGHT)
        for x, y in support_centers(config)
    ]
    anchors = [
        coupon_f_anchor(x, y, direction)
        for (x, y), direction in zip(config.clutch_centers, config.split_directions)
    ]
    additions: list[trimesh.Trimesh] = [*supports, *anchors]
    if config.mount_mode == "open_tabs":
        assert config.tab_centers_x is not None
        additions.extend(open_x_tab(x, config.tab_height) for x in config.tab_centers_x)

    combined = trimesh.boolean.union([source, *additions], engine="manifold")
    if config.mount_mode == "open_tabs":
        assert config.body_edges_x is not None
        portals = []
        for edge_x in config.body_edges_x:
            portal = trimesh.creation.box(extents=[4.0, 6.40, CAVITY_HEIGHT])
            portal.apply_translation([edge_x, 0.0, CAVITY_HEIGHT / 2.0])
            portals.append(portal)
        result = trimesh.boolean.difference([combined, *portals], engine="manifold")
    else:
        result = combined

    result.remove_unreferenced_vertices()
    config.output_dir.mkdir(parents=True, exist_ok=True)
    result.export(config.output_stl)
    # STL stores float32 coordinates. Reload the exact exported artifact so a
    # narrow in-memory overlap cannot hide a seam that appears after export.
    exported = trimesh.load_mesh(config.output_stl, process=True)
    nondegenerate = exported.nondegenerate_faces()
    if not bool(np.all(nondegenerate)):
        exported.update_faces(nondegenerate)
        exported.remove_unreferenced_vertices()
        exported.export(config.output_stl)
        exported = trimesh.load_mesh(config.output_stl, process=True)
    exported.remove_unreferenced_vertices()
    return source, exported, supports, anchors


def extract_assets(config: ModuleConfig) -> tuple[str, ...]:
    written: list[str] = []
    with zipfile.ZipFile(config.original_zip) as archive:
        old_readme = archive.read("README_FIRST.md").decode("utf-8")
        correction = (
            f"\n\n> **Correction for this revision:** {config.reference_correction}\n"
            if config.reference_correction
            else ""
        )
        reference = (
            "# Preserved mechanism assembly reference\n\n"
            "This guide came from the last mechanism revision. The printable base "
            "in this package supersedes its underside and cardboard-mount geometry."
            f"{correction}\n\n---\n\n{old_readme}"
        )
        (config.output_dir / "MECHANISM_ASSEMBLY_REFERENCE.md").write_text(
            reference,
            encoding="utf-8",
        )
        written.append("MECHANISM_ASSEMBLY_REFERENCE.md")
        for name in config.original_assets:
            (config.output_dir / name).write_bytes(archive.read(name))
            written.append(name)

    for source, destination_name in config.extra_assets:
        (config.output_dir / destination_name).write_bytes(source.read_bytes())
        written.append(destination_name)

    (config.output_dir / BRAD_COUPON.name).write_bytes(BRAD_COUPON.read_bytes())
    written.append(BRAD_COUPON.name)
    return tuple(written)


def query_occupancy(
    mesh: trimesh.Trimesh,
    queries: dict[str, list[tuple[float, float, float]]],
) -> dict[str, list[bool]]:
    points: list[tuple[float, float, float]] = []
    ranges: dict[str, tuple[int, int]] = {}
    for name, values in queries.items():
        start = len(points)
        points.extend(values)
        ranges[name] = (start, len(points))
    values = [bool(value) for value in mesh.contains(np.asarray(points))]
    return {
        name: values[start:end]
        for name, (start, end) in ranges.items()
    }


def validate(
    config: ModuleConfig,
    source: trimesh.Trimesh,
    mesh: trimesh.Trimesh,
    assets: tuple[str, ...],
) -> dict[str, object]:
    anchor_material = []
    anchor_above = []
    anchor_notches = []
    for (x, y), (direction_x, direction_y) in zip(
        config.clutch_centers,
        config.split_directions,
    ):
        perpendicular_x, perpendicular_y = -direction_y, direction_x
        material_xy = [
            (x - direction_x * 1.50, y - direction_y * 1.50),
            (x + perpendicular_x * 1.60, y + perpendicular_y * 1.60),
            (x - perpendicular_x * 1.60, y - perpendicular_y * 1.60),
        ]
        for point_x, point_y in material_xy:
            for z in (0.05, 0.30, 0.59):
                anchor_material.append((point_x, point_y, z))
            anchor_above.append((point_x, point_y, 0.61))
        for radius in (0.0, 0.75, 1.50, 2.50):
            for z in (0.05, 0.30, 0.59):
                anchor_notches.append(
                    (x + direction_x * radius, y + direction_y * radius, z)
                )

    supports = support_centers(config)
    portal_trimmed = set(config.portal_trimmed_support_centers)
    full_round_supports = tuple(point for point in supports if point not in portal_trimmed)
    support_center_points = [
        (x, y, z)
        for x, y in full_round_supports
        for z in (0.05, 0.30, 1.40, 2.50, 2.79)
    ]
    support_disk_points = [
        (x + dx, y + dy, z)
        for x, y in supports
        for dx, dy in ((1.50, 0.0), (-1.50, 0.0), (0.0, 1.50), (0.0, -1.50))
        for z in (0.30, 2.70)
    ]
    clutch_bore_points = [
        (x, y, z)
        for x, y in config.clutch_centers
        for z in (0.05, 0.30, 0.59, 0.61, 1.40, config.clutch_bore_top_z)
    ]

    queries: dict[str, list[tuple[float, float, float]]] = {
        "anchor_material": anchor_material,
        "anchor_above": anchor_above,
        "anchor_notches": anchor_notches,
        "support_centers": support_center_points,
        "support_disks": support_disk_points,
        "portal_trimmed_support_centers": [
            (x, y, z)
            for x, y in config.portal_trimmed_support_centers
            for z in (0.05, 0.30, 1.40, 2.50, 2.79)
        ],
        "clutch_bores": clutch_bore_points,
        "studs": [(x, y, 1.40) for x, y in config.stud_centers],
        "clearances": list(config.clearance_points),
    }

    if config.mount_mode == "internal_paths":
        queries["slits"] = [
            (x, y + offset, z)
            for x, y in config.path_centers
            for offset in (-1.20, 0.0, 1.20)
            for z in (0.10, 1.40, 4.00, 5.20, 7.80)
        ]
        queries["head_pockets"] = [
            (x + dx, y + dy, z)
            for x, y in config.path_centers
            for dx, dy in ((0.0, 0.0), (3.0, 0.0), (0.0, 3.0))
            for z in (5.10, 7.80)
        ]
        queries["pocket_floors"] = [
            (x + dx, y + dy, 4.90)
            for x, y in config.path_centers
            for dx, dy in ((3.0, 0.0), (0.0, 3.0))
        ]
    else:
        assert config.tab_centers_x is not None
        assert config.body_edges_x is not None
        continuation = [
            (center_x + offset, 0.0, 1.40)
            for center_x in config.tab_centers_x
            for offset in (-4.0, 4.0)
        ]
        queries["continuation_studs"] = continuation
        queries["tab_paths"] = [
            (x, 2.30, 1.40)
            for center_x, edge_x in zip(config.tab_centers_x, config.body_edges_x)
            for x in (
                edge_x - math.copysign(1.0, edge_x),
                edge_x,
                edge_x + math.copysign(1.0, edge_x),
                center_x - math.copysign(4.0, center_x),
                center_x + math.copysign(4.0, center_x),
            )
        ]
        queries["tab_slits"] = [
            (center_x, offset, z)
            for center_x in config.tab_centers_x
            for offset in (-1.20, 0.0, 1.20)
            for z in (0.10, 4.00, config.tab_height - 0.20)
        ]

    occupancy = query_occupancy(mesh, queries)
    checks: dict[str, object] = {
        "watertight": bool(mesh.is_watertight),
        "winding_consistent": bool(mesh.is_winding_consistent),
        "components": len(mesh.split(only_watertight=False)),
        "faces": int(len(mesh.faces)),
        "bounds_mm": [[round(float(v), 3) for v in row] for row in mesh.bounds],
        "extents_mm": [round(float(v), 3) for v in mesh.extents],
        "source_extents_mm": [round(float(v), 3) for v in source.extents],
        "source_sha256": sha256(config.source_stl),
        "output_stl_sha256": sha256(config.output_stl),
        "clutch_count": len(config.clutch_centers),
        "solid_support_count": len(supports),
        "full_round_solid_support_count": len(full_round_supports),
        "portal_trimmed_solid_support_count": len(config.portal_trimmed_support_centers),
        "anchor_material_present_through_z_0p59": all(occupancy["anchor_material"]),
        "anchor_material_ends_before_z_0p61": not any(occupancy["anchor_above"]),
        "anchor_notches_open": not any(occupancy["anchor_notches"]),
        "all_clutch_centerlines_open": not any(occupancy["clutch_bores"]),
        "all_non_clutch_support_centers_solid": all(occupancy["support_centers"]),
        "all_full_round_support_disks_solid": all(occupancy["support_disks"]),
        "all_portal_trimmed_support_centerlines_solid": all(
            occupancy["portal_trimmed_support_centers"]
        ),
        "all_lego_seating_points_open": not any(occupancy["studs"]),
        "mechanism_hardware_clearances_open": not any(occupancy["clearances"]),
        "support_geometry_max_z_mm": SUPPORT_HEIGHT,
        "source_geometry_above_z_2p85_preserved_by_construction": True,
        "asset_sha256": {
            name: sha256(config.output_dir / name)
            for name in assets
        },
    }

    if config.mount_mode == "internal_paths":
        checks.update(
            {
                "cardboard_path_centers_mm": [list(point) for point in config.path_centers],
                "both_internal_slits_open": not any(occupancy["slits"]),
                "both_top_open_head_pockets_clear": not any(occupancy["head_pockets"]),
                "solid_floor_retained_around_paths": all(occupancy["pocket_floors"]),
            }
        )
        mount_checks = (
            checks["both_internal_slits_open"]
            and checks["both_top_open_head_pockets_clear"]
            and checks["solid_floor_retained_around_paths"]
        )
    else:
        checks.update(
            {
                "tab_centers_mm": [[x, 0.0] for x in config.tab_centers_x or ()],
                "four_continuation_stud_centers_open": not any(occupancy["continuation_studs"]),
                "both_tab_cavities_and_portals_open": not any(occupancy["tab_paths"]),
                "both_3p4x1p8_tab_slits_open": not any(occupancy["tab_slits"]),
            }
        )
        mount_checks = (
            checks["four_continuation_stud_centers_open"]
            and checks["both_tab_cavities_and_portals_open"]
            and checks["both_3p4x1p8_tab_slits_open"]
        )

    checks["all_required_checks_pass"] = bool(
        checks["watertight"]
        and checks["winding_consistent"]
        and checks["components"] == 1
        and checks["anchor_material_present_through_z_0p59"]
        and checks["anchor_material_ends_before_z_0p61"]
        and checks["anchor_notches_open"]
        and checks["all_clutch_centerlines_open"]
        and checks["all_non_clutch_support_centers_solid"]
        and checks["all_full_round_support_disks_solid"]
        and checks["all_portal_trimmed_support_centerlines_solid"]
        and checks["all_lego_seating_points_open"]
        and checks["mechanism_hardware_clearances_open"]
        and mount_checks
    )
    return checks


def write_readme(config: ModuleConfig) -> None:
    supports = len(support_centers(config))
    mount_description = (
        "two open brick-style X-end tabs with continuous underside portals"
        if config.mount_mode == "open_tabs"
        else "the two existing compact top-open internal cardboard-fastener paths"
    )
    features = "\n".join(f"- {item}" for item in config.preserved_features)
    correction = (
        f"\n## Documentation correction\n\n{config.reference_correction}\n"
        if config.reference_correction
        else ""
    )
    portal_note = (
        f"- {len(config.portal_trimmed_support_centers)} edge supports are intentionally "
        "trimmed by the open tab portals; their centerlines remain solid.\n"
        if config.portal_trimmed_support_centers
        else ""
    )
    accessory_print = (
        "- Print supplied straps, panels, links, or flaps in their flat orientation\n"
        if config.original_assets
        else ""
    )
    text = f"""# {config.title} {config.version}

This revision responds to the physical potentiometer bridge failure by adding
solid roof support at every safe non-gripping underside tube while preserving
all compliant Coupon-F clutch bores. It also retains {mount_description}.

## Supportless underside

- {supports} non-gripping tube centers are solid through the cavity roof.
{portal_note}- {supports - len(config.portal_trimmed_support_centers)} supports remain full-round.
- All {len(config.clutch_centers)} Coupon-F clutch bores remain open.
- Every clutch ring gains a 0.60 mm C-shaped first-layer anchor pad.
- Each anchor notch follows the ring's existing split direction.
- All {len(config.stud_centers)} surrounding LEGO seating points remain clear.
- Added roof-support geometry stops at Z = 2.85 mm and cannot enter the
  mechanism or fastener geometry above the base.

## Preserved mechanism geometry

{features}

## Cardboard mounting

The retained mounting uses the classroom-selected 3.4 x 1.8 mm brass-fastener
slit. Open cavities or top-open pockets avoid hidden support material. Print
and test the included 3.2 / 3.4 / 3.6 mm coupon before a classroom batch.
{correction}
## Printing

- Bambu A1 mini or comparable printer
- PLA, 0.4 mm nozzle
- Bambu 0.20 mm Standard profile
- LEGO underside on the build plate
- Supports off; raft off
{accessory_print}

## Pilot status

{config.pilot_note}

Inspect the cavity roof after printing. It should be carried by clean solid
columns with no loose bridge strands. Then verify full LEGO seating and removal,
cardboard seating, both brass fasteners, and the complete moving/electrical
assembly before classroom quantities.
"""
    (config.output_dir / "README_FIRST.md").write_text(text, encoding="utf-8")


def write_dimensions(config: ModuleConfig, mesh: trimesh.Trimesh) -> None:
    mount = (
        "Two open X-end brick tabs"
        if config.mount_mode == "open_tabs"
        else "Two compact top-open internal paths"
    )
    rows = [
        ("Feature", "Value"),
        ("Module", f"{config.title} {config.version}"),
        ("LEGO footprint", config.footprint),
        ("Overall mesh extents", " x ".join(f"{v:.2f}" for v in mesh.extents) + " mm"),
        ("Coupon-F clutch bores", f"{len(config.clutch_centers)} open"),
        ("C anchor feet", f"{len(config.clutch_centers)} at 6.00 x 0.60 mm"),
        ("Anchor notch", "4.20 x 1.55 mm aligned to each existing split"),
        ("Solid non-gripping roof supports", f"{len(support_centers(config))}"),
        (
            "Full-round / portal-trimmed supports",
            f"{len(support_centers(config)) - len(config.portal_trimmed_support_centers)} / "
            f"{len(config.portal_trimmed_support_centers)}",
        ),
        ("Final support diameter x height", "5.20 x 2.85 mm"),
        ("LEGO seating points validated open", str(len(config.stud_centers))),
        ("Cardboard mount", mount),
        ("Brass-fastener slit", "3.4 x 1.8 mm capsule"),
    ]
    if config.mount_mode == "open_tabs":
        rows.extend(
            [
                ("Tab body", f"17 x 10 x {config.tab_height:.2f} mm"),
                ("Tab underside cavity", "16 x 6.4 x 2.72 mm"),
                ("Tab portal", "4 x 6.4 x 2.72 mm"),
                ("Head recess", "9.1 mm diameter x 1.22 mm deep"),
            ]
        )
    else:
        rows.extend(
            [
                ("Head pockets", "8.5 mm diameter, top-open from Z=5 to Z=8"),
                ("Pocket floor", "Solid from cavity roof to Z=5 outside slit"),
            ]
        )
    with (config.output_dir / f"{config.file_prefix}_Dimensions.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        csv.writer(handle).writerows(rows)


def write_validation(config: ModuleConfig, checks: dict[str, object]) -> None:
    (config.output_dir / "MESH_AND_CLEARANCE_VALIDATION.json").write_text(
        json.dumps(checks, indent=2) + "\n",
        encoding="utf-8",
    )
    mount_lines = []
    if config.mount_mode == "internal_paths":
        mount_lines = [
            f"- Internal slits open: `{checks['both_internal_slits_open']}`",
            f"- Top-open head pockets clear: `{checks['both_top_open_head_pockets_clear']}`",
            f"- Solid pocket floor retained: `{checks['solid_floor_retained_around_paths']}`",
        ]
    else:
        mount_lines = [
            f"- Four continuation-stud centers open: `{checks['four_continuation_stud_centers_open']}`",
            f"- Tab cavities and portals open: `{checks['both_tab_cavities_and_portals_open']}`",
            f"- Both tab slits open: `{checks['both_3p4x1p8_tab_slits_open']}`",
        ]
    lines = [
        f"# {config.title} {config.version} validation",
        "",
        f"- Watertight: `{checks['watertight']}`",
        f"- Winding consistent: `{checks['winding_consistent']}`",
        f"- Connected components: `{checks['components']}`",
        f"- Solid non-clutch supports: `{checks['solid_support_count']}`",
        f"- All support centers solid: `{checks['all_non_clutch_support_centers_solid']}`",
        f"- Full-round support disks solid: `{checks['all_full_round_support_disks_solid']}`",
        f"- Portal-trimmed support centerlines solid: `{checks['all_portal_trimmed_support_centerlines_solid']}`",
        f"- Open clutch centerlines: `{checks['all_clutch_centerlines_open']}`",
        f"- C anchor material present through Z=0.59: `{checks['anchor_material_present_through_z_0p59']}`",
        f"- C anchors end before Z=0.61: `{checks['anchor_material_ends_before_z_0p61']}`",
        f"- Anchor notches open: `{checks['anchor_notches_open']}`",
        f"- LEGO seating points open: `{checks['all_lego_seating_points_open']}`",
        f"- Mechanism/hardware checks open: `{checks['mechanism_hardware_clearances_open']}`",
        *mount_lines,
        f"- Package embeds exact STL: `{checks.get('package_embeds_exact_stl', False)}`",
        f"- All required checks pass: `{checks['all_required_checks_pass']}`",
        "",
        "The solid supports address the cavity-roof failure observed in the physical potentiometer v1.2 print.",
        "A complete physical pilot remains required.",
        "",
    ]
    (config.output_dir / "MESH_AND_CLEARANCE_VALIDATION.md").write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def render_isometric(
    specs: list[tuple[trimesh.Trimesh, tuple[int, int, int]]],
    path: Path,
    title: str,
    footer: str,
    overlay_count: int = 0,
) -> None:
    view = np.array([1.0, -1.35, 0.90])
    view /= np.linalg.norm(view)
    right = np.cross(view, np.array([0.0, 0.0, 1.0]))
    right /= np.linalg.norm(right)
    up = np.cross(right, view)
    up /= np.linalg.norm(up)
    light = np.array([0.30, -0.45, 0.84])
    light /= np.linalg.norm(light)

    triangles = []
    overlays = []
    projected_all = []
    overlay_start = len(specs) - overlay_count
    for index, (mesh, color) in enumerate(specs):
        tri3 = mesh.vertices[mesh.faces]
        normals = np.cross(tri3[:, 1] - tri3[:, 0], tri3[:, 2] - tri3[:, 0])
        lengths = np.linalg.norm(normals, axis=1)
        valid = lengths > 1e-9
        normals[valid] /= lengths[valid, None]
        facing = normals @ view > -0.10
        for triangle, normal in zip(tri3[facing], normals[facing]):
            projected = np.column_stack((triangle @ right, -(triangle @ up)))
            depth = float(np.mean(triangle @ view))
            shade = 0.70 + 0.30 * max(0.0, float(normal @ light))
            shaded = tuple(max(0, min(255, int(channel * shade))) for channel in color)
            target = overlays if overlay_count and index >= overlay_start else triangles
            target.append((depth, projected, shaded))
            projected_all.append(projected)

    all_points = np.vstack(projected_all)
    low = all_points.min(axis=0)
    high = all_points.max(axis=0)
    canvas = (1500, 1000)
    margin = 110
    scale = min(
        (canvas[0] - 2 * margin) / (high[0] - low[0]),
        (canvas[1] - 2 * margin - 100) / (high[1] - low[1]),
    )
    offset = np.array(
        [
            (canvas[0] - (high[0] - low[0]) * scale) / 2 - low[0] * scale,
            100 + (canvas[1] - 175 - (high[1] - low[1]) * scale) / 2 - low[1] * scale,
        ]
    )
    image = Image.new("RGB", canvas, (247, 249, 252))
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    draw.text((45, 28), title, fill=(30, 40, 54), font=font)
    for collection in (triangles, overlays):
        for _, projected, color in sorted(collection, key=lambda item: item[0]):
            points = [
                (float(x * scale + offset[0]), float(y * scale + offset[1]))
                for x, y in projected
            ]
            draw.polygon(points, fill=color)
    draw.text((45, 955), footer, fill=(30, 40, 54), font=font)
    image.save(path)


def assembly_reference(config: ModuleConfig) -> trimesh.Trimesh:
    if config.preview_kind == "buzzer":
        board = trimesh.creation.box(extents=[24.8, 11.0, 1.0])
        # Keep the simple reference proxy just above the printable holder so the
        # lightweight painter renderer does not create intersection artifacts.
        board.apply_translation([0.0, 0.0, 12.31])
        body = trimesh.creation.box(extents=[10.6, 10.0, 5.1])
        body.apply_translation([0.0, 0.0, 15.36])
        return trimesh.util.concatenate([board, body])
    if config.preview_kind == "vertical":
        servo = trimesh.creation.box(extents=[23.0, 12.4, 22.7])
        servo.apply_translation([0.0, 0.0, 19.35])
        return servo
    servo = trimesh.creation.box(extents=[23.0, 22.7, 12.4])
    servo.apply_translation([0.0, 0.0, 14.20])
    return servo


def render_previews(
    config: ModuleConfig,
    mesh: trimesh.Trimesh,
    supports: list[trimesh.Trimesh],
    anchors: list[trimesh.Trimesh],
) -> None:
    reference = assembly_reference(config)
    render_isometric(
        [(mesh, (174, 184, 194)), (reference, (55, 122, 96))],
        config.output_dir / f"{config.file_prefix}_Assembly_Preview.png",
        f"{config.title.upper()} {config.version} - SUPPORTLESS DUAL MOUNT",
        f"{len(supports)} solid roof supports; {len(anchors)} open clutch anchors; supports off.",
    )
    render_isometric(
        [(mesh, (174, 184, 194))],
        config.output_dir / f"{config.file_prefix}_Top_Preview.png",
        f"{config.title.upper()} {config.version} - PRINTABLE BASE",
        "All mechanism geometry above the cavity roof is retained from the preceding revision.",
    )

    rotation = trimesh.transformations.rotation_matrix(math.pi, [1.0, 0.0, 0.0])
    underside = mesh.copy()
    underside.apply_transform(rotation)
    support_overlay = trimesh.util.concatenate([item.copy() for item in supports])
    support_overlay.apply_transform(rotation)
    support_overlay.apply_translation([0.0, 0.0, 0.03])
    anchor_overlay = trimesh.util.concatenate([item.copy() for item in anchors])
    anchor_overlay.apply_transform(rotation)
    anchor_overlay.apply_translation([0.0, 0.0, 0.05])
    render_isometric(
        [
            (underside, (174, 184, 194)),
            (support_overlay, (93, 151, 105)),
            (anchor_overlay, (65, 116, 168)),
        ],
        config.output_dir / f"{config.file_prefix}_Underside_Preview.png",
        f"{config.title.upper()} {config.version} - SUPPORTED UNDERSIDE",
        "Green = solid non-gripping roof supports; blue = open, split-aligned Coupon-F anchors.",
        overlay_count=2,
    )


def package_names(config: ModuleConfig, assets: tuple[str, ...]) -> list[str]:
    return [
        "README_FIRST.md",
        config.output_stl_name,
        *assets,
        f"{config.file_prefix}_Dimensions.csv",
        "MESH_AND_CLEARANCE_VALIDATION.md",
        "MESH_AND_CLEARANCE_VALIDATION.json",
        f"{config.file_prefix}_Assembly_Preview.png",
        f"{config.file_prefix}_Top_Preview.png",
        f"{config.file_prefix}_Underside_Preview.png",
    ]


def create_package(config: ModuleConfig, assets: tuple[str, ...]) -> None:
    with zipfile.ZipFile(
        config.output_zip,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for name in package_names(config, assets):
            archive.write(config.output_dir / name, f"{config.archive_prefix}/{name}")
        archive.write(
            Path(__file__),
            f"{config.archive_prefix}/SOURCE/{Path(__file__).name}",
        )


def package_embeds_exact_stl(config: ModuleConfig) -> bool:
    with zipfile.ZipFile(config.output_zip) as archive:
        data = archive.read(f"{config.archive_prefix}/{config.output_stl_name}")
    return data == config.output_stl.read_bytes()


def main() -> None:
    all_pass = True
    for config in CONFIGS:
        config.output_dir.mkdir(parents=True, exist_ok=True)
        assets = extract_assets(config)
        source, mesh, supports, anchors = build_module(config)
        checks = validate(config, source, mesh, assets)
        write_readme(config)
        write_dimensions(config, mesh)
        render_previews(config, mesh, supports, anchors)

        checks["package_embeds_exact_stl"] = False
        write_validation(config, checks)
        create_package(config, assets)
        checks["package_embeds_exact_stl"] = package_embeds_exact_stl(config)
        write_validation(config, checks)
        create_package(config, assets)

        passed = bool(checks["all_required_checks_pass"] and package_embeds_exact_stl(config))
        all_pass = all_pass and passed
        print(
            f"{config.key}|pass={passed}|watertight={checks['watertight']}|"
            f"components={checks['components']}|supports={checks['solid_support_count']}|"
            f"clutches={checks['clutch_count']}|extents={checks['extents_mm']}|"
            f"zip={config.output_zip}"
        )

    if not all_pass:
        raise SystemExit("One or more supportless module builds failed validation")


if __name__ == "__main__":
    main()

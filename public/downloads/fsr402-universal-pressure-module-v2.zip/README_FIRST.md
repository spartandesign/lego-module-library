# PLTW FSR402 Universal LEGO Pressure Module v2

This module turns the successful FSR pocket into a compact, interchangeable pressure pedestal. The FSR remains flat in its pocket. A light three-guide carrier transfers force through a centered removable puck, and three independent hard stops prevent large platform travel.

## Print first

1. `FSR402_Pocket_and_Stem_Fit_Coupon.stl`
2. `Three_Guide_Fit_Coupon.stl`
3. `M3_Nut_Trap_Fit_Coupon.stl`
4. `Top_Interface_Fit_Coupon.stl`

The base uses the **F-fit LEGO underside**: 6.60 mm clutch-tube OD, 4.80 mm ID, and a 0.90 mm relief slot. This was the best physical coupon in the project.

## Main parts

- LEGO base
- Three-guide carrier
- M3 connector clamp
- One actuator puck; start with 1.0 mm
- One interchangeable top
- Two M3 nuts and two M3 × 6 mm screws

## Bambu A1 mini

- PLA, 0.4 mm nozzle
- 0.20 mm Standard profile
- Four wall loops
- 20% gyroid; use 100% for the tiny pucks and hinge pin
- Supports off
- Print each part in the supplied orientation
- The ramp leaf is intentionally supplied on its long edge with the hinge bore vertical
- Keep elephant-foot compensation enabled/default; the LEGO interface is sensitive to first-layer expansion

Do not use automatic orientation on the base. Its LEGO cavity faces the build plate.

## Important limitations

This is a classroom trigger/input device, not a calibrated scale. FSR output varies with actuator geometry, preload, temperature, and the individual sensor. Test one full assembly before printing classroom quantities.

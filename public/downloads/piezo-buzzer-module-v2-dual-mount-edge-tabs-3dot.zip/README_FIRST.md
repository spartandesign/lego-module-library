# PLTW 26SMDBZ1 buzzer module v2.0 — recreated F-fit

This module was reconstructed from the confirmed Electronix Express product
listing and product photos. The buzzer is a 3 V self-driven module measuring
24.8 x 11.0 x 6.1 mm, with double-sided conductive + and - terminal holes.

## Print first

1. Terminal-spacing coupon
2. M3 nut-trap coupon
3. Default B base with 19.5 mm terminal spacing

Coupon mapping:

- A = 19.0 mm
- B = 19.5 mm, default
- C = 20.0 mm

Lay the physical buzzer over the coupon. Choose the row whose two M3 holes align
without forcing the PCB.

## Hardware

- Two standard M3 hex nuts
- Two M3 x 8 mm screws
- Two conductive M3 washers, 7 to 9 mm outside diameter

The buzzer's own terminal holes provide the electrical contact. The screws
clamp the metal terminal rings and give students a durable surface for
alligator clips. Do not overtighten.

## Assembly

1. Insert the left nut from the front side and the right nut from the back side.
2. Place the buzzer into the shallow top recess.
3. Orient the buzzer with minus on the left and plus on the right, matching the
   recessed marks in the base.
4. Put one washer over each terminal ring.
5. Insert the M3 x 8 screws and tighten gently into the captive nuts.
6. Connect the negative terminal to GND and the positive terminal to the
   controlled 3 V circuit connection.

## Bambu A1 mini

- PLA
- 0.20 mm Standard
- Four wall loops
- 20% gyroid
- Supports off
- LEGO underside on the build plate
- Use the same elephant-foot compensation used for the successful F coupon

The default production base remains physically unconfirmed until the actual
buzzer is checked against the terminal-spacing coupon.

Product reference:
https://www.elexp.com/products/buzzer-surface-mount

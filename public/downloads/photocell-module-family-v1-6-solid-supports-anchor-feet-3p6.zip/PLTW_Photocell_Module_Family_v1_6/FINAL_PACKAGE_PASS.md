# FINAL PASS — PLTW Photocell Module Family v1.6

Stable output marker: every model below passed the exact exported-and-reloaded geometry gate.
The packaging stage separately byte-compares every named artifact and the website-download ZIP copy.

- `photocell_ambient`: PASS — supports 8; open Coupon-F bores/C anchors 4; M3 nut paths 2; watertight one-component STL.
- `photocell_beam`: PASS — supports 8; open Coupon-F bores/C anchors 4; M3 nut paths 2; watertight one-component STL.
- `photocell_cover`: PASS — supports 8; open Coupon-F bores/C anchors 4; M3 nut paths 2; watertight one-component STL.

Common cardboard path: 3.60 x 1.80 mm. Recommended coupon choice: 3.60 mm.
Physical pilot status: still required before classroom quantities.

# Mesh and feature validation — v1.4 captive strap dual mount

Generated with OpenSCAD and independently inspected with trimesh/manifold booleans.

| Check | 2xAA | 4xAA |
|---|---:|---:|
| Overall pass | True | True |
| Watertight | True | True |
| One connected component | 1 | 1 |
| No degenerate faces | True | True |
| Pack envelope clears | True | True |
| Cable corridor clears | True | True |
| 20.0 x 1.6 full floor strap gauge clears | True | True |
| Main 2.35 mm floor material probes pass | True | True |
| Conservative outer-exit material probes pass | True | True |
| Two 6.0 mm keeper zones present | 2 | 2 |
| 18.2 mm keeper-mouth gauge clears | True | True |
| Keeper mouth bounded near 18.4 mm | True | True |
| Lifted tape meets positive retention | True | True |
| Opposing 45-degree keeper lips pass | True | True |
| All four 0.8 mm lead tapers pass | True | True |
| Minimum lead-taper root fill ratio | 0.999999 | 1.000001 |
| Complete captive strap insert passes | True | True |
| Full 4.90 x 1.70 nominal stud array has zero collision | True | True |
| Nominal stud-array overlap (mm^3) | 0.0 | 0.0 |
| All support centers are solid to roof | True | True |
| Minimum solid-post fill ratio | 1.0 | 1.0 |
| All clutch centerlines open | True | True |
| C-anchor material/height/notches pass | True | True |
| Dense brass paths open | True | True |
| Head recess envelopes open | True | True |
| Head seating points solid | True | True |
| Head recesses bounded | True | True |
| Overall extents unchanged | True | True |
| v1.3 symmetric delta localized to strap envelope | True | True |
| No new positive geometry above z=8 | True | True |
| Faces | 14364 | 21532 |
| Volume (mm^3) | 14428.556 | 25266.712 |

The support-foot test fills nearly the complete 5.20 mm nominal disk from z=0.08 to z=2.78 at every non-clutch tube center. Separate void and material probes verify open clutch centerlines, inward C gaps, anchor material below z=0.60, and no anchor closure above it.

Each brass-fastener path is tested with a tight 3.50 x 1.70 capsule through the complete base. An 8.35 mm head gauge spanning z=5.05..8.05 verifies the full recess; points below and just outside it verify the seating shoulder and bounded envelope.

A complete nominal LEGO stud array (4.90 mm diameter x 1.70 mm high) is checked at x=-28..28 in 8 mm steps and y=-16..16 for 2xAA or y=-32..32 for 4xAA. Zero boolean intersection verifies that the skirt, solid posts, open clutch tubes, and C-anchor notches preserve the seating paths.

The captive route is tested with a 20.00 x 1.60 mm gauge resting at z=4.90..6.50. Each 6.00 mm keeper core receives mouth, edge-material, lifted-retention, and paired void/material probes along its declared 45-degree underside.

Material probes verify the main floor immediately below z=4.80 and both exterior exits immediately below z=4.05. The main nominal floor is 2.35 above the cavity roof. The 1.60 exit figure is deliberately conservative because the lead-out's lowest point is over the solid perimeter, not open cavity.

Every 0.80 mm lead taper is sampled at its midpoint on both X sides. Paired void/lip probes verify gradual entry geometry, and structural root probes near x=+/-11.10 verify continuous material. Lift retention must intersect at least 3.00 mm^3 of keeper material per zone.

A bidirectional v1.3/v1.4 boolean comparison masks only the declared captive-strap envelope. It requires zero unmasked symmetric difference and independently verifies that new keeper material does not extend above the z=8 body plane.

This is digital validation. Pilot-print one module and the included 3.6 mm brad coupon before classroom batch production.

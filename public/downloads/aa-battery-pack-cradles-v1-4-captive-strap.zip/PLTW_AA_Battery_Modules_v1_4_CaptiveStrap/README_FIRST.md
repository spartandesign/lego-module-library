# PLTW AA battery modules v1.4 — captive strap dual mount

Two matching supportless cradles with a captive route for the confirmed 3/4-inch strap plus recessed cardboard brass-fastener mounting.

## Print files

- `PLTW_2801AA2JST_2xAA_Cradle_v1_4_CaptiveStrap_DualMount_3p6.stl`
- `PLTW_2801AA4PWR_4xAA_Cradle_v1_4_CaptiveStrap_DualMount_3p6.stl`
- `PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl` — copied standard coupon; use the 3.6 section

## Editable source and verification

- `PLTW_AA_Battery_Modules_v1_4_CaptiveStrap.scad`
- `build_and_validate_v1_4.py`
- `DIMENSION_SUMMARY.md`, `MESH_VALIDATION.md`, and `ASSEMBLY_AND_USAGE.md`

Two 6 mm keeper cores hold the loose tape below opposing 45-degree lips. The 18.40 mm upper mouth retains the nominal 19.05 mm tape while the deep floor clears a 20.00 x 1.60 mm validation gauge. Thread the tape through both keepers before installing the battery holder; hot glue is unnecessary.

The non-clutch underside locations remain solid roof posts. The six selected Medium-fit clutch tubes remain open and use thin, inward-notched C anchors. Two recessed 3.6 x 1.8 mm brass-fastener paths are centered 40 mm apart. All additions stay at or below the z=8 body plane and print with supports off.

Status: digitally validated prototype. Test one module and the 3.6 mm coupon before classroom production.

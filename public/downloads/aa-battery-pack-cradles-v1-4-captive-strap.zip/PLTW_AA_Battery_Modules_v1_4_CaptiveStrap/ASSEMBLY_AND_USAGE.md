# Printing, assembly, and use

## Print

- PLA, 0.20 mm layers, four walls, approximately 20% gyroid.
- Print in the supplied orientation: hollow underside and C-anchor faces on the build plate, cradle opening upward.
- Supports off. The solid roof posts and 0.60 mm C anchors build directly from the plate.
- Pilot-print and check the 3.6 mm section of `PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl` before making a classroom batch.

## 3/4-inch non-adhesive strap

Only the tape width, 3/4 inch (19.05 mm), was confirmed from the actual material. The 1.60 mm value is a deliberately conservative digital validation gauge, not a measured or manufacturer-specified tape thickness. Pilot-fit the actual tape in one printed module before batch production. Stop if it will not slide beneath both keepers without force; do not stretch the tape or pry the printed lips.

1. Remove the holder and batteries. Feed the end of the 3/4-inch tape along the deep transverse channel and through the first 6 mm keeper.
2. If the cut end catches, tilt one tape edge under one 45-degree lip, gently bow the tape, then tuck the opposite edge under the opposing lip. Slide rather than pulling the hook surface hard across a printed edge.
3. Continue through the second keeper until the tape lies flat on the deep floor with roughly equal tails on both sides. Do not twist or fold it beneath a keeper.
4. Set the battery holder over the seated tape with its wires aligned to the wide cable relief. Wrap the tails over the cells and press the hook-and-loop faces together, tightening only enough to stop rattling.
5. Hot glue is unnecessary: the two integral keeper zones retain the loose strap whenever the holder is removed. Keeping the tape removable also makes inspection and replacement easier.

## Cardboard and brass paper fasteners

1. Use the 3.6 mm coupon result to confirm the intended brass-fastener fit before forcing hardware into a finished module.
2. Mark the cardboard at 40 mm center-to-center using the two internal recesses as a template. Punch clean holes in the cardboard.
3. With the holder and batteries removed, pass the brass fasteners through the two X-axis capsule paths and the cardboard. Seat each head fully in its 8.50 mm recess; do not leave a proud metal head beneath the battery holder.
4. Spread the legs flat on the far side of the cardboard and cover exposed legs if students can touch them. Do not overtighten or crush corrugated board.
5. Inspect the cardboard, fasteners, printed seats, leads, and strap before every use. Replace torn board or loose hardware.
6. To return the module to LEGO use, remove both brass fasteners and all cardboard first, then inspect the hollow underside before seating it on studs.

Installed brads/cardboard and LEGO mounting are mutually exclusive. Never press the module onto LEGO studs while either brass fastener or cardboard remains installed through the underside. The hook-and-loop strap may be used with either mounting method. Keep all conductive fastener parts away from battery contacts and bare wire ends.

## Electrical safety

- The 2xAA/JST pack is the low-voltage micro:bit pack.
- Never plug the 4xAA pack into the micro:bit battery socket. Four alkaline cells are about 6 V, while official micro:bit documentation gives a 3.6 V maximum operating supply.
- Treat the 4xAA bare leads as a separate external supply for the intended classroom circuit; verify polarity and follow the PLTW wiring diagram.

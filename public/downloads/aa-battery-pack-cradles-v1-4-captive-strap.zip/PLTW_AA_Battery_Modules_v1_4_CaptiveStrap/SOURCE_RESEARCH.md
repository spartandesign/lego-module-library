# Verified dimensions and design inputs

## User-supplied requirements

- The reusable, non-adhesive hook-and-loop tape on hand is 3/4 inch (19.05 mm) wide.
- The user requested cardboard brass-fastener inserts and solid, supportless anchor feet.
- The user requested an integral insert that retains the loose strap in the module body.
- This revision preserves the v1.3 3.6 mm dual-brad/supportless underside and adds two supportless captive-strap keeper zones.

## Battery holders

The PLTW 44PLTWMCRBT bill of materials identifies the exact supplied parts `2801AA2JST` and `2801AA4PWR`. Same-SKU supplier listings provide the holder envelopes used in the CAD.

- PLTW BOM: https://www.pltw.org/hubfs/operations/equipment_supplies/gateway_bill_of_materials/CSIM_Microbit_Kit_44PLTWMCRBT.pdf
- 2xAA supplier: https://www.sciencepurchase.com/products/aa-battery-holder-for-2-aa-batteries-with-jst-connector-2-26-x-1-25-x-0-59
- 4xAA supplier: https://www.sciencepurchase.com/products/aa-4-battery-holder-with-wire-leads-holds-four-aa-batteries
- Official micro:bit power guidance: https://tech.microbit.org/hardware/powersupply/

The brass-fastener dimensions are design geometry and must be confirmed with the included physical fit coupon; they are not claimed as a universal brad standard.

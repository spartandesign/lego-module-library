from __future__ import annotations

import csv
import hashlib
import json
import math
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path


CAD_DEPS = Path(r"C:\Users\trira\.codex\tmp\cad_pydeps")
sys.path.insert(0, str(CAD_DEPS))

import numpy as np
import trimesh


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "PLTW_AA_Battery_Modules_v1_4_CaptiveStrap.scad"
OPENSCAD = Path(r"C:\Program Files\OpenSCAD\openscad.com")
COUPON_SOURCE = Path(
    r"C:\Users\trira\OneDrive\Documents\Innovators and Makers\IM testbed"
    r"\02_LATEST_NEEDS_TESTING\18_All_Modules_InternalBrad_3Dot_v0_1"
    r"\STL\PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl"
)

# Established Medium-fit modular standard.
PITCH = 8.00
BASE_HEIGHT = 8.00
CAVITY_DEPTH = 2.45
RAIL_HEIGHT = 7.00
CLEARANCE_PER_SIDE = 0.80
WIRE_CORNER_STOP = 6.00

# User-confirmed 3/4-inch, non-adhesive hook-and-loop tape route. The v1.4
# route is 3.20 mm deep across its complete Y span so a deliberately oversized
# 20.0 x 1.6 mm validation strap can sit below both retention lips.
STRAP_WIDTH = 19.05
STRAP_GAUGE_WIDTH = 20.00
STRAP_GAUGE_HEIGHT = 1.60
STRAP_CHANNEL_FLOOR_WIDTH = 21.00
STRAP_CHANNEL_TOP_WIDTH = 22.00
V1_3_STRAP_CHANNEL_DEPTH = 1.80
STRAP_CHANNEL_DEPTH = 3.20
STRAP_EXIT_CHAMFER = 0.75

# Captive-strap insert. Each module has two 6 mm core keeper zones with 0.8 mm
# root-only lead tapers at each end. Opposing 45-degree undersides narrow the
# upper mouth while leaving the full seated floor gauge free.
KEEPER_ZONE_LENGTH = 6.00
KEEPER_ZONE_COUNT = 2
KEEPER_ZONE_CENTER_INSET = 11.25
KEEPER_ROOT_LEAD_TAPER = 0.80
KEEPER_TOTAL_ENVELOPE_LENGTH = KEEPER_ZONE_LENGTH + 2 * KEEPER_ROOT_LEAD_TAPER
KEEPER_MOUTH_WIDTH = 18.40
KEEPER_MOUTH_TOLERANCE = 0.20
KEEPER_LIP_ANGLE_DEG = 45.00
KEEPER_LIP_OVERHANG = (STRAP_CHANNEL_FLOOR_WIDTH - KEEPER_MOUTH_WIDTH) / 2
KEEPER_SLOPE_HEIGHT = KEEPER_LIP_OVERHANG
KEEPER_VERTICAL_TIP_HEIGHT = 0.40
KEEPER_TOTAL_LIP_HEIGHT = KEEPER_SLOPE_HEIGHT + KEEPER_VERTICAL_TIP_HEIGHT
KEEPER_ROOT_OUTER_HALF_WIDTH = 11.60
KEEPER_DEEP_CHANNEL_DEPTH = STRAP_CHANNEL_DEPTH
KEEPER_FLOOR_CLEARANCE = 0.10
KEEPER_TOP_Z = BASE_HEIGHT
KEEPER_SLOPE_TOP_Z = KEEPER_TOP_Z - KEEPER_VERTICAL_TIP_HEIGHT
KEEPER_LIP_BOTTOM_Z = KEEPER_TOP_Z - KEEPER_TOTAL_LIP_HEIGHT
KEEPER_DEEP_FLOOR_Z = BASE_HEIGHT - KEEPER_DEEP_CHANNEL_DEPTH

# Keep boolean probes slightly away from exact CAD boundaries.
KEEPER_ZONE_END_MARGIN = 0.25
KEEPER_MOUTH_GAUGE_WIDTH = KEEPER_MOUTH_WIDTH - KEEPER_MOUTH_TOLERANCE
KEEPER_RETENTION_GAUGE_WIDTH = STRAP_GAUGE_WIDTH
KEEPER_RETENTION_GAUGE_HEIGHT = STRAP_GAUGE_HEIGHT
KEEPER_RETENTION_LIFT_Z = KEEPER_LIP_BOTTOM_Z + 0.10
KEEPER_RETENTION_MIN_VOLUME = 3.00
KEEPER_SLOPE_PROBE_DIAMETER = 0.16
KEEPER_TAPER_PROBE_DIAMETER = 0.12
STRAP_CHANGE_ENVELOPE_MARGIN_XY = 0.35
STRAP_CHANGE_ENVELOPE_Z0 = (
    KEEPER_DEEP_FLOOR_Z - STRAP_EXIT_CHAMFER - 0.10
)
STRAP_CHANGE_ENVELOPE_Z1 = BASE_HEIGHT + 0.10

# Remaining floor structure above the nominal 2.45 mm cavity roof. The exit
# lead-out reaches z=4.05 only over the perimeter solid; 1.60 mm is therefore a
# deliberately conservative comparison to the cavity-roof plane.
MAIN_FLOOR_LOW_Z = CAVITY_DEPTH
MAIN_FLOOR_HIGH_Z = KEEPER_DEEP_FLOOR_Z
MAIN_FLOOR_NOMINAL_THICKNESS = MAIN_FLOOR_HIGH_Z - MAIN_FLOOR_LOW_Z
OUTER_EXIT_LOW_Z = KEEPER_DEEP_FLOOR_Z - STRAP_EXIT_CHAMFER
OUTER_EXIT_CONSERVATIVE_THICKNESS = OUTER_EXIT_LOW_Z - CAVITY_DEPTH

# v1.3 cardboard/brass-fastener and supportless underside details, preserved
# unchanged in v1.4.
BRAD_CENTERS = ((-20.0, 0.0), (20.0, 0.0))
BRAD_SLOT_LENGTH = 3.60
BRAD_SLOT_WIDTH = 1.80
BRAD_SLOT_LONG_AXIS = "X"
BRAD_HEAD_DIAMETER = 8.50
BRAD_HEAD_RECESS_DEPTH = 3.00

SOLID_POST_DIAMETER = 5.20
SOLID_POST_HEIGHT = 2.85
CLUTCH_ANCHOR_DIAMETER = 6.00
CLUTCH_ANCHOR_HEIGHT = 0.60
CLUTCH_ANCHOR_NOTCH_WIDTH = 1.55
CLUTCH_ANCHOR_NOTCH_LENGTH = 4.20
SELECTED_CLUTCH_COUNT = 6

# Gauges sit slightly inside nominal CAD surfaces so faceting and STL floating
# point noise cannot create false failures.
MATERIAL_FILL_MIN = 0.995
VOID_VOLUME_TOLERANCE = 0.001
SOLID_POST_GAUGE_DIAMETER = 4.90
SOLID_POST_GAUGE_Z0 = 0.08
SOLID_POST_GAUGE_HEIGHT = 2.70
# The C split reaches only 0.10 mm past the exact bore center on its outward
# side.  Use a true centerline probe here; the separate 3.70 x 1.25 mm notch
# gauge verifies the useful opening from the center to the outside rim.
CLUTCH_CENTERLINE_GAUGE_DIAMETER = 0.08
# Stop below the z=2.45 cavity roof.  The clutch receives a nominal 1.80 mm
# stud; extending this gauge into the intentionally solid roof is not a bore
# clearance test.
CLUTCH_CENTERLINE_GAUGE_HEIGHT = 2.30
CLUTCH_NOTCH_GAUGE_WIDTH = 1.25
CLUTCH_NOTCH_GAUGE_LENGTH = 3.70
BRAD_SLOT_GAUGE_LENGTH = 3.50
BRAD_SLOT_GAUGE_WIDTH = 1.70
BRAD_HEAD_GAUGE_DIAMETER = 8.35
BRAD_HEAD_GAUGE_DEPTH = 3.00
STUD_GAUGE_DIAMETER = 4.90
STUD_GAUGE_HEIGHT = 1.70

MODULES = {
    "2AA": {
        "title": "2xAA JST battery cradle, captive strap/brass-fastener mount",
        "part": "2AA_CAPTIVE",
        "sku": "2801AA2JST",
        "pack_mm": [57.40, 31.75, 15.00],
        "lead": "approximately 145 mm paired lead with 2-pin JST plug",
        "footprint_studs": [8, 5],
        "cable_side": -1,
        "v1_3_stl": "PLTW_2801AA2JST_2xAA_Cradle_v1_3_DualMount_3p6.stl",
        "stl": "PLTW_2801AA2JST_2xAA_Cradle_v1_4_CaptiveStrap_DualMount_3p6.stl",
    },
    "4AA": {
        "title": "4xAA bare-lead battery cradle, captive strap/brass-fastener mount",
        "part": "4AA_CAPTIVE",
        "sku": "2801AA4PWR",
        "pack_mm": [57.80, 62.00, 15.00],
        "lead": "approximately 152 mm separate red/black pre-stripped leads",
        "footprint_studs": [8, 9],
        "cable_side": 1,
        "v1_3_stl": "PLTW_2801AA4PWR_4xAA_Cradle_v1_3_DualMount_3p6.stl",
        "stl": "PLTW_2801AA4PWR_4xAA_Cradle_v1_4_CaptiveStrap_DualMount_3p6.stl",
    },
}


def run(command: list[str]) -> None:
    result = subprocess.run(
        command,
        cwd=ROOT,
        check=False,
        text=True,
        capture_output=True,
    )
    if result.returncode != 0:
        raise RuntimeError(
            "Command failed:\n"
            + " ".join(command)
            + "\nSTDOUT:\n"
            + result.stdout
            + "\nSTDERR:\n"
            + result.stderr
        )
    if result.stderr.strip():
        print(result.stderr.strip())


def export_stl(spec: dict[str, object], output: Path) -> None:
    run(
        [
            str(OPENSCAD),
            "-o",
            str(output),
            "-D",
            f'part="{spec["part"]}"',
            "-D",
            # Match the released v1.3 curve resolution so the regression
            # compares like-for-like tessellation.
            "facet_count=64",
            str(SOURCE),
        ]
    )


def export_preview(part: str, output: Path) -> None:
    run(
        [
            str(OPENSCAD),
            "-o",
            str(output),
            "--render",
            "--imgsize=1600,1000",
            "--projection=ortho",
            "--autocenter",
            "--viewall",
            "--colorscheme=Tomorrow Night",
            "-D",
            f'part="{part}"',
            "-D",
            "facet_count=48",
            str(SOURCE),
        ]
    )


def load_mesh(path: Path) -> trimesh.Trimesh:
    loaded = trimesh.load(path, process=True)
    if isinstance(loaded, trimesh.Scene):
        loaded = loaded.to_geometry()
    if not isinstance(loaded, trimesh.Trimesh):
        raise TypeError(f"Expected a mesh in {path}")
    return loaded


def clean_exported_stl(path: Path) -> None:
    """Remove collapsed triangles without changing the closed solid."""
    mesh = load_mesh(path)
    if not mesh.is_volume:
        raise ValueError(f"OpenSCAD export is not a closed volume: {path.name}")
    original_volume = abs(float(mesh.volume))
    original_bounds = mesh.bounds.copy()
    # OpenSCAD can emit zero-area facet pairs where several coplanar Boolean
    # boundaries meet.  Re-running the same solid through manifold removes
    # those bookkeeping facets.  The larger cradle needs up to three passes;
    # every pass must preserve the exact volume and bounds.
    for _ in range(4):
        if bool(np.all(mesh.nondegenerate_faces())):
            break
        mesh = trimesh.boolean.union([mesh], engine="manifold")
        if mesh is None or len(mesh.faces) == 0:
            raise ValueError(f"Mesh cleanup Boolean failed: {path.name}")
    trimesh.repair.fix_normals(mesh)
    preserved = bool(
        np.isclose(abs(float(mesh.volume)), original_volume, atol=0.001, rtol=0.0)
        and np.allclose(mesh.bounds, original_bounds, atol=1e-7, rtol=0.0)
    )
    if (
        not mesh.is_volume
        or not bool(np.all(mesh.nondegenerate_faces()))
        or not preserved
    ):
        raise ValueError(f"Mesh cleanup failed: {path.name}")
    mesh.export(path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def intersection_volume(a: trimesh.Trimesh, b: trimesh.Trimesh) -> float:
    result = trimesh.boolean.intersection([a, b], engine="manifold")
    if result is None or len(result.faces) == 0:
        return 0.0
    return abs(float(result.volume))


def material_fill(mesh: trimesh.Trimesh, probe: trimesh.Trimesh) -> float:
    probe_volume = abs(float(probe.volume))
    if probe_volume <= 0.0:
        raise ValueError("Material probe has no volume")
    return intersection_volume(mesh, probe) / probe_volume


def union_meshes(meshes: list[trimesh.Trimesh]) -> trimesh.Trimesh:
    if not meshes:
        raise ValueError("Cannot union an empty mesh list")
    if len(meshes) == 1:
        return meshes[0]
    result = trimesh.boolean.union(meshes, engine="manifold")
    if result is None or len(result.faces) == 0:
        raise ValueError("Probe union failed")
    return result


def z_cylinder(diameter: float, height: float, center: tuple[float, float, float]) -> trimesh.Trimesh:
    shape = trimesh.creation.cylinder(radius=diameter / 2, height=height, sections=48)
    shape.apply_translation(center)
    return shape


def oriented_box(
    extents: tuple[float, float, float],
    center: tuple[float, float, float],
    angle_radians: float,
) -> trimesh.Trimesh:
    shape = trimesh.creation.box(extents=extents)
    if abs(angle_radians) > 1e-12:
        shape.apply_transform(
            trimesh.transformations.rotation_matrix(angle_radians, [0, 0, 1])
        )
    shape.apply_translation(center)
    return shape


def capsule(
    length: float,
    width: float,
    height: float,
    center: tuple[float, float, float],
    angle_radians: float = 0.0,
) -> trimesh.Trimesh:
    """Closed XY capsule extruded along Z; `length` is the full long axis."""
    if length < width:
        raise ValueError("Capsule length must be at least its width")
    straight = length - width
    pieces = [trimesh.creation.box(extents=[straight, width, height])]
    for x in (-straight / 2, straight / 2):
        end = trimesh.creation.cylinder(radius=width / 2, height=height, sections=48)
        end.apply_translation([x, 0, 0])
        pieces.append(end)
    shape = union_meshes(pieces)
    if abs(angle_radians) > 1e-12:
        shape.apply_transform(
            trimesh.transformations.rotation_matrix(angle_radians, [0, 0, 1])
        )
    shape.apply_translation(center)
    return shape


def reference_pack(spec: dict[str, object]) -> trimesh.Trimesh:
    pack = trimesh.creation.box(extents=np.asarray(spec["pack_mm"], dtype=float))
    pack.apply_translation(
        [0.0, 0.0, BASE_HEIGHT + float(spec["pack_mm"][2]) / 2 + 0.02]
    )
    return pack


def cable_corridor(spec: dict[str, object]) -> trimesh.Trimesh:
    pack_length, pack_width, _ = spec["pack_mm"]
    nx, _ = spec["footprint_studs"]
    base_length = nx * PITCH
    pocket_length = pack_length + 2 * CLEARANCE_PER_SIDE
    pocket_width = pack_width + 2 * CLEARANCE_PER_SIDE
    gap_width = pocket_width - 2 * WIRE_CORNER_STOP
    x_inner = pocket_length / 2 - 0.20
    x_outer = base_length / 2 + 0.20
    corridor_length = x_outer - x_inner
    center_x = spec["cable_side"] * (x_inner + x_outer) / 2
    corridor = trimesh.creation.box(
        extents=[corridor_length, gap_width - 0.40, RAIL_HEIGHT - 0.30]
    )
    corridor.apply_translation(
        [center_x, 0.0, BASE_HEIGHT + 0.15 + (RAIL_HEIGHT - 0.30) / 2]
    )
    return corridor


def tape_gauge(spec: dict[str, object]) -> trimesh.Trimesh:
    """Full-width strap resting on the captive route's deep floor."""
    _, ny = spec["footprint_studs"]
    base_width = ny * PITCH
    gauge = trimesh.creation.box(
        extents=[STRAP_GAUGE_WIDTH, base_width + 0.80, STRAP_GAUGE_HEIGHT]
    )
    gauge_z = (
        KEEPER_DEEP_FLOOR_Z
        + KEEPER_FLOOR_CLEARANCE
        + STRAP_GAUGE_HEIGHT / 2
    )
    gauge.apply_translation([0.0, 0.0, gauge_z])
    return gauge


def keeper_zone_centers_y(spec: dict[str, object]) -> tuple[float, float]:
    """Centers of the two keeper cores, inset by the declared edge value."""
    _, ny = spec["footprint_studs"]
    base_width = ny * PITCH
    offset = base_width / 2 - KEEPER_ZONE_CENTER_INSET
    return (-offset, offset)


def validate_channel_floor_material(
    mesh: trimesh.Trimesh, spec: dict[str, object]
) -> dict[str, object]:
    """Confirm material remains below the deep route and its exit lead-outs."""
    centers_y = keeper_zone_centers_y(spec)
    main_z0 = MAIN_FLOOR_LOW_Z + 0.05
    main_z1 = MAIN_FLOOR_HIGH_Z - 0.05
    main_fills: list[float] = []
    for y in (0.0, *centers_y):
        probe = trimesh.creation.box(extents=[0.30, 0.30, main_z1 - main_z0])
        probe.apply_translation([0.0, y, (main_z0 + main_z1) / 2])
        main_fills.append(material_fill(mesh, probe))

    # The 0.75 mm exit lead-out bottoms at z=4.05 over the perimeter solid.
    # Probe just below that plane on both sides. Reporting 1.60 mm relative to
    # the nominal cavity roof is conservative because the perimeter is solid
    # below z=2.45 as well.
    _, ny = spec["footprint_studs"]
    base_half_width = ny * PITCH / 2
    exit_z0 = CAVITY_DEPTH + 0.05
    exit_z1 = OUTER_EXIT_LOW_Z - 0.05
    exit_fills: list[float] = []
    for side in (-1.0, 1.0):
        y = side * (base_half_width - 0.08)
        probe = trimesh.creation.box(extents=[0.30, 0.12, exit_z1 - exit_z0])
        probe.apply_translation([0.0, y, (exit_z0 + exit_z1) / 2])
        exit_fills.append(material_fill(mesh, probe))

    main_pass = min(main_fills, default=0.0) >= MATERIAL_FILL_MIN
    exit_pass = min(exit_fills, default=0.0) >= MATERIAL_FILL_MIN
    return {
        "main_floor_z_range_mm": [MAIN_FLOOR_LOW_Z, MAIN_FLOOR_HIGH_Z],
        "main_floor_nominal_thickness_mm": MAIN_FLOOR_NOMINAL_THICKNESS,
        "minimum_main_floor_material_fill_ratio": round(
            min(main_fills, default=0.0), 6
        ),
        "main_floor_material_present_below_z4_80": main_pass,
        "outer_exit_low_z_mm": OUTER_EXIT_LOW_Z,
        "outer_exit_conservative_thickness_above_cavity_roof_mm": (
            OUTER_EXIT_CONSERVATIVE_THICKNESS
        ),
        "outer_exit_is_over_perimeter_solid": True,
        "minimum_outer_exit_material_fill_ratio": round(
            min(exit_fills, default=0.0), 6
        ),
        "outer_exit_material_present_below_z4_05": exit_pass,
        "channel_floor_and_exit_material_pass": bool(main_pass and exit_pass),
    }


def validate_captive_strap(
    mesh: trimesh.Trimesh, spec: dict[str, object]
) -> dict[str, object]:
    """Verify floor clearance, opposing 45-degree lips, and lift retention."""
    centers_y = keeper_zone_centers_y(spec)
    usable_zone_length = KEEPER_ZONE_LENGTH - 2 * KEEPER_ZONE_END_MARGIN
    floor_overlap = intersection_volume(mesh, tape_gauge(spec))
    mouth_overlaps: list[float] = []
    mouth_edge_fills: list[float] = []
    lifted_overlaps: list[float] = []
    slope_void_overlaps: list[float] = []
    slope_material_fills: list[float] = []
    taper_void_overlaps: list[float] = []
    taper_lip_fills: list[float] = []
    taper_root_fills: list[float] = []

    # Probe just below the top plane, where the two lips define the narrowest
    # mouth. An 18.20 mm gauge must pass; small probes immediately outside the
    # nominal 18.40 mm mouth must be printed material on both sides.
    mouth_probe_height = 0.10
    mouth_probe_z = KEEPER_TOP_Z - 0.08
    for center_y in centers_y:
        mouth = trimesh.creation.box(
            extents=[KEEPER_MOUTH_GAUGE_WIDTH, usable_zone_length, mouth_probe_height]
        )
        mouth.apply_translation([0.0, center_y, mouth_probe_z])
        mouth_overlaps.append(intersection_volume(mesh, mouth))

        core_sample_ys = (
            center_y - KEEPER_ZONE_LENGTH / 2 + 0.35,
            center_y,
            center_y + KEEPER_ZONE_LENGTH / 2 - 0.35,
        )
        for sample_y in core_sample_ys:
            for side in (-1.0, 1.0):
                edge_x = side * (KEEPER_MOUTH_WIDTH / 2 + 0.18)
                edge = z_cylinder(
                    KEEPER_SLOPE_PROBE_DIAMETER,
                    mouth_probe_height,
                    (edge_x, sample_y, mouth_probe_z),
                )
                mouth_edge_fills.append(material_fill(mesh, edge))

        # A strap lifted off the deep floor must meet both lips. This probe is
        # confined to the open strap corridor, so any intersection is the
        # deliberate retention geometry rather than a cradle wall.
        lifted = trimesh.creation.box(
            extents=[
                KEEPER_RETENTION_GAUGE_WIDTH,
                usable_zone_length,
                KEEPER_RETENTION_GAUGE_HEIGHT,
            ]
        )
        lifted.apply_translation(
            [
                0.0,
                center_y,
                KEEPER_RETENTION_LIFT_Z
                + KEEPER_RETENTION_GAUGE_HEIGHT / 2,
            ]
        )
        lifted_overlaps.append(intersection_volume(mesh, lifted))

        # At a true 45-degree underside the X transition moves outward by the
        # same distance that Z moves downward. Two separated height samples,
        # on both sides of both keepers, verify void immediately inward and
        # material immediately outward from that expected transition.
        for sample_y in core_sample_ys:
            for z in (
                KEEPER_LIP_BOTTOM_Z + 0.28,
                KEEPER_SLOPE_TOP_Z - 0.28,
            ):
                transition_half_width = (
                    KEEPER_MOUTH_WIDTH / 2 + (KEEPER_SLOPE_TOP_Z - z)
                )
                for side in (-1.0, 1.0):
                    inward_x = side * (transition_half_width - 0.16)
                    outward_x = side * (transition_half_width + 0.16)
                    inward_probe = z_cylinder(
                        KEEPER_SLOPE_PROBE_DIAMETER,
                        0.12,
                        (inward_x, sample_y, z),
                    )
                    outward_probe = z_cylinder(
                        KEEPER_SLOPE_PROBE_DIAMETER,
                        0.12,
                        (outward_x, sample_y, z),
                    )
                    slope_void_overlaps.append(
                        intersection_volume(mesh, inward_probe)
                    )
                    slope_material_fills.append(material_fill(mesh, outward_probe))

        # Each core has two 0.80 mm longitudinal lead tapers. At each taper's
        # midpoint, the upper inner boundary is halfway from x=+/-9.20 to
        # x=+/-10.50. Void/material probes distinguish a real taper from both
        # a full abrupt lip and a missing lip. The x=+/-11.10 probes verify a
        # continuous structural root throughout every lead.
        taper_z = KEEPER_SLOPE_TOP_Z + KEEPER_VERTICAL_TIP_HEIGHT / 2
        taper_fraction = 0.50
        taper_inner_half_width = (
            KEEPER_MOUTH_WIDTH / 2
            + taper_fraction
            * (STRAP_CHANNEL_FLOOR_WIDTH / 2 - KEEPER_MOUTH_WIDTH / 2)
        )
        for end_sign in (-1.0, 1.0):
            taper_y = center_y + end_sign * (
                KEEPER_ZONE_LENGTH / 2 + KEEPER_ROOT_LEAD_TAPER / 2
            )
            for side in (-1.0, 1.0):
                void_x = side * (taper_inner_half_width - 0.20)
                lip_x = side * (taper_inner_half_width + 0.20)
                root_x = side * (KEEPER_ROOT_OUTER_HALF_WIDTH - 0.50)
                void_probe = z_cylinder(
                    KEEPER_TAPER_PROBE_DIAMETER,
                    0.10,
                    (void_x, taper_y, taper_z),
                )
                lip_probe = z_cylinder(
                    KEEPER_TAPER_PROBE_DIAMETER,
                    0.10,
                    (lip_x, taper_y, taper_z),
                )
                root_probe = z_cylinder(
                    KEEPER_TAPER_PROBE_DIAMETER,
                    0.10,
                    (root_x, taper_y, taper_z),
                )
                taper_void_overlaps.append(intersection_volume(mesh, void_probe))
                taper_lip_fills.append(material_fill(mesh, lip_probe))
                taper_root_fills.append(material_fill(mesh, root_probe))

    floor_is_open = floor_overlap <= VOID_VOLUME_TOLERANCE
    mouth_is_open = max(mouth_overlaps, default=0.0) <= VOID_VOLUME_TOLERANCE
    mouth_is_bounded = min(mouth_edge_fills, default=0.0) >= MATERIAL_FILL_MIN
    retained_when_lifted = (
        min(lifted_overlaps, default=0.0) >= KEEPER_RETENTION_MIN_VOLUME
    )
    slope_voids_open = max(slope_void_overlaps, default=0.0) <= VOID_VOLUME_TOLERANCE
    slope_material_present = (
        min(slope_material_fills, default=0.0) >= MATERIAL_FILL_MIN
    )
    lips_pass = bool(slope_voids_open and slope_material_present)
    taper_voids_open = (
        max(taper_void_overlaps, default=0.0) <= VOID_VOLUME_TOLERANCE
    )
    taper_lips_present = min(taper_lip_fills, default=0.0) >= MATERIAL_FILL_MIN
    taper_roots_present = min(taper_root_fills, default=0.0) >= MATERIAL_FILL_MIN
    tapers_pass = bool(taper_voids_open and taper_lips_present and taper_roots_present)

    return {
        "keeper_zone_count": len(centers_y),
        "keeper_zone_centers_y_mm": [round(value, 3) for value in centers_y],
        "keeper_zone_length_mm": KEEPER_ZONE_LENGTH,
        "keeper_mouth_nominal_mm": KEEPER_MOUTH_WIDTH,
        "keeper_mouth_clear_gauge_mm": KEEPER_MOUTH_GAUGE_WIDTH,
        "keeper_lip_angle_degrees": KEEPER_LIP_ANGLE_DEG,
        "deep_channel_floor_z_mm": KEEPER_DEEP_FLOOR_Z,
        "floor_tape_gauge_mm": [STRAP_GAUGE_WIDTH, STRAP_GAUGE_HEIGHT],
        "floor_tape_gauge_overlap_mm3": round(floor_overlap, 6),
        "20_0_x_1_6_floor_tape_gauge_is_open": floor_is_open,
        "maximum_keeper_mouth_gauge_overlap_mm3": round(
            max(mouth_overlaps, default=0.0), 6
        ),
        "keeper_mouth_gauge_is_open": mouth_is_open,
        "minimum_keeper_mouth_edge_fill_ratio": round(
            min(mouth_edge_fills, default=0.0), 6
        ),
        "keeper_mouth_is_bounded_near_18_4_mm": mouth_is_bounded,
        "minimum_lifted_strap_retention_overlap_mm3": round(
            min(lifted_overlaps, default=0.0), 6
        ),
        "required_lifted_strap_retention_overlap_mm3": (
            KEEPER_RETENTION_MIN_VOLUME
        ),
        "lifted_strap_has_positive_retention": retained_when_lifted,
        "maximum_45_degree_lip_void_probe_overlap_mm3": round(
            max(slope_void_overlaps, default=0.0), 6
        ),
        "minimum_45_degree_lip_material_fill_ratio": round(
            min(slope_material_fills, default=0.0), 6
        ),
        "opposing_45_degree_keeper_lips_pass": lips_pass,
        "keeper_lead_taper_count": len(centers_y) * 2,
        "maximum_lead_taper_void_probe_overlap_mm3": round(
            max(taper_void_overlaps, default=0.0), 6
        ),
        "minimum_lead_taper_lip_fill_ratio": round(
            min(taper_lip_fills, default=0.0), 6
        ),
        "minimum_lead_taper_root_fill_ratio": round(
            min(taper_root_fills, default=0.0), 6
        ),
        "all_0_8_mm_lead_tapers_pass": tapers_pass,
        "captive_strap_insert_pass": bool(
            len(centers_y) == KEEPER_ZONE_COUNT
            and floor_is_open
            and mouth_is_open
            and mouth_is_bounded
            and retained_when_lifted
            and lips_pass
            and tapers_pass
        ),
    }


def nominal_stud_array(spec: dict[str, object]) -> trimesh.Trimesh:
    """Nominal mating-stud envelope across the complete LEGO footprint."""
    nx, ny = spec["footprint_studs"]
    x_values = [-nx * PITCH / 2 + PITCH / 2 + index * PITCH for index in range(nx)]
    y_values = [-ny * PITCH / 2 + PITCH / 2 + index * PITCH for index in range(ny)]
    studs = [
        z_cylinder(
            STUD_GAUGE_DIAMETER,
            STUD_GAUGE_HEIGHT,
            (x, y, STUD_GAUGE_HEIGHT / 2),
        )
        for x in x_values
        for y in y_values
    ]
    return union_meshes(studs)


def tube_centers(spec: dict[str, object]) -> tuple[list[tuple[float, float]], list[tuple[float, float]]]:
    nx, ny = spec["footprint_studs"]
    size_x = nx * PITCH
    size_y = ny * PITCH
    edge_x = (nx - 2) * PITCH / 2
    edge_y = (ny - 2) * PITCH / 2
    selected: list[tuple[float, float]] = []
    solid: list[tuple[float, float]] = []
    for ix in range(1, nx):
        for iy in range(1, ny):
            x = -size_x / 2 + ix * PITCH
            y = -size_y / 2 + iy * PITCH
            is_selected = (
                abs(abs(y) - edge_y) < 0.01
                and (abs(abs(x) - edge_x) < 0.01 or abs(x) < 0.01)
            )
            (selected if is_selected else solid).append((x, y))
    return selected, solid


def validate_solid_posts(mesh: trimesh.Trimesh, spec: dict[str, object]) -> dict[str, object]:
    _, solid = tube_centers(spec)
    results = []
    for x, y in solid:
        probe = z_cylinder(
            SOLID_POST_GAUGE_DIAMETER,
            SOLID_POST_GAUGE_HEIGHT,
            (x, y, SOLID_POST_GAUGE_Z0 + SOLID_POST_GAUGE_HEIGHT / 2),
        )
        results.append(material_fill(mesh, probe))
    failures = [solid[index] for index, value in enumerate(results) if value < MATERIAL_FILL_MIN]
    return {
        "expected_solid_post_count": len(solid),
        "solid_post_centers_mm": [[x, y] for x, y in solid],
        "solid_post_probe_diameter_mm": SOLID_POST_GAUGE_DIAMETER,
        "solid_post_probe_height_mm": SOLID_POST_GAUGE_HEIGHT,
        "minimum_solid_post_fill_ratio": round(min(results), 6),
        "solid_post_failed_centers_mm": [[x, y] for x, y in failures],
        "all_non_clutch_centers_have_solid_posts_to_roof": not failures,
    }


def inward_unit(x: float, y: float) -> np.ndarray:
    vector = np.asarray([-x, -y], dtype=float)
    length = float(np.linalg.norm(vector))
    if length <= 0:
        raise ValueError("Selected clutch center cannot be at the origin")
    return vector / length


def validate_clutch_anchors(mesh: trimesh.Trimesh, spec: dict[str, object]) -> dict[str, object]:
    selected, _ = tube_centers(spec)
    centerline_overlap = []
    notch_overlap = []
    lower_anchor_fill = []
    above_anchor_overlap = []

    for x, y in selected:
        inward = inward_unit(x, y)
        perpendicular = np.asarray([-inward[1], inward[0]])
        angle = math.atan2(float(inward[1]), float(inward[0]))

        centerline = z_cylinder(
            CLUTCH_CENTERLINE_GAUGE_DIAMETER,
            CLUTCH_CENTERLINE_GAUGE_HEIGHT,
            (x, y, 0.05 + CLUTCH_CENTERLINE_GAUGE_HEIGHT / 2),
        )
        centerline_overlap.append(intersection_volume(mesh, centerline))

        # The nominal 4.20 mm cutter is centered 2.00 mm inward, so it starts
        # just beyond the bore center and opens completely through the inward
        # circumference. Keep the gauge 0.25 mm inside both long ends.
        notch_center_xy = np.asarray([x, y]) + inward * 2.00
        notch = oriented_box(
            (CLUTCH_NOTCH_GAUGE_LENGTH, CLUTCH_NOTCH_GAUGE_WIDTH, 0.44),
            (float(notch_center_xy[0]), float(notch_center_xy[1]), 0.28),
            angle,
        )
        notch_overlap.append(intersection_volume(mesh, notch))

        # These two small points lie inside the normal 4.95 mm clutch opening,
        # but outside the radial notch. They can only be filled by the 0.60 mm
        # C-anchor. The identical points must be open just above that anchor.
        for sign in (-1.0, 1.0):
            point_xy = np.asarray([x, y]) + perpendicular * 1.45 * sign
            lower = z_cylinder(
                0.34,
                0.38,
                (float(point_xy[0]), float(point_xy[1]), 0.28),
            )
            upper = z_cylinder(
                0.34,
                0.28,
                (float(point_xy[0]), float(point_xy[1]), 0.82),
            )
            lower_anchor_fill.append(material_fill(mesh, lower))
            above_anchor_overlap.append(intersection_volume(mesh, upper))

    centerlines_open = max(centerline_overlap, default=0.0) <= VOID_VOLUME_TOLERANCE
    notches_open = max(notch_overlap, default=0.0) <= VOID_VOLUME_TOLERANCE
    anchors_present = min(lower_anchor_fill, default=0.0) >= MATERIAL_FILL_MIN
    anchors_end_by_height = max(above_anchor_overlap, default=0.0) <= VOID_VOLUME_TOLERANCE
    return {
        "selected_clutch_count": len(selected),
        "selected_clutch_centers_mm": [[x, y] for x, y in selected],
        "clutch_centerline_probe_diameter_mm": CLUTCH_CENTERLINE_GAUGE_DIAMETER,
        "maximum_clutch_centerline_overlap_mm3": round(max(centerline_overlap, default=0.0), 6),
        "all_selected_clutch_centerlines_are_open": centerlines_open,
        "maximum_inward_notch_gauge_overlap_mm3": round(max(notch_overlap, default=0.0), 6),
        "all_c_anchor_inward_notches_are_open": notches_open,
        "minimum_c_anchor_material_fill_ratio": round(min(lower_anchor_fill, default=0.0), 6),
        "c_anchor_material_is_present_inside_clutch_openings": anchors_present,
        "maximum_material_above_c_anchor_height_mm3": round(max(above_anchor_overlap, default=0.0), 6),
        "c_anchors_end_at_or_below_0_60_mm": anchors_end_by_height,
        "c_anchor_presence_height_and_notches_pass": bool(
            len(selected) == SELECTED_CLUTCH_COUNT
            and centerlines_open
            and notches_open
            and anchors_present
            and anchors_end_by_height
        ),
    }


def validate_brad_mounts(mesh: trimesh.Trimesh) -> dict[str, object]:
    slot_overlaps = []
    head_overlaps = []
    seat_fills = []
    boundary_fills = []

    for x, y in BRAD_CENTERS:
        slot = capsule(
            BRAD_SLOT_GAUGE_LENGTH,
            BRAD_SLOT_GAUGE_WIDTH,
            BASE_HEIGHT + 0.30,
            (x, y, BASE_HEIGHT / 2),
        )
        slot_overlaps.append(intersection_volume(mesh, slot))

        head = z_cylinder(
            BRAD_HEAD_GAUGE_DIAMETER,
            BRAD_HEAD_GAUGE_DEPTH,
            # Probe the complete required recess from z=5.05 through z=8.05.
            (x, y, 6.55),
        )
        head_overlaps.append(intersection_volume(mesh, head))

        # Four points around the through-slot verify a solid shoulder directly
        # below the recess, so a brass head has a real seating surface.
        for dx, dy in ((0.0, 2.8), (0.0, -2.8), (2.8, 2.0), (-2.8, -2.0)):
            seat = z_cylinder(0.36, 0.28, (x + dx, y + dy, 4.80))
            seat_fills.append(material_fill(mesh, seat))

        # Eight points just outside the nominal head circle detect an
        # accidentally oversized or misplaced recess envelope.
        for angle in np.linspace(0.0, 2.0 * math.pi, 8, endpoint=False):
            radius = BRAD_HEAD_DIAMETER / 2 + 0.28
            boundary = z_cylinder(
                0.22,
                2.40,
                (
                    x + radius * math.cos(float(angle)),
                    y + radius * math.sin(float(angle)),
                    6.50,
                ),
            )
            boundary_fills.append(material_fill(mesh, boundary))

    slots_open = max(slot_overlaps, default=0.0) <= VOID_VOLUME_TOLERANCE
    heads_open = max(head_overlaps, default=0.0) <= VOID_VOLUME_TOLERANCE
    seats_present = min(seat_fills, default=0.0) >= MATERIAL_FILL_MIN
    envelope_bounded = min(boundary_fills, default=0.0) >= MATERIAL_FILL_MIN
    return {
        "brad_centers_mm": [list(center) for center in BRAD_CENTERS],
        "brad_slot_long_axis": BRAD_SLOT_LONG_AXIS,
        "maximum_dense_brad_path_overlap_mm3": round(max(slot_overlaps, default=0.0), 6),
        "dense_brad_paths_are_open_through_base": slots_open,
        "maximum_head_recess_gauge_overlap_mm3": round(max(head_overlaps, default=0.0), 6),
        "head_recess_envelopes_are_open": heads_open,
        "minimum_brad_seating_point_fill_ratio": round(min(seat_fills, default=0.0), 6),
        "brad_head_seating_points_are_solid": seats_present,
        "minimum_head_recess_boundary_fill_ratio": round(min(boundary_fills, default=0.0), 6),
        "head_recesses_stay_inside_nominal_envelopes": envelope_bounded,
        "brad_paths_recesses_and_seats_pass": bool(
            slots_open and heads_open and seats_present and envelope_bounded
        ),
    }


def captive_strap_regression(
    mesh: trimesh.Trimesh, spec: dict[str, object]
) -> dict[str, object]:
    """Require the complete v1.3-to-v1.4 symmetric delta to stay in the strap envelope."""
    reference_path = (
        ROOT.parent
        / "PLTW_AA_Battery_Modules_v1_3_DualMount"
        / str(spec["v1_3_stl"])
    )
    if not reference_path.exists():
        return {
            "v1_3_regression_checked": False,
            "v1_3_symmetric_delta_localized_to_strap_envelope": None,
            "v1_3_minus_v1_4_outside_strap_envelope_mm3": None,
            "v1_4_minus_v1_3_outside_strap_envelope_mm3": None,
            "v1_4_positive_geometry_above_z8_mm3": None,
            "no_new_positive_geometry_above_z8": None,
        }

    nx, ny = spec["footprint_studs"]
    full_clip = trimesh.creation.box(
        extents=[nx * PITCH + 2.0, ny * PITCH + 2.0, BASE_HEIGHT + RAIL_HEIGHT + 1.0]
    )
    full_clip.apply_translation([0.0, 0.0, (BASE_HEIGHT + RAIL_HEIGHT) / 2])

    envelope_height = STRAP_CHANGE_ENVELOPE_Z1 - STRAP_CHANGE_ENVELOPE_Z0
    envelope_width = (
        2 * KEEPER_ROOT_OUTER_HALF_WIDTH
        + 2 * STRAP_CHANGE_ENVELOPE_MARGIN_XY
    )
    allowed_change = trimesh.creation.box(
        extents=[
            envelope_width,
            ny * PITCH + 1.20 + 2 * STRAP_CHANGE_ENVELOPE_MARGIN_XY,
            envelope_height,
        ]
    )
    allowed_change.apply_translation(
        [0.0, 0.0, STRAP_CHANGE_ENVELOPE_Z0 + envelope_height / 2]
    )
    comparison_region = trimesh.boolean.difference(
        [full_clip, allowed_change], engine="manifold"
    )
    reference = load_mesh(reference_path)
    old_outside = trimesh.boolean.intersection(
        [reference, comparison_region], engine="manifold"
    )
    new_outside = trimesh.boolean.intersection(
        [mesh, comparison_region], engine="manifold"
    )
    old_only = trimesh.boolean.difference(
        [old_outside, new_outside], engine="manifold"
    )
    new_only = trimesh.boolean.difference(
        [new_outside, old_outside], engine="manifold"
    )
    old_only_volume = (
        0.0
        if old_only is None or len(old_only.faces) == 0
        else abs(float(old_only.volume))
    )
    new_only_volume = (
        0.0
        if new_only is None or len(new_only.faces) == 0
        else abs(float(new_only.volume))
    )
    matches = old_only_volume <= 0.005 and new_only_volume <= 0.005

    # The captive insert must stay within the body/floor plane. Compare only
    # new material (not the existing cradle walls) above z=8.
    positive_delta = trimesh.boolean.difference([mesh, reference], engine="manifold")
    above_height = RAIL_HEIGHT + 0.80
    above_clip = trimesh.creation.box(
        extents=[nx * PITCH + 2.0, ny * PITCH + 2.0, above_height]
    )
    above_clip.apply_translation(
        [0.0, 0.0, BASE_HEIGHT + 0.02 + above_height / 2]
    )
    positive_above = (
        None
        if positive_delta is None or len(positive_delta.faces) == 0
        else trimesh.boolean.intersection(
            [positive_delta, above_clip], engine="manifold"
        )
    )
    positive_above_volume = (
        0.0
        if positive_above is None or len(positive_above.faces) == 0
        else abs(float(positive_above.volume))
    )
    no_positive_above = positive_above_volume <= 0.005

    return {
        "v1_3_regression_checked": True,
        "strap_change_envelope_xyz_mm": [
            round(envelope_width, 3),
            round(ny * PITCH + 1.20 + 2 * STRAP_CHANGE_ENVELOPE_MARGIN_XY, 3),
            round(envelope_height, 3),
        ],
        "strap_change_envelope_z_range_mm": [
            STRAP_CHANGE_ENVELOPE_Z0,
            STRAP_CHANGE_ENVELOPE_Z1,
        ],
        "v1_3_symmetric_delta_localized_to_strap_envelope": matches,
        "v1_3_minus_v1_4_outside_strap_envelope_mm3": round(
            old_only_volume, 6
        ),
        "v1_4_minus_v1_3_outside_strap_envelope_mm3": round(
            new_only_volume, 6
        ),
        "v1_4_positive_geometry_above_z8_mm3": round(
            positive_above_volume, 6
        ),
        "no_new_positive_geometry_above_z8": no_positive_above,
    }


def topology(mesh: trimesh.Trimesh) -> dict[str, object]:
    edge_counts = np.bincount(mesh.edges_unique_inverse)
    return {
        "watertight": bool(mesh.is_watertight),
        "winding_consistent": bool(mesh.is_winding_consistent),
        "connected_components": int(len(mesh.split(only_watertight=False))),
        "every_edge_has_two_incident_faces": bool(len(edge_counts) and np.all(edge_counts == 2)),
        "no_degenerate_faces": bool(np.all(mesh.nondegenerate_faces())),
        "no_duplicate_faces": bool(np.all(mesh.unique_faces())),
        "finite_vertices_and_normals": bool(
            np.all(np.isfinite(mesh.vertices)) and np.all(np.isfinite(mesh.face_normals))
        ),
        "vertices": int(len(mesh.vertices)),
        "faces": int(len(mesh.faces)),
        "bounds_mm": [[round(float(value), 5) for value in row] for row in mesh.bounds],
        "extents_mm": [round(float(value), 5) for value in mesh.extents],
        "volume_mm3": round(abs(float(mesh.volume)), 3),
    }


def validate_one(key: str, spec: dict[str, object]) -> dict[str, object]:
    path = ROOT / str(spec["stl"])
    mesh = load_mesh(path)
    top = topology(mesh)
    pack_overlap = intersection_volume(mesh, reference_pack(spec))
    corridor_overlap = intersection_volume(mesh, cable_corridor(spec))
    gauge_overlap = intersection_volume(mesh, tape_gauge(spec))
    stud_array_overlap = intersection_volume(mesh, nominal_stud_array(spec))
    posts = validate_solid_posts(mesh, spec)
    anchors = validate_clutch_anchors(mesh, spec)
    brads = validate_brad_mounts(mesh)
    floor_material = validate_channel_floor_material(mesh, spec)
    captive = validate_captive_strap(mesh, spec)
    regression = captive_strap_regression(mesh, spec)

    nx, ny = spec["footprint_studs"]
    expected_extents = np.asarray([nx * PITCH, ny * PITCH, BASE_HEIGHT + RAIL_HEIGHT])
    extents_match = bool(np.allclose(mesh.extents, expected_extents, atol=0.05, rtol=0.0))
    pocket = [
        round(float(spec["pack_mm"][0]) + 2 * CLEARANCE_PER_SIDE, 3),
        round(float(spec["pack_mm"][1]) + 2 * CLEARANCE_PER_SIDE, 3),
    ]
    wire_gap = round(pocket[1] - 2 * WIRE_CORNER_STOP, 3)

    checks = {
        **top,
        "sha256": sha256(path),
        "file_bytes": path.stat().st_size,
        "pack_reference_overlap_mm3": round(pack_overlap, 6),
        "pack_reference_has_clearance": pack_overlap <= VOID_VOLUME_TOLERANCE,
        "full_height_cable_corridor_overlap_mm3": round(corridor_overlap, 6),
        "full_height_cable_corridor_is_open": corridor_overlap <= VOID_VOLUME_TOLERANCE,
        "tape_gauge_overlap_mm3": round(gauge_overlap, 6),
        "20_0_x_1_6_tape_gauge_is_open": gauge_overlap <= VOID_VOLUME_TOLERANCE,
        "nominal_stud_array_gauge_mm": [STUD_GAUGE_DIAMETER, STUD_GAUGE_HEIGHT],
        "nominal_stud_array_overlap_mm3": round(stud_array_overlap, 6),
        "nominal_stud_array_has_zero_collision": stud_array_overlap <= VOID_VOLUME_TOLERANCE,
        **posts,
        **anchors,
        **brads,
        **floor_material,
        **captive,
        **regression,
        "expected_extents_mm": expected_extents.tolist(),
        "overall_extents_unchanged": extents_match,
        "footprint_studs": f"{nx} x {ny}",
        "footprint_mm": [nx * PITCH, ny * PITCH],
        "documented_pack_mm": spec["pack_mm"],
        "drop_in_pocket_mm": pocket,
        "clearance_per_side_mm": CLEARANCE_PER_SIDE,
        "wire_end_full_height_gap_mm": wire_gap,
    }
    checks["pass"] = bool(
        checks["watertight"]
        and checks["winding_consistent"]
        and checks["connected_components"] == 1
        and checks["every_edge_has_two_incident_faces"]
        and checks["no_degenerate_faces"]
        and checks["no_duplicate_faces"]
        and checks["finite_vertices_and_normals"]
        and checks["pack_reference_has_clearance"]
        and checks["full_height_cable_corridor_is_open"]
        and checks["20_0_x_1_6_tape_gauge_is_open"]
        and checks["nominal_stud_array_has_zero_collision"]
        and checks["all_non_clutch_centers_have_solid_posts_to_roof"]
        and checks["c_anchor_presence_height_and_notches_pass"]
        and checks["brad_paths_recesses_and_seats_pass"]
        and checks["channel_floor_and_exit_material_pass"]
        and checks["captive_strap_insert_pass"]
        and checks["overall_extents_unchanged"]
        and checks["v1_3_regression_checked"]
        and checks["v1_3_symmetric_delta_localized_to_strap_envelope"]
        and checks["no_new_positive_geometry_above_z8"]
    )
    return checks


def write_dimension_csv(records: dict[str, dict[str, object]]) -> None:
    with (ROOT / "DIMENSIONS.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "module",
                "sku",
                "documented holder L x W x H (mm)",
                "LEGO footprint",
                "printable L x W x H (mm)",
                "full-span strap channel floor/top/depth (mm)",
                "keeper core zones / total envelope (mm)",
                "keeper center Y coordinates (mm)",
                "keeper mouth / root width (mm)",
                "keeper 45-degree run / vertical tip (mm)",
                "brad centers (mm)",
                "brad capsule L x W (mm)",
                "head recess diameter x depth (mm)",
                "solid roof posts",
                "solid post diameter x height (mm)",
                "C anchors",
                "C-anchor diameter x height (mm)",
                "C-anchor notch width x length (mm)",
            ]
        )
        for key, spec in MODULES.items():
            record = records[key]
            writer.writerow(
                [
                    key,
                    spec["sku"],
                    " x ".join(f"{value:g}" for value in spec["pack_mm"]),
                    record["footprint_studs"],
                    " x ".join(f"{value:g}" for value in record["extents_mm"]),
                    f"{STRAP_CHANNEL_FLOOR_WIDTH:g} / {STRAP_CHANNEL_TOP_WIDTH:g} / {STRAP_CHANNEL_DEPTH:g}",
                    f"2 x {KEEPER_ZONE_LENGTH:g} / {KEEPER_TOTAL_ENVELOPE_LENGTH:g}",
                    "; ".join(f"{value:g}" for value in record["keeper_zone_centers_y_mm"]),
                    f"{KEEPER_MOUTH_WIDTH:g} / {2 * KEEPER_ROOT_OUTER_HALF_WIDTH:g}",
                    f"{KEEPER_SLOPE_HEIGHT:g} / {KEEPER_VERTICAL_TIP_HEIGHT:g}",
                    "(-20, 0); (20, 0)",
                    f"{BRAD_SLOT_LENGTH:g} x {BRAD_SLOT_WIDTH:g}",
                    f"{BRAD_HEAD_DIAMETER:g} x {BRAD_HEAD_RECESS_DEPTH:g}",
                    record["expected_solid_post_count"],
                    f"{SOLID_POST_DIAMETER:g} x {SOLID_POST_HEIGHT:g}",
                    record["selected_clutch_count"],
                    f"{CLUTCH_ANCHOR_DIAMETER:g} x {CLUTCH_ANCHOR_HEIGHT:g}",
                    f"{CLUTCH_ANCHOR_NOTCH_WIDTH:g} x {CLUTCH_ANCHOR_NOTCH_LENGTH:g}",
                ]
            )


def write_reports(records: dict[str, dict[str, object]], coupon_included: bool) -> None:
    dimensions = f"""# Dimension summary — v1.4 captive-strap dual-mount modules

All dimensions are millimetres.

| Item | 2xAA | 4xAA |
|---|---:|---:|
| PLTW / vendor SKU | {MODULES['2AA']['sku']} | {MODULES['4AA']['sku']} |
| Holder body L x W x H | 57.4 x 31.75 x 15.0 | 57.8 x 62.0 x 15.0 |
| LEGO footprint | 8 x 5 studs (64 x 40) | 8 x 9 studs (64 x 72) |
| Printable L x W x H | 64 x 40 x 15 | 64 x 72 x 15 |
| Solid roof posts | {records['2AA']['expected_solid_post_count']} | {records['4AA']['expected_solid_post_count']} |
| Selected Medium-fit clutch positions | 6 | 6 |

## Captive strap insert

- Strap: 19.05 confirmed tape width; validated with a deliberately larger 20.00 x 1.60 seated gauge. The 1.60 height is a digital fit gauge, not a measured tape-thickness claim.
- Full-span route: 21.00 floor, 22.00 top, and {KEEPER_DEEP_CHANNEL_DEPTH:.2f} deep across the complete Y path. Its floor is z={KEEPER_DEEP_FLOOR_Z:.2f}. The seated gauge occupies z={KEEPER_DEEP_FLOOR_Z + KEEPER_FLOOR_CLEARANCE:.2f}..{KEEPER_DEEP_FLOOR_Z + KEEPER_FLOOR_CLEARANCE + STRAP_GAUGE_HEIGHT:.2f}.
- Nominal material above the hollow-cavity roof is {MAIN_FLOOR_NOMINAL_THICKNESS:.2f} (z={CAVITY_DEPTH:.2f}..{KEEPER_DEEP_FLOOR_Z:.2f}). The 0.75 mm exit lead-out bottoms at z={OUTER_EXIT_LOW_Z:.2f}, a conservative {OUTER_EXIT_CONSERVATIVE_THICKNESS:.2f} above the cavity-roof plane; that lowest exit point lies over the solid perimeter.
- Two {KEEPER_ZONE_LENGTH:.2f}-long keeper cores per module, centered at Y={records['2AA']['keeper_zone_centers_y_mm']} for 2xAA and Y={records['4AA']['keeper_zone_centers_y_mm']} for 4xAA.
- Each core has a {KEEPER_ROOT_LEAD_TAPER:.2f} root-only lead taper at both ends ({KEEPER_TOTAL_ENVELOPE_LENGTH:.2f} total envelope).
- Opposing supportless lips: {KEEPER_MOUTH_WIDTH:.2f} mouth (inner X=+/-{KEEPER_MOUTH_WIDTH / 2:.2f}), roots at X=+/-{KEEPER_ROOT_OUTER_HALF_WIDTH:.2f}.
- The underside rises {KEEPER_SLOPE_HEIGHT:.2f} in Z while moving {KEEPER_LIP_OVERHANG:.2f} in X (45 degrees), from z={KEEPER_LIP_BOTTOM_Z:.2f} to z={KEEPER_SLOPE_TOP_Z:.2f}; a {KEEPER_VERTICAL_TIP_HEIGHT:.2f} vertical tip ends flush at z=8.00.

## Dual attachment geometry retained from v1.3

- Brass-fastener centers: (-20.00, 0.00) and (20.00, 0.00).
- Through paths: X-axis capsules, 3.60 long x 1.80 wide.
- Top head recesses: 8.50 diameter x 3.00 deep.
- Non-clutch feet: solid 5.20 diameter x 2.85 high roof posts ({records['2AA']['expected_solid_post_count']} / {records['4AA']['expected_solid_post_count']}).
- Six selected clutch positions retain their open Medium-fit tubes and add bottom C anchors: 6.00 diameter x 0.60 high, with 1.55 x 4.20 notches facing the module center.

The underside additions begin on the build plate and require no support. Overall footprints remain unchanged. Relative to v1.3, every mesh difference is constrained to the declared strap envelope and no new positive geometry rises above z=8.00.
"""
    (ROOT / "DIMENSION_SUMMARY.md").write_text(dimensions, encoding="utf-8")

    validation = [
        "# Mesh and feature validation — v1.4 captive strap dual mount",
        "",
        "Generated with OpenSCAD and independently inspected with trimesh/manifold booleans.",
        "",
        "| Check | 2xAA | 4xAA |",
        "|---|---:|---:|",
    ]
    rows = (
        ("Overall pass", "pass"),
        ("Watertight", "watertight"),
        ("One connected component", "connected_components"),
        ("No degenerate faces", "no_degenerate_faces"),
        ("Pack envelope clears", "pack_reference_has_clearance"),
        ("Cable corridor clears", "full_height_cable_corridor_is_open"),
        ("20.0 x 1.6 full floor strap gauge clears", "20_0_x_1_6_floor_tape_gauge_is_open"),
        ("Main 2.35 mm floor material probes pass", "main_floor_material_present_below_z4_80"),
        ("Conservative outer-exit material probes pass", "outer_exit_material_present_below_z4_05"),
        ("Two 6.0 mm keeper zones present", "keeper_zone_count"),
        ("18.2 mm keeper-mouth gauge clears", "keeper_mouth_gauge_is_open"),
        ("Keeper mouth bounded near 18.4 mm", "keeper_mouth_is_bounded_near_18_4_mm"),
        ("Lifted tape meets positive retention", "lifted_strap_has_positive_retention"),
        ("Opposing 45-degree keeper lips pass", "opposing_45_degree_keeper_lips_pass"),
        ("All four 0.8 mm lead tapers pass", "all_0_8_mm_lead_tapers_pass"),
        ("Minimum lead-taper root fill ratio", "minimum_lead_taper_root_fill_ratio"),
        ("Complete captive strap insert passes", "captive_strap_insert_pass"),
        ("Full 4.90 x 1.70 nominal stud array has zero collision", "nominal_stud_array_has_zero_collision"),
        ("Nominal stud-array overlap (mm^3)", "nominal_stud_array_overlap_mm3"),
        ("All support centers are solid to roof", "all_non_clutch_centers_have_solid_posts_to_roof"),
        ("Minimum solid-post fill ratio", "minimum_solid_post_fill_ratio"),
        ("All clutch centerlines open", "all_selected_clutch_centerlines_are_open"),
        ("C-anchor material/height/notches pass", "c_anchor_presence_height_and_notches_pass"),
        ("Dense brass paths open", "dense_brad_paths_are_open_through_base"),
        ("Head recess envelopes open", "head_recess_envelopes_are_open"),
        ("Head seating points solid", "brad_head_seating_points_are_solid"),
        ("Head recesses bounded", "head_recesses_stay_inside_nominal_envelopes"),
        ("Overall extents unchanged", "overall_extents_unchanged"),
        ("v1.3 symmetric delta localized to strap envelope", "v1_3_symmetric_delta_localized_to_strap_envelope"),
        ("No new positive geometry above z=8", "no_new_positive_geometry_above_z8"),
        ("Faces", "faces"),
        ("Volume (mm^3)", "volume_mm3"),
    )
    for label, field in rows:
        validation.append(f"| {label} | {records['2AA'][field]} | {records['4AA'][field]} |")
    validation += [
        "",
        "The support-foot test fills nearly the complete 5.20 mm nominal disk from z=0.08 to z=2.78 at every non-clutch tube center. Separate void and material probes verify open clutch centerlines, inward C gaps, anchor material below z=0.60, and no anchor closure above it.",
        "",
        "Each brass-fastener path is tested with a tight 3.50 x 1.70 capsule through the complete base. An 8.35 mm head gauge spanning z=5.05..8.05 verifies the full recess; points below and just outside it verify the seating shoulder and bounded envelope.",
        "",
        "A complete nominal LEGO stud array (4.90 mm diameter x 1.70 mm high) is checked at x=-28..28 in 8 mm steps and y=-16..16 for 2xAA or y=-32..32 for 4xAA. Zero boolean intersection verifies that the skirt, solid posts, open clutch tubes, and C-anchor notches preserve the seating paths.",
        "",
        f"The captive route is tested with a 20.00 x 1.60 mm gauge resting at z={KEEPER_DEEP_FLOOR_Z + KEEPER_FLOOR_CLEARANCE:.2f}..{KEEPER_DEEP_FLOOR_Z + KEEPER_FLOOR_CLEARANCE + STRAP_GAUGE_HEIGHT:.2f}. Each {KEEPER_ZONE_LENGTH:.2f} mm keeper core receives mouth, edge-material, lifted-retention, and paired void/material probes along its declared 45-degree underside.",
        "",
        f"Material probes verify the main floor immediately below z={KEEPER_DEEP_FLOOR_Z:.2f} and both exterior exits immediately below z={OUTER_EXIT_LOW_Z:.2f}. The main nominal floor is {MAIN_FLOOR_NOMINAL_THICKNESS:.2f} above the cavity roof. The {OUTER_EXIT_CONSERVATIVE_THICKNESS:.2f} exit figure is deliberately conservative because the lead-out's lowest point is over the solid perimeter, not open cavity.",
        "",
        f"Every {KEEPER_ROOT_LEAD_TAPER:.2f} mm lead taper is sampled at its midpoint on both X sides. Paired void/lip probes verify gradual entry geometry, and structural root probes near x=+/-11.10 verify continuous material. Lift retention must intersect at least {KEEPER_RETENTION_MIN_VOLUME:.2f} mm^3 of keeper material per zone.",
        "",
        "A bidirectional v1.3/v1.4 boolean comparison masks only the declared captive-strap envelope. It requires zero unmasked symmetric difference and independently verifies that new keeper material does not extend above the z=8 body plane.",
        "",
        "This is digital validation. Pilot-print one module and the included 3.6 mm brad coupon before classroom batch production.",
    ]
    (ROOT / "MESH_VALIDATION.md").write_text("\n".join(validation) + "\n", encoding="utf-8")

    assembly = f"""# Printing, assembly, and use

## Print

- PLA, 0.20 mm layers, four walls, approximately 20% gyroid.
- Print in the supplied orientation: hollow underside and C-anchor faces on the build plate, cradle opening upward.
- Supports off. The solid roof posts and 0.60 mm C anchors build directly from the plate.
- Pilot-print and check the 3.6 mm section of `PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl` before making a classroom batch.{'' if coupon_included else ' The standard coupon was not present when this package was built.'}

## 3/4-inch non-adhesive strap

Only the tape width, 3/4 inch (19.05 mm), was confirmed from the actual material. The 1.60 mm value is a deliberately conservative digital validation gauge, not a measured or manufacturer-specified tape thickness. Pilot-fit the actual tape in one printed module before batch production. Stop if it will not slide beneath both keepers without force; do not stretch the tape or pry the printed lips.

1. Remove the holder and batteries. Feed the end of the 3/4-inch tape along the deep transverse channel and through the first 6 mm keeper.
2. If the cut end catches, tilt one tape edge under one 45-degree lip, gently bow the tape, then tuck the opposite edge under the opposing lip. Slide rather than pulling the hook surface hard across a printed edge.
3. Continue through the second keeper until the tape lies flat on the deep floor with roughly equal tails on both sides. Do not twist or fold it beneath a keeper.
4. Set the battery holder over the seated tape with its wires aligned to the wide cable relief. Wrap the tails over the cells and press the hook-and-loop faces together, tightening only enough to stop rattling.
5. Hot glue is unnecessary: the two integral keeper zones retain the loose strap whenever the holder is removed. Keeping the tape removable also makes inspection and replacement easier.

## Cardboard and brass paper fasteners

1. Use the 3.6 mm coupon result to confirm the intended brass-fastener fit before forcing hardware into a finished module.
2. Mark the cardboard at 40 mm center-to-center using the two internal recesses as a template. Punch clean holes in the cardboard.
3. With the holder and batteries removed, pass the brass fasteners through the two X-axis capsule paths and the cardboard. Seat each head fully in its 8.50 mm recess; do not leave a proud metal head beneath the battery holder.
4. Spread the legs flat on the far side of the cardboard and cover exposed legs if students can touch them. Do not overtighten or crush corrugated board.
5. Inspect the cardboard, fasteners, printed seats, leads, and strap before every use. Replace torn board or loose hardware.
6. To return the module to LEGO use, remove both brass fasteners and all cardboard first, then inspect the hollow underside before seating it on studs.

Installed brads/cardboard and LEGO mounting are mutually exclusive. Never press the module onto LEGO studs while either brass fastener or cardboard remains installed through the underside. The hook-and-loop strap may be used with either mounting method. Keep all conductive fastener parts away from battery contacts and bare wire ends.

## Electrical safety

- The 2xAA/JST pack is the low-voltage micro:bit pack.
- Never plug the 4xAA pack into the micro:bit battery socket. Four alkaline cells are about 6 V, while official micro:bit documentation gives a 3.6 V maximum operating supply.
- Treat the 4xAA bare leads as a separate external supply for the intended classroom circuit; verify polarity and follow the PLTW wiring diagram.
"""
    (ROOT / "ASSEMBLY_AND_USAGE.md").write_text(assembly, encoding="utf-8")

    research = """# Verified dimensions and design inputs

## User-supplied requirements

- The reusable, non-adhesive hook-and-loop tape on hand is 3/4 inch (19.05 mm) wide.
- The user requested cardboard brass-fastener inserts and solid, supportless anchor feet.
- The user requested an integral insert that retains the loose strap in the module body.
- This revision preserves the v1.3 3.6 mm dual-brad/supportless underside and adds two supportless captive-strap keeper zones.

## Battery holders

The PLTW 44PLTWMCRBT bill of materials identifies the exact supplied parts `2801AA2JST` and `2801AA4PWR`. Same-SKU supplier listings provide the holder envelopes used in the CAD.

- PLTW BOM: https://www.pltw.org/hubfs/operations/equipment_supplies/gateway_bill_of_materials/CSIM_Microbit_Kit_44PLTWMCRBT.pdf
- 2xAA supplier: https://www.sciencepurchase.com/products/aa-battery-holder-for-2-aa-batteries-with-jst-connector-2-26-x-1-25-x-0-59
- 4xAA supplier: https://www.sciencepurchase.com/products/aa-4-battery-holder-with-wire-leads-holds-four-aa-batteries
- Official micro:bit power guidance: https://tech.microbit.org/hardware/powersupply/

The brass-fastener dimensions are design geometry and must be confirmed with the included physical fit coupon; they are not claimed as a universal brad standard.
"""
    (ROOT / "SOURCE_RESEARCH.md").write_text(research, encoding="utf-8")

    coupon_line = (
        "- `PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl` — copied standard coupon; use the 3.6 section"
        if coupon_included
        else "- Standard brad coupon was not found at build time; obtain and test it before batch printing"
    )
    readme = f"""# PLTW AA battery modules v1.4 — captive strap dual mount

Two matching supportless cradles with a captive route for the confirmed 3/4-inch strap plus recessed cardboard brass-fastener mounting.

## Print files

- `{MODULES['2AA']['stl']}`
- `{MODULES['4AA']['stl']}`
{coupon_line}

## Editable source and verification

- `PLTW_AA_Battery_Modules_v1_4_CaptiveStrap.scad`
- `build_and_validate_v1_4.py`
- `DIMENSION_SUMMARY.md`, `MESH_VALIDATION.md`, and `ASSEMBLY_AND_USAGE.md`

Two 6 mm keeper cores hold the loose tape below opposing 45-degree lips. The 18.40 mm upper mouth retains the nominal 19.05 mm tape while the deep floor clears a 20.00 x 1.60 mm validation gauge. Thread the tape through both keepers before installing the battery holder; hot glue is unnecessary.

The non-clutch underside locations remain solid roof posts. The six selected Medium-fit clutch tubes remain open and use thin, inward-notched C anchors. Two recessed 3.6 x 1.8 mm brass-fastener paths are centered 40 mm apart. All additions stay at or below the z=8 body plane and print with supports off.

Status: digitally validated prototype. Test one module and the 3.6 mm coupon before classroom production.
"""
    (ROOT / "README_FIRST.md").write_text(readme, encoding="utf-8")


def copy_optional_coupon() -> bool:
    if not COUPON_SOURCE.exists():
        return False
    destination = ROOT / COUPON_SOURCE.name
    shutil.copy2(COUPON_SOURCE, destination)
    return True


def package() -> None:
    archive = ROOT.parent / "PLTW_AA_Battery_Modules_v1_4_CaptiveStrap.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(ROOT.iterdir()):
            if path.name == "__pycache__":
                continue
            bundle.write(path, arcname=f"{ROOT.name}/{path.name}")


def main() -> None:
    if not OPENSCAD.exists():
        raise FileNotFoundError(f"OpenSCAD CLI not found: {OPENSCAD}")
    if not SOURCE.exists():
        raise FileNotFoundError(
            f"Captive-strap CAD source does not exist yet: {SOURCE}. "
            "This builder intentionally does not generate or modify the SCAD."
        )
    if not COUPON_SOURCE.exists():
        raise FileNotFoundError(
            "Required brad fit coupon is missing: "
            f"{COUPON_SOURCE}. The v1.4 package must include the coupon."
        )

    validate_only = "--validate-only" in sys.argv[1:]
    skip_previews = "--skip-previews" in sys.argv[1:]
    if not validate_only:
        for spec in MODULES.values():
            export_stl(spec, ROOT / str(spec["stl"]))
        if not skip_previews:
            export_preview(
                "CAPTIVE_PREVIEW",
                ROOT / "PLTW_AA_Battery_Modules_v1_4_CaptiveStrap_Preview.png",
            )
            export_preview(
                "CAPTIVE_UNDERSIDE_PREVIEW",
                ROOT / "PLTW_AA_Battery_Modules_v1_4_CaptiveStrap_Underside.png",
            )

    for spec in MODULES.values():
        clean_exported_stl(ROOT / str(spec["stl"]))

    records = {key: validate_one(key, spec) for key, spec in MODULES.items()}
    coupon_included = copy_optional_coupon()
    if not coupon_included:
        raise RuntimeError("Required 3.2/3.4/3.6 brad fit coupon was not copied")
    payload = {
        "design": {
            "version": "1.4 CaptiveStrap DualMount 3p6",
            "supportless_printing": True,
            "strap_width_mm": STRAP_WIDTH,
            "strap_gauge_mm": [STRAP_GAUGE_WIDTH, STRAP_GAUGE_HEIGHT],
            "strap_width_confirmed_from_actual_material": True,
            "strap_thickness_measured_or_published": False,
            "strap_gauge_is_a_thickness_claim": False,
            "v1_3_reference_channel_depth_mm": V1_3_STRAP_CHANNEL_DEPTH,
            "strap_channel_floor_top_depth_mm": [
                STRAP_CHANNEL_FLOOR_WIDTH,
                STRAP_CHANNEL_TOP_WIDTH,
                STRAP_CHANNEL_DEPTH,
            ],
            "captive_channel_depth_mm": KEEPER_DEEP_CHANNEL_DEPTH,
            "captive_channel_floor_z_mm": KEEPER_DEEP_FLOOR_Z,
            "channel_exit_chamfer_mm": STRAP_EXIT_CHAMFER,
            "outer_exit_low_z_mm": OUTER_EXIT_LOW_Z,
            "main_floor_nominal_thickness_above_cavity_roof_mm": (
                MAIN_FLOOR_NOMINAL_THICKNESS
            ),
            "outer_exit_conservative_thickness_above_cavity_roof_mm": (
                OUTER_EXIT_CONSERVATIVE_THICKNESS
            ),
            "outer_exit_low_point_is_over_perimeter_solid": True,
            "keeper_count": KEEPER_ZONE_COUNT,
            "keeper_core_length_mm": KEEPER_ZONE_LENGTH,
            "keeper_root_lead_taper_each_end_mm": KEEPER_ROOT_LEAD_TAPER,
            "keeper_total_envelope_length_mm": KEEPER_TOTAL_ENVELOPE_LENGTH,
            "keeper_center_inset_from_base_edge_mm": KEEPER_ZONE_CENTER_INSET,
            "keeper_mouth_width_mm": KEEPER_MOUTH_WIDTH,
            "keeper_root_outer_width_mm": 2 * KEEPER_ROOT_OUTER_HALF_WIDTH,
            "keeper_lip_angle_degrees": KEEPER_LIP_ANGLE_DEG,
            "keeper_lip_45_degree_run_mm": KEEPER_SLOPE_HEIGHT,
            "keeper_vertical_tip_height_mm": KEEPER_VERTICAL_TIP_HEIGHT,
            "keeper_lip_z_range_mm": [KEEPER_LIP_BOTTOM_Z, KEEPER_TOP_Z],
            "keeper_retention_minimum_overlap_per_zone_mm3": (
                KEEPER_RETENTION_MIN_VOLUME
            ),
            "declared_strap_change_envelope_z_range_mm": [
                STRAP_CHANGE_ENVELOPE_Z0,
                STRAP_CHANGE_ENVELOPE_Z1,
            ],
            "brad_centers_mm": [list(center) for center in BRAD_CENTERS],
            "brad_capsule_length_width_mm": [BRAD_SLOT_LENGTH, BRAD_SLOT_WIDTH],
            "brad_capsule_long_axis": BRAD_SLOT_LONG_AXIS,
            "brad_head_recess_diameter_depth_mm": [
                BRAD_HEAD_DIAMETER,
                BRAD_HEAD_RECESS_DEPTH,
            ],
            "solid_post_diameter_height_mm": [
                SOLID_POST_DIAMETER,
                SOLID_POST_HEIGHT,
            ],
            "clutch_c_anchor_diameter_height_mm": [
                CLUTCH_ANCHOR_DIAMETER,
                CLUTCH_ANCHOR_HEIGHT,
            ],
            "clutch_c_anchor_notch_width_length_mm": [
                CLUTCH_ANCHOR_NOTCH_WIDTH,
                CLUTCH_ANCHOR_NOTCH_LENGTH,
            ],
            "brad_coupon_included": coupon_included,
            "brad_coupon_required": True,
        },
        "modules": records,
    }
    (ROOT / "MESH_VALIDATION.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    write_dimension_csv(records)
    write_reports(records, coupon_included)

    if not all(record["pass"] for record in records.values()):
        raise RuntimeError(
            "One or more mesh/clearance/keeper/anchor/brad checks failed; "
            "see MESH_VALIDATION.json"
        )

    package()
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

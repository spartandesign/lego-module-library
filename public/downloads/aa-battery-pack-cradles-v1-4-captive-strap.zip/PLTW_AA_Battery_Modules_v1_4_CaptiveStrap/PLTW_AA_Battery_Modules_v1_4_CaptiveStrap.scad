/*
PLTW AA Battery-Pack Modules v1.4 - captive-strap dual-mount edition

Parameterized source for the exact holders listed in the PLTW
44PLTWMCRBT micro:bit kit:
  - 2801AA2JST: 57.4 x 31.75 x 15.0 mm, JST lead
  - 2801AA4PWR: 57.8 x 62.0 x 15.0 mm, bare leads

The underside reproduces the established brick-style Medium-fit standard:
  8.00 mm pitch; 2.45 mm hollow cavity; 0.65 mm lead-in;
  1.50/1.38 mm skirt; selected 6.31/6.10 mm clutch tubes;
  4.95 mm clutch-tube ID; 5.20/5.00 mm clearance support tubes;
  3.40 mm support-tube ID.

Export choices (override from the OpenSCAD command line with -D):
  part = "2AA";
  part = "4AA";
  part = "2AA_STRAP";
  part = "4AA_STRAP";
  part = "2AA_DUAL";
  part = "4AA_DUAL";
  part = "2AA_CAPTIVE";
  part = "4AA_CAPTIVE";
  part = "preview";
  part = "underside_preview";
  part = "STRAP_PREVIEW";
  part = "STRAP_UNDERSIDE_PREVIEW";
  part = "DUAL_PREVIEW";
  part = "DUAL_UNDERSIDE_PREVIEW";
  part = "CAPTIVE_PREVIEW";
  part = "CAPTIVE_UNDERSIDE_PREVIEW";
*/

part = is_undef(part) ? "CAPTIVE_PREVIEW" : part;
facet_count = is_undef(facet_count) ? 72 : facet_count;
$fn = facet_count;

EPS = 0.03;

// Established Medium-fit LEGO interface.
PITCH = 8.00;
BASE_HEIGHT = 8.00;
CAVITY_DEPTH = 2.45;
LEAD_IN_HEIGHT = 0.65;
SKIRT_MAIN = 1.50;
SKIRT_LEAD = 1.38;
CLUTCH_OD_MAIN = 6.31;
CLUTCH_OD_LEAD = 6.10;
CLUTCH_ID = 4.95;
SUPPORT_OD_MAIN = 5.20;
SUPPORT_OD_LEAD = 5.00;
SUPPORT_ID = 3.40;

// Cradle geometry shared by both modules.
FIT_CLEARANCE_PER_SIDE = 0.80;
CRADLE_WALL = 1.80;
RAIL_HEIGHT = 7.00;
SIDE_FINGER_GAP = 22.00;
NONWIRE_CORNER_STOP = 9.00;
WIRE_CORNER_STOP = 6.00;
FINGER_RECESS_DEPTH = 2.20;
BASE_CORNER_RADIUS = 2.20;
WALL_CORNER_RADIUS = 0.55;

// The user confirmed that the actual tape is 3/4 inch (19.05 mm) wide.
// Its thickness is not published.  Both recessed routes therefore avoid
// forcing the tape through the cradle's 0.80 mm side clearance.  The legacy
// open route has a 21.00 mm floor and 22.00 mm mouth.  The captive route keeps
// that lower width, deepens the full route, and narrows only two short keeper
// zones to the separately declared mouth width below.
STRAP_TAPE_WIDTH = 19.05;
STRAP_CHANNEL_WIDTH = 21.00;
STRAP_CHANNEL_TOP_WIDTH = 22.00;
STRAP_CHANNEL_DEPTH = 1.80;
STRAP_CHANNEL_CHAMFER = 0.50;
STRAP_EXIT_CHAMFER = 0.75;
STRAP_GRID_OFFSET = 0.00;
STRAP_REFERENCE_THICKNESS = 1.40; // preview only; not a product claim

// v1.4 slide-in strap insert.  Two short keeper zones retain the flexible
// tape beneath opposing 45-degree lips; the center stays open, so there is no
// unsupported 20 mm roof or loose printed clip.  A 20.00 x 1.60 mm gauge has
// 0.50 mm lateral clearance in the lower track and at least 0.30 mm clearance
// at the keeper lips when seated against the channel floor.
STRAP_INSERT_CHANNEL_DEPTH = 3.20;
STRAP_INSERT_MOUTH_WIDTH = 18.40;
STRAP_INSERT_LIP_RAMP = 1.30;
STRAP_INSERT_LIP_TIP = 0.40;
STRAP_INSERT_KEEPER_CORE_LENGTH = 6.00;
STRAP_INSERT_LEAD_LENGTH = 0.80;
// The extra 0.25 mm avoids a coplanar contact with the 4xAA finger recess.
STRAP_INSERT_KEEPER_EDGE_INSET = 11.25;
STRAP_INSERT_ROOT_OUTER_X = 11.60;

// Current supportless dual-mount library standard.
SOLID_SUPPORT_DIAMETER = 5.20;
SOLID_SUPPORT_HEIGHT = 2.85;
C_ANCHOR_DIAMETER = 6.00;
C_ANCHOR_HEIGHT = 0.60;
C_ANCHOR_NOTCH_WIDTH = 1.55;
C_ANCHOR_NOTCH_LENGTH = 4.20;
BRAD_PATH_LENGTH = 3.60;
BRAD_PATH_WIDTH = 1.80;
BRAD_HEAD_RECESS_DIAMETER = 8.50;
BRAD_HEAD_RECESS_DEPTH = 3.00;
BRAD_CENTERS = [[-20.0, 0.0], [20.0, 0.0]];

// Supplier-documented bodies.  Exit coordinates and molded-hole coordinates
// are intentionally not assumed because the supplier does not dimension them.
PACK_2AA = [57.40, 31.75, 15.00];
PACK_4AA = [57.80, 62.00, 15.00];

module rounded_rect_prism(size, radius) {
    linear_extrude(height = size[2], convexity = 10)
        offset(r = radius)
            square([size[0] - 2 * radius, size[1] - 2 * radius], center = true);
}

module xy_box(size, z0) {
    translate([-size[0] / 2, -size[1] / 2, z0]) cube(size);
}

module hollow_tube(outer_diameter, inner_diameter, height, z0) {
    translate([0, 0, z0])
        difference() {
            cylinder(d = outer_diameter, h = height);
            translate([0, 0, -EPS])
                cylinder(d = inner_diameter, h = height + 2 * EPS);
        }
}

// Six symmetric clutch tubes for both footprints: left, center, and right on
// the two outermost tube rows.  Every other interstitial tube only supports
// the cavity roof.
function is_selected_clutch(x, y, nx, ny) =
    let(
        edge_x = (nx - 2) * PITCH / 2,
        edge_y = (ny - 2) * PITCH / 2
    )
    abs(abs(y) - edge_y) < 0.01 &&
    (abs(abs(x) - edge_x) < 0.01 || abs(x) < 0.01);

module interface_tube(x, y, selected) {
    translate([x, y, 0])
        union() {
            hollow_tube(
                selected ? CLUTCH_OD_LEAD : SUPPORT_OD_LEAD,
                selected ? CLUTCH_ID : SUPPORT_ID,
                LEAD_IN_HEIGHT + 0.06,
                0
            );
            hollow_tube(
                selected ? CLUTCH_OD_MAIN : SUPPORT_OD_MAIN,
                selected ? CLUTCH_ID : SUPPORT_ID,
                CAVITY_DEPTH - LEAD_IN_HEIGHT + 0.12,
                LEAD_IN_HEIGHT - 0.03
            );
        }
}

module solid_roof_support(x, y) {
    translate([x, y, 0])
        cylinder(d = SOLID_SUPPORT_DIAMETER,
                 h = SOLID_SUPPORT_HEIGHT);
}

// Exact inward notch shared by the 0.60 mm anchor disk and the selected
// clutch tube's first layer.  Cutting both pieces keeps a true open C instead
// of letting the original annulus bridge back across the anchor split.
module c_anchor_notch_cutter(x, y) {
    center_distance = sqrt(x * x + y * y);
    direction_x = -x / center_distance;
    direction_y = -y / center_distance;
    notch_angle = atan2(direction_y, direction_x) - 90;

    translate([
        x + direction_x * 2.0,
        y + direction_y * 2.0,
        C_ANCHOR_HEIGHT / 2
    ])
        rotate([0, 0, notch_angle])
            cube([
                C_ANCHOR_NOTCH_WIDTH,
                C_ANCHOR_NOTCH_LENGTH,
                C_ANCHOR_HEIGHT + 2 * EPS
            ], center = true);
}

// Six selected clutch tubes receive C-shaped first-layer anchors.  Their
// notches face inward toward the module center, leaving every bore centerline
// and normal LEGO seating path open.
module anchored_interface_tube(x, y) {
    difference() {
        union() {
            interface_tube(x, y, true);
            translate([x, y, 0])
                cylinder(d = C_ANCHOR_DIAMETER,
                         h = C_ANCHOR_HEIGHT);
        }
        c_anchor_notch_cutter(x, y);
    }
}

module medium_fit_brick_base(nx, ny, supportless_dual = false) {
    size_x = nx * PITCH;
    size_y = ny * PITCH;

    union() {
        difference() {
            rounded_rect_prism([size_x, size_y, BASE_HEIGHT], BASE_CORNER_RADIUS);

            // Slightly looser first-layer lead-in, followed by the selected
            // Medium skirt wall above it.
            xy_box(
                [size_x - 2 * SKIRT_LEAD, size_y - 2 * SKIRT_LEAD,
                 LEAD_IN_HEIGHT + 2 * EPS],
                -EPS
            );
            xy_box(
                [size_x - 2 * SKIRT_MAIN, size_y - 2 * SKIRT_MAIN,
                 CAVITY_DEPTH - LEAD_IN_HEIGHT + 2 * EPS],
                LEAD_IN_HEIGHT - EPS
            );
        }

        for (ix = [1 : nx - 1])
            for (iy = [1 : ny - 1])
                let(
                    x = -size_x / 2 + ix * PITCH,
                    y = -size_y / 2 + iy * PITCH
                )
                let(selected = is_selected_clutch(x, y, nx, ny)) {
                    if (selected) {
                        if (supportless_dual)
                            anchored_interface_tube(x, y);
                        else
                            interface_tube(x, y, true);
                    } else if (supportless_dual) {
                        solid_roof_support(x, y);
                    } else {
                        interface_tube(x, y, false);
                    }
                }
    }
}

module wall_block(size, center_xy, height = RAIL_HEIGHT) {
    translate([center_xy[0], center_xy[1], BASE_HEIGHT - 0.06])
        rounded_rect_prism(
            [size[0], size[1], height + 0.06],
            min(WALL_CORNER_RADIUS, min(size[0], size[1]) / 3)
        );
}

module segmented_cradle_walls(pack_length, pack_width, cable_side) {
    pocket_length = pack_length + 2 * FIT_CLEARANCE_PER_SIDE;
    pocket_width = pack_width + 2 * FIT_CLEARANCE_PER_SIDE;
    side_segment = (pocket_length - SIDE_FINGER_GAP) / 2;
    side_x = SIDE_FINGER_GAP / 2 + side_segment / 2;
    side_y = pocket_width / 2 + CRADLE_WALL / 2;
    end_x = pocket_length / 2 + CRADLE_WALL / 2;

    // Long-side rails are split at the center so a student can grasp the
    // holder.  The matching floor recesses are subtracted later.
    for (x = [-side_x, side_x])
        for (y = [-side_y, side_y])
            wall_block([side_segment, CRADLE_WALL], [x, y]);

    // The non-wire end has two substantial corner stops and a broad center
    // opening.  This avoids blocking the molded battery-removal cutouts.
    nonwire_x = -cable_side * end_x;
    for (y_sign = [-1, 1])
        wall_block(
            [CRADLE_WALL, NONWIRE_CORNER_STOP],
            [nonwire_x,
             y_sign * (pocket_width / 2 - NONWIRE_CORNER_STOP / 2)]
        );

    // The lead end is deliberately a very wide, full-height opening.  Only
    // small corner stops remain, so undocumented wire-exit variation cannot
    // pinch either the JST pair or the separate 4xAA leads.
    wire_x = cable_side * end_x;
    for (y_sign = [-1, 1])
        wall_block(
            [CRADLE_WALL, WIRE_CORNER_STOP],
            [wire_x,
             y_sign * (pocket_width / 2 - WIRE_CORNER_STOP / 2)]
        );
}

module finger_recesses(pack_width, base_width) {
    pocket_width = pack_width + 2 * FIT_CLEARANCE_PER_SIDE;
    inner_edge = pocket_width / 2 - 3.0;
    outer_edge = base_width / 2 + 0.6;
    recess_span = outer_edge - inner_edge;
    recess_center = (outer_edge + inner_edge) / 2;

    for (side = [-1, 1])
        translate([0, side * recess_center,
                   BASE_HEIGHT - FINGER_RECESS_DEPTH])
            rounded_rect_prism(
                [SIDE_FINGER_GAP, recess_span,
                 FINGER_RECESS_DEPTH + 0.20],
                min(2.0, recess_span / 3)
            );
}

// Cut a supportless tape route into the top of the base.  The 22 mm open mouth
// is centered in the existing 22 mm finger window, so neither long-side rail
// is removed.  The default 1.80 mm route leaves 3.75 mm above the cavity roof;
// the v1.4 captive call uses 3.20 mm, leaving 2.35 mm on the main floor.  Its
// outer 0.75 mm lead-out lies over the solid perimeter and conservatively
// bottoms 1.60 mm above the cavity-roof Z datum.  The underside interface is
// unchanged in either case.
module strap_channel_cutter(
    base_width,
    cable_side,
    channel_depth = STRAP_CHANNEL_DEPTH
) {
    strap_x = -cable_side * STRAP_GRID_OFFSET;
    channel_span = base_width + 1.20;
    lower_z = BASE_HEIGHT - channel_depth - EPS;

    // X-Z trapezoid extruded across Y.  The upper 0.50 mm flares by
    // 0.50 mm on each side to soften the tape-contact edges.
    translate([strap_x, 0, lower_z])
        rotate([90, 0, 0])
            linear_extrude(height = channel_span, center = true, convexity = 10)
                polygon(points = [
                    [-STRAP_CHANNEL_WIDTH / 2, 0],
                    [ STRAP_CHANNEL_WIDTH / 2, 0],
                    [ STRAP_CHANNEL_WIDTH / 2,
                      channel_depth - STRAP_CHANNEL_CHAMFER],
                    [ STRAP_CHANNEL_TOP_WIDTH / 2,
                      channel_depth + 2 * EPS],
                    [-STRAP_CHANNEL_TOP_WIDTH / 2,
                      channel_depth + 2 * EPS],
                    [-STRAP_CHANNEL_WIDTH / 2,
                      channel_depth - STRAP_CHANNEL_CHAMFER]
                ]);

    // Open guides through the two long-side rails.  These are deliberately
    // open at the top: no bridge, support, or unknown-thickness pinch point.
    translate([
        strap_x - STRAP_CHANNEL_TOP_WIDTH / 2,
        -channel_span / 2,
        BASE_HEIGHT - EPS
    ])
        cube([
            STRAP_CHANNEL_TOP_WIDTH,
            channel_span,
            RAIL_HEIGHT + 0.20
        ]);

    // Bevel the two exterior lips where the tape turns upward.  These
    // 0.75 mm, 45-degree lead-outs are fully subtractive and supportless.
    for (side = [-1, 1])
        hull() {
            translate([
                strap_x,
                side * (base_width / 2 - STRAP_EXIT_CHAMFER / 2),
                BASE_HEIGHT - channel_depth + EPS
            ])
                cube([
                    STRAP_CHANNEL_TOP_WIDTH,
                    STRAP_EXIT_CHAMFER,
                    2 * EPS
                ], center = true);
            translate([
                strap_x,
                side * (base_width / 2 + EPS / 2),
                BASE_HEIGHT - channel_depth
                    - STRAP_EXIT_CHAMFER / 2
            ])
                cube([
                    STRAP_CHANNEL_TOP_WIDTH,
                    EPS,
                    STRAP_EXIT_CHAMFER
                ], center = true);
        }
}

// X-Z section for one keeper lip.  The 1.30 mm underside is exactly 45
// degrees.  A 0.40 mm vertical inner face above it gives the lip a printable,
// durable tip instead of ending in a zero-thickness knife edge.
module strap_insert_lip_prism(
    strap_x,
    x_sign,
    y_center,
    y_length,
    full_profile = true
) {
    inner_bottom = STRAP_CHANNEL_WIDTH / 2;
    inner_top = STRAP_INSERT_MOUTH_WIDTH / 2;
    outer_x = STRAP_INSERT_ROOT_OUTER_X;
    total_height = STRAP_INSERT_LIP_RAMP + STRAP_INSERT_LIP_TIP;
    bottom_z = BASE_HEIGHT - total_height;

    right_full = [
        [ inner_bottom, 0],
        [ outer_x, 0],
        [ outer_x, total_height],
        [ inner_top, total_height],
        [ inner_top, STRAP_INSERT_LIP_RAMP]
    ];
    left_full = [
        [-outer_x, 0],
        [-inner_bottom, 0],
        [-inner_top, STRAP_INSERT_LIP_RAMP],
        [-inner_top, total_height],
        [-outer_x, total_height]
    ];
    right_root = [
        [ inner_bottom, 0],
        [ outer_x, 0],
        [ outer_x, total_height],
        [ inner_bottom, total_height]
    ];
    left_root = [
        [-outer_x, 0],
        [-inner_bottom, 0],
        [-inner_bottom, total_height],
        [-outer_x, total_height]
    ];
    profile = full_profile
        ? (x_sign > 0 ? right_full : left_full)
        : (x_sign > 0 ? right_root : left_root);

    translate([strap_x, y_center, bottom_z])
        rotate([90, 0, 0])
            linear_extrude(height = y_length, center = true, convexity = 10)
                polygon(points = profile);
}

module strap_insert_keeper_lips(base_width, cable_side) {
    strap_x = -cable_side * STRAP_GRID_OFFSET;
    keeper_y = base_width / 2 - STRAP_INSERT_KEEPER_EDGE_INSET;

    for (y_sign = [-1, 1])
        for (x_sign = [-1, 1]) {
            y_center = y_sign * keeper_y;

            // Full six-millimetre capture core.
            strap_insert_lip_prism(
                strap_x,
                x_sign,
                y_center,
                STRAP_INSERT_KEEPER_CORE_LENGTH,
                true
            );

            // Short longitudinal lead tapers reduce snagging when the tape is
            // slid under each keeper.  The outer slice is root-only, so the
            // tape sees a gradual 21.0-to-18.4 mm entry rather than a step.
            for (end_sign = [-1, 1])
                hull() {
                    strap_insert_lip_prism(
                        strap_x,
                        x_sign,
                        y_center + end_sign
                            * STRAP_INSERT_KEEPER_CORE_LENGTH / 2,
                        2 * EPS,
                        true
                    );
                    strap_insert_lip_prism(
                        strap_x,
                        x_sign,
                        y_center + end_sign
                            * (STRAP_INSERT_KEEPER_CORE_LENGTH / 2
                               + STRAP_INSERT_LEAD_LENGTH),
                        2 * EPS,
                        false
                    );
                }
        }
}

module vertical_capsule(center_xy, long_axis, width, height, z0) {
    radius = width / 2;
    straight = long_axis - width;
    hull()
        for (offset_x = [-straight / 2, straight / 2])
            translate([
                center_xy[0] + offset_x,
                center_xy[1],
                z0
            ])
                cylinder(r = radius, h = height);
}

// Two internal cardboard-mount paths.  The current library upgrade is a
// 3.60 x 1.80 mm rounded slit; the 8.50 x 3.00 mm top pocket fully recesses the
// classroom brass-paper-fastener head beneath the battery-holder floor.
module brass_fastener_cutters() {
    for (center = BRAD_CENTERS) {
        vertical_capsule(
            center,
            BRAD_PATH_LENGTH,
            BRAD_PATH_WIDTH,
            BASE_HEIGHT + 2 * EPS,
            -EPS
        );
        translate([
            center[0],
            center[1],
            BASE_HEIGHT - BRAD_HEAD_RECESS_DEPTH
        ])
            cylinder(
                d = BRAD_HEAD_RECESS_DIAMETER,
                h = BRAD_HEAD_RECESS_DEPTH + 2 * EPS
            );
    }
}

module battery_cradle(
    pack,
    nx,
    ny,
    cable_side,
    with_strap = false,
    supportless_dual = false,
    captive_strap = false
) {
    base_width = ny * PITCH;

    union() {
        difference() {
            union() {
                medium_fit_brick_base(nx, ny, supportless_dual);
                segmented_cradle_walls(pack[0], pack[1], cable_side);
            }
            finger_recesses(pack[1], base_width);
            if (with_strap)
                strap_channel_cutter(
                    base_width,
                    cable_side,
                    captive_strap
                        ? STRAP_INSERT_CHANNEL_DEPTH
                        : STRAP_CHANNEL_DEPTH
                );
            if (supportless_dual)
                brass_fastener_cutters();
        }
        if (captive_strap)
            strap_insert_keeper_lips(base_width, cable_side);
    }
}

module module_2aa() {
    // Product photos show the paired lead leaving a short end; the opening is
    // much wider than the paired wire so either molded revision remains clear.
    battery_cradle(PACK_2AA, 8, 5, -1);
}

module module_4aa() {
    // Product photos show two leads leaving near a corner.  The wide short-end
    // opening spans nearly the entire holder width instead of assuming the
    // unpublished corner coordinate.
    battery_cradle(PACK_4AA, 8, 9, 1);
}

module module_2aa_strap() {
    battery_cradle(PACK_2AA, 8, 5, -1, true);
}

module module_4aa_strap() {
    battery_cradle(PACK_4AA, 8, 9, 1, true);
}

module module_2aa_dual() {
    battery_cradle(PACK_2AA, 8, 5, -1, true, true);
}

module module_4aa_dual() {
    battery_cradle(PACK_4AA, 8, 9, 1, true, true);
}

module module_2aa_captive() {
    battery_cradle(PACK_2AA, 8, 5, -1, true, true, true);
}

module module_4aa_captive() {
    battery_cradle(PACK_4AA, 8, 9, 1, true, true, true);
}

module reference_pack(pack, cable_side, rgba) {
    color(rgba)
        translate([0, 0, BASE_HEIGHT + 0.08])
            rounded_rect_prism(pack, 1.0);

    // Schematic lead pair for preview only; never included in printable STLs.
    color([0.75, 0.12, 0.10, 0.75])
        translate([cable_side * (pack[0] / 2 + 8), 1.2,
                   BASE_HEIGHT + 2.4])
            rotate([0, 90, 0]) cylinder(d = 1.25, h = 16, center = true);
    color([0.05, 0.05, 0.05, 0.75])
        translate([cable_side * (pack[0] / 2 + 8), -1.2,
                   BASE_HEIGHT + 2.4])
            rotate([0, 90, 0]) cylinder(d = 1.25, h = 16, center = true);
}

// A schematic wrap for preview only.  The actual tape is cut from the roll,
// laid in the recessed floor channel, brought up through both open guides,
// and overlapped on top of the batteries.
module reference_strap(
    pack,
    base_width,
    cable_side,
    channel_depth = STRAP_CHANNEL_DEPTH
) {
    strap_x = -cable_side * STRAP_GRID_OFFSET;
    strap_t = STRAP_REFERENCE_THICKNESS;
    side_y = pack[1] / 2 + FIT_CLEARANCE_PER_SIDE + CRADLE_WALL + strap_t / 2;
    bottom_z = BASE_HEIGHT - channel_depth + strap_t / 2 + 0.10;
    top_z = BASE_HEIGHT + pack[2] + strap_t / 2 + 0.12;
    side_height = top_z - bottom_z;

    color([0.20, 0.78, 0.28, 0.82]) {
        translate([strap_x, 0, bottom_z])
            cube([STRAP_TAPE_WIDTH, base_width, strap_t], center = true);
        translate([strap_x, 0, top_z])
            cube([STRAP_TAPE_WIDTH, 2 * side_y, strap_t], center = true);
        for (side = [-1, 1])
            translate([strap_x, side * side_y,
                       bottom_z + side_height / 2])
                cube([STRAP_TAPE_WIDTH, strap_t, side_height], center = true);
    }
}

// Schematic brass paper fasteners for preview only.
module reference_brass_fasteners() {
    leg_height = BASE_HEIGHT - CAVITY_DEPTH - 0.60;
    color([0.82, 0.58, 0.16, 0.92])
        for (center = BRAD_CENTERS) {
            translate([center[0], center[1], BASE_HEIGHT - 0.55])
                cylinder(d = 7.8, h = 0.55);
            translate([
                center[0],
                center[1],
                CAVITY_DEPTH + 0.05 + leg_height / 2
            ])
                cube([BRAD_PATH_LENGTH, BRAD_PATH_WIDTH,
                      leg_height], center = true);
        }
}

module preview_pair() {
    translate([-40, 0, 0]) {
        color([0.93, 0.55, 0.10]) module_2aa();
        reference_pack(PACK_2AA, -1, [0.12, 0.14, 0.17, 0.55]);
    }
    translate([40, 0, 0]) {
        color([0.20, 0.58, 0.86]) module_4aa();
        reference_pack(PACK_4AA, 1, [0.12, 0.14, 0.17, 0.55]);
    }
}

module underside_pair() {
    translate([-40, 0, BASE_HEIGHT]) rotate([180, 0, 0])
        color([0.93, 0.55, 0.10]) module_2aa();
    translate([40, 0, BASE_HEIGHT]) rotate([180, 0, 0])
        color([0.20, 0.58, 0.86]) module_4aa();
}

module strap_preview_pair() {
    translate([-40, 0, 0]) {
        color([0.93, 0.55, 0.10]) module_2aa_strap();
        reference_pack(PACK_2AA, -1, [0.12, 0.14, 0.17, 0.48]);
        reference_strap(PACK_2AA, 5 * PITCH, -1);
    }
    translate([40, 0, 0]) {
        color([0.20, 0.58, 0.86]) module_4aa_strap();
        reference_pack(PACK_4AA, 1, [0.12, 0.14, 0.17, 0.48]);
        reference_strap(PACK_4AA, 9 * PITCH, 1);
    }
}

module strap_underside_pair() {
    translate([-40, 0, BASE_HEIGHT]) rotate([180, 0, 0])
        color([0.93, 0.55, 0.10]) module_2aa_strap();
    translate([40, 0, BASE_HEIGHT]) rotate([180, 0, 0])
        color([0.20, 0.58, 0.86]) module_4aa_strap();
}

module dual_preview_pair() {
    translate([-40, 0, 0]) {
        color([0.93, 0.55, 0.10]) module_2aa_dual();
        reference_pack(PACK_2AA, -1, [0.12, 0.14, 0.17, 0.45]);
        reference_strap(PACK_2AA, 5 * PITCH, -1);
        reference_brass_fasteners();
    }
    translate([40, 0, 0]) {
        color([0.20, 0.58, 0.86]) module_4aa_dual();
        reference_pack(PACK_4AA, 1, [0.12, 0.14, 0.17, 0.45]);
        reference_strap(PACK_4AA, 9 * PITCH, 1);
        reference_brass_fasteners();
    }
}

module dual_underside_pair() {
    translate([-40, 0, BASE_HEIGHT]) rotate([180, 0, 0])
        color([0.93, 0.55, 0.10]) module_2aa_dual();
    translate([40, 0, BASE_HEIGHT]) rotate([180, 0, 0])
        color([0.20, 0.58, 0.86]) module_4aa_dual();
}

module captive_preview_pair() {
    translate([-40, 0, 0]) {
        color([0.93, 0.55, 0.10]) module_2aa_captive();
        reference_pack(PACK_2AA, -1, [0.12, 0.14, 0.17, 0.42]);
        reference_strap(
            PACK_2AA,
            5 * PITCH,
            -1,
            STRAP_INSERT_CHANNEL_DEPTH
        );
        reference_brass_fasteners();
    }
    translate([40, 0, 0]) {
        color([0.20, 0.58, 0.86]) module_4aa_captive();
        reference_pack(PACK_4AA, 1, [0.12, 0.14, 0.17, 0.42]);
        reference_strap(
            PACK_4AA,
            9 * PITCH,
            1,
            STRAP_INSERT_CHANNEL_DEPTH
        );
        reference_brass_fasteners();
    }
}

module captive_underside_pair() {
    translate([-40, 0, BASE_HEIGHT]) rotate([180, 0, 0])
        color([0.93, 0.55, 0.10]) module_2aa_captive();
    translate([40, 0, BASE_HEIGHT]) rotate([180, 0, 0])
        color([0.20, 0.58, 0.86]) module_4aa_captive();
}

if (part == "2AA") {
    module_2aa();
} else if (part == "4AA") {
    module_4aa();
} else if (part == "2AA_STRAP") {
    module_2aa_strap();
} else if (part == "4AA_STRAP") {
    module_4aa_strap();
} else if (part == "2AA_DUAL") {
    module_2aa_dual();
} else if (part == "4AA_DUAL") {
    module_4aa_dual();
} else if (part == "2AA_CAPTIVE") {
    module_2aa_captive();
} else if (part == "4AA_CAPTIVE") {
    module_4aa_captive();
} else if (part == "underside_preview") {
    underside_pair();
} else if (part == "STRAP_PREVIEW") {
    strap_preview_pair();
} else if (part == "STRAP_UNDERSIDE_PREVIEW") {
    strap_underside_pair();
} else if (part == "DUAL_PREVIEW") {
    dual_preview_pair();
} else if (part == "DUAL_UNDERSIDE_PREVIEW") {
    dual_underside_pair();
} else if (part == "CAPTIVE_PREVIEW") {
    captive_preview_pair();
} else if (part == "CAPTIVE_UNDERSIDE_PREVIEW") {
    captive_underside_pair();
} else {
    preview_pair();
}

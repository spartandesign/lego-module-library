# Dimension summary — v1.4 captive-strap dual-mount modules

All dimensions are millimetres.

| Item | 2xAA | 4xAA |
|---|---:|---:|
| PLTW / vendor SKU | 2801AA2JST | 2801AA4PWR |
| Holder body L x W x H | 57.4 x 31.75 x 15.0 | 57.8 x 62.0 x 15.0 |
| LEGO footprint | 8 x 5 studs (64 x 40) | 8 x 9 studs (64 x 72) |
| Printable L x W x H | 64 x 40 x 15 | 64 x 72 x 15 |
| Solid roof posts | 22 | 50 |
| Selected Medium-fit clutch positions | 6 | 6 |

## Captive strap insert

- Strap: 19.05 confirmed tape width; validated with a deliberately larger 20.00 x 1.60 seated gauge. The 1.60 height is a digital fit gauge, not a measured tape-thickness claim.
- Full-span route: 21.00 floor, 22.00 top, and 3.20 deep across the complete Y path. Its floor is z=4.80. The seated gauge occupies z=4.90..6.50.
- Nominal material above the hollow-cavity roof is 2.35 (z=2.45..4.80). The 0.75 mm exit lead-out bottoms at z=4.05, a conservative 1.60 above the cavity-roof plane; that lowest exit point lies over the solid perimeter.
- Two 6.00-long keeper cores per module, centered at Y=[-8.75, 8.75] for 2xAA and Y=[-24.75, 24.75] for 4xAA.
- Each core has a 0.80 root-only lead taper at both ends (7.60 total envelope).
- Opposing supportless lips: 18.40 mouth (inner X=+/-9.20), roots at X=+/-11.60.
- The underside rises 1.30 in Z while moving 1.30 in X (45 degrees), from z=6.30 to z=7.60; a 0.40 vertical tip ends flush at z=8.00.

## Dual attachment geometry retained from v1.3

- Brass-fastener centers: (-20.00, 0.00) and (20.00, 0.00).
- Through paths: X-axis capsules, 3.60 long x 1.80 wide.
- Top head recesses: 8.50 diameter x 3.00 deep.
- Non-clutch feet: solid 5.20 diameter x 2.85 high roof posts (22 / 50).
- Six selected clutch positions retain their open Medium-fit tubes and add bottom C anchors: 6.00 diameter x 0.60 high, with 1.55 x 4.20 notches facing the module center.

The underside additions begin on the build plate and require no support. Overall footprints remain unchanged. Relative to v1.3, every mesh difference is constrained to the declared strap envelope and no new positive geometry rises above z=8.00.

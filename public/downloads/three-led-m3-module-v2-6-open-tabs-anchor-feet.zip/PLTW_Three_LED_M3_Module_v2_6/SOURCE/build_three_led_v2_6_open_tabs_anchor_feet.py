from __future__ import annotations

import csv
import json
import math
import sys
import zipfile
from pathlib import Path


CAD_DEPS = Path(r"C:\Users\trira\.codex\tmp\cad_pydeps")
sys.path.insert(0, str(CAD_DEPS))

import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont


OUTPUT_DIR = Path(__file__).resolve().parent
LATEST_DIR = OUTPUT_DIR.parent
SOURCE_V25 = (
    LATEST_DIR
    / "24_Three_LED_v2_5_ResistorStandard_Tabs"
    / "PLTW_Three_LED_LEGO_Module_v2_5_FFit_DualMount_"
    "OpenBrickTabs_3p4x1p8.stl"
)

OUTPUT_STL = OUTPUT_DIR / (
    "PLTW_Three_LED_LEGO_Module_v2_6_FFit_DualMount_"
    "OpenBrickTabs_AnchoredCouponFFeet_3p4x1p8.stl"
)
OUTPUT_ZIP = OUTPUT_DIR / (
    "PLTW_Three_LED_M3_Module_v2_6_Open_Tabs_Anchor_Feet.zip"
)

ANCHOR_FOOT_RADIUS = 3.00
ANCHOR_FOOT_HEIGHT = 0.60
ANCHOR_NOTCH_LENGTH = 4.20
ANCHOR_NOTCH_WIDTH = 1.55

CLUTCH_CENTERS = [
    (-20.0, -12.0),
    (-20.0, 12.0),
    (-4.0, -4.0),
    (4.0, 4.0),
    (20.0, -12.0),
    (20.0, 12.0),
]
TUBE_GRID = [
    (x, y)
    for x in (-20.0, -12.0, -4.0, 4.0, 12.0, 20.0)
    for y in (-12.0, -4.0, 4.0, 12.0)
]
NON_CLUTCH_CENTERS = [
    point for point in TUBE_GRID if point not in CLUTCH_CENTERS
]
BODY_STUD_CENTERS = [
    (x, y)
    for x in (-24.0, -16.0, -8.0, 0.0, 8.0, 16.0, 24.0)
    for y in (-16.0, -8.0, 0.0, 8.0, 16.0)
]
TAB_STUD_CENTERS = [
    (-40.0, 0.0),
    (-32.0, 0.0),
    (32.0, 0.0),
    (40.0, 0.0),
]
TERMINAL_X = (-16.0, 0.0, 16.0)
TERMINAL_Y = (-11.5, 11.5)
LED_CENTERS = [(-16.0, 0.0), (0.0, 0.0), (16.0, 0.0)]


def cylinder_at(
    x: float,
    y: float,
    radius: float,
    height: float,
    z0: float = 0.0,
    sections: int = 64,
) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(
        radius=radius,
        height=height,
        sections=sections,
    )
    mesh.apply_translation([x, y, z0 + height / 2.0])
    return mesh


def inward_direction(x: float, y: float) -> tuple[float, float]:
    length = math.hypot(x, y)
    return (-x / length, -y / length)


def coupon_f_anchor_foot(x: float, y: float) -> trimesh.Trimesh:
    """Create a first-layer C pad aligned to the ring's inward split."""
    direction_x, direction_y = inward_direction(x, y)
    angle = math.atan2(direction_y, direction_x)

    disk = cylinder_at(
        x,
        y,
        ANCHOR_FOOT_RADIUS,
        ANCHOR_FOOT_HEIGHT,
    )
    notch = trimesh.creation.box(
        extents=[
            ANCHOR_NOTCH_LENGTH,
            ANCHOR_NOTCH_WIDTH,
            ANCHOR_FOOT_HEIGHT + 0.40,
        ]
    )
    notch.apply_transform(
        trimesh.transformations.rotation_matrix(
            angle,
            [0.0, 0.0, 1.0],
        )
    )
    notch.apply_translation(
        [
            x + direction_x * 2.0,
            y + direction_y * 2.0,
            ANCHOR_FOOT_HEIGHT / 2.0,
        ]
    )
    return trimesh.boolean.difference(
        [disk, notch],
        engine="manifold",
    )


def build_base() -> tuple[trimesh.Trimesh, trimesh.Trimesh]:
    source = trimesh.load_mesh(SOURCE_V25)
    anchor_feet = [
        coupon_f_anchor_foot(x, y)
        for x, y in CLUTCH_CENTERS
    ]
    result = trimesh.boolean.union(
        [source, *anchor_feet],
        engine="manifold",
    )
    result.remove_unreferenced_vertices()
    result.export(OUTPUT_STL)
    return source, result


def contains_points(
    mesh: trimesh.Trimesh,
    points: list[tuple[float, float, float]],
) -> list[bool]:
    return [bool(value) for value in mesh.contains(np.asarray(points))]


def validate(
    source: trimesh.Trimesh,
    mesh: trimesh.Trimesh,
) -> dict[str, object]:
    components = len(mesh.split(only_watertight=False))
    tube_bore_points = [
        (x, y, z)
        for x, y in TUBE_GRID
        for z in (0.05, 0.30, 0.59, 0.61, 1.40, 2.30)
    ]
    non_clutch_bore_points = [
        (x, y, z)
        for x, y in NON_CLUTCH_CENTERS
        for z in (0.05, 0.30, 0.59, 0.61, 1.40, 2.30)
    ]

    anchor_material_points = []
    anchor_above_points = []
    anchor_notch_points = []
    for x, y in CLUTCH_CENTERS:
        direction_x, direction_y = inward_direction(x, y)
        perpendicular_x, perpendicular_y = -direction_y, direction_x
        material_xy = [
            (x - direction_x * 1.50, y - direction_y * 1.50),
            (x + perpendicular_x * 1.60, y + perpendicular_y * 1.60),
            (x - perpendicular_x * 1.60, y - perpendicular_y * 1.60),
        ]
        for point_x, point_y in material_xy:
            for z in (0.05, 0.30, 0.59):
                anchor_material_points.append((point_x, point_y, z))
            anchor_above_points.append((point_x, point_y, 0.61))
        for radius in (0.0, 0.75, 1.50, 2.50):
            for z in (0.05, 0.30, 0.59):
                anchor_notch_points.append(
                    (
                        x + direction_x * radius,
                        y + direction_y * radius,
                        z,
                    )
                )

    body_stud_points = [
        (x, y, 1.40) for x, y in BODY_STUD_CENTERS
    ]
    tab_stud_points = [
        (x, y, 1.40) for x, y in TAB_STUD_CENTERS
    ]
    tab_path_points = [
        (sign * x, 0.0, 1.40)
        for sign in (-1.0, 1.0)
        for x in (28.0, 32.0, 36.0, 40.0)
    ]
    slit_points = [
        (sign * 36.0, 0.0, z)
        for sign in (-1.0, 1.0)
        for z in (0.50, 4.75, 9.00)
    ]
    nut_path_points = [
        (x, sign * y, 5.75)
        for x in TERMINAL_X
        for sign in (-1.0, 1.0)
        for y in (9.0, 11.5, 15.0, 19.0)
    ]
    screw_bore_points = [
        (x, y, z)
        for x in TERMINAL_X
        for y in TERMINAL_Y
        for z in (5.75, 8.00, 10.00, 12.00)
    ]
    led_pocket_points = [
        (x, y, z)
        for x, y in LED_CENTERS
        for z in (10.00, 12.00)
    ]

    checks = {
        "watertight": bool(mesh.is_watertight),
        "winding_consistent": bool(mesh.is_winding_consistent),
        "components": components,
        "extents_mm": [round(float(value), 3) for value in mesh.extents],
        "bounds_mm": [
            [round(float(value), 3) for value in row]
            for row in mesh.bounds
        ],
        "faces": int(len(mesh.faces)),
        "anchor_feet_expected": len(CLUTCH_CENTERS),
        "anchor_foot_material_present_through_z_0p59": all(
            contains_points(mesh, anchor_material_points)
        ),
        "anchor_foot_material_ends_before_z_0p61": not any(
            contains_points(mesh, anchor_above_points)
        ),
        "anchor_notches_open_toward_center": not any(
            contains_points(mesh, anchor_notch_points)
        ),
        "all_24_original_tube_centerlines_open": not any(
            contains_points(mesh, tube_bore_points)
        ),
        "all_18_non_clutch_tube_centerlines_open": not any(
            contains_points(mesh, non_clutch_bore_points)
        ),
        "all_35_body_stud_centers_open": not any(
            contains_points(mesh, body_stud_points)
        ),
        "four_tab_continuation_stud_centers_open": not any(
            contains_points(mesh, tab_stud_points)
        ),
        "both_tab_portal_paths_open": not any(
            contains_points(mesh, tab_path_points)
        ),
        "both_brad_slits_open_through_tab": not any(
            contains_points(mesh, slit_points)
        ),
        "all_six_m3_nut_loading_paths_open": not any(
            contains_points(mesh, nut_path_points)
        ),
        "all_six_m3_screw_bores_open": not any(
            contains_points(mesh, screw_bore_points)
        ),
        "all_three_led_pockets_open": not any(
            contains_points(mesh, led_pocket_points)
        ),
        "source_extents_preserved": bool(
            np.allclose(mesh.extents, source.extents, atol=1e-6)
        ),
        "added_anchor_volume_mm3": round(
            float(mesh.volume - source.volume),
            3,
        ),
        "tab_centers_mm": [[-36.0, 0.0], [36.0, 0.0]],
        "brad_slit_mm": [3.4, 1.8],
        "tab_portal_mm": [4.0, 6.4, 2.72],
    }

    required = (
        checks["watertight"]
        and checks["winding_consistent"]
        and components == 1
        and checks["anchor_foot_material_present_through_z_0p59"]
        and checks["anchor_foot_material_ends_before_z_0p61"]
        and checks["anchor_notches_open_toward_center"]
        and checks["all_24_original_tube_centerlines_open"]
        and checks["all_18_non_clutch_tube_centerlines_open"]
        and checks["all_35_body_stud_centers_open"]
        and checks["four_tab_continuation_stud_centers_open"]
        and checks["both_tab_portal_paths_open"]
        and checks["both_brad_slits_open_through_tab"]
        and checks["all_six_m3_nut_loading_paths_open"]
        and checks["all_six_m3_screw_bores_open"]
        and checks["all_three_led_pockets_open"]
        and checks["source_extents_preserved"]
    )
    checks["all_required_checks_pass"] = bool(required)
    return checks


def write_validation(checks: dict[str, object]) -> None:
    (OUTPUT_DIR / "MESH_AND_CLEARANCE_VALIDATION.json").write_text(
        json.dumps(checks, indent=2) + "\n",
        encoding="utf-8",
    )
    lines = [
        "# Three-LED v2.6 mesh and clearance validation",
        "",
        f"- Watertight: `{checks['watertight']}`",
        f"- Winding consistent: `{checks['winding_consistent']}`",
        f"- Connected components: `{checks['components']}`",
        f"- Mesh extents: `{checks['extents_mm']} mm`",
        f"- Coupon-F C-shaped anchor feet: `{checks['anchor_feet_expected']}`",
        f"- Anchor material present through Z=0.59 mm: `{checks['anchor_foot_material_present_through_z_0p59']}`",
        f"- Anchor material ends before Z=0.61 mm: `{checks['anchor_foot_material_ends_before_z_0p61']}`",
        f"- All inward anchor notches open: `{checks['anchor_notches_open_toward_center']}`",
        f"- All 24 original tube centerlines open: `{checks['all_24_original_tube_centerlines_open']}`",
        f"- All 18 non-clutch tube centerlines open: `{checks['all_18_non_clutch_tube_centerlines_open']}`",
        f"- All 35 body stud centers open: `{checks['all_35_body_stud_centers_open']}`",
        f"- Four continuation-stud centers beneath tabs open: `{checks['four_tab_continuation_stud_centers_open']}`",
        f"- Both tab-to-base portal paths open: `{checks['both_tab_portal_paths_open']}`",
        f"- Both brass-fastener slits open through the tabs: `{checks['both_brad_slits_open_through_tab']}`",
        f"- All six M3 nut-loading paths open: `{checks['all_six_m3_nut_loading_paths_open']}`",
        f"- All six M3 screw bores open: `{checks['all_six_m3_screw_bores_open']}`",
        f"- All three LED pockets open: `{checks['all_three_led_pockets_open']}`",
        f"- All required automated checks pass: `{checks['all_required_checks_pass']}`",
        "",
        "The v2.5 end tabs and open underside paths are retained without modification.",
        "These checks do not replace a pilot print with the classroom LEGO plate, LEDs, M3 hardware, cardboard, and brass fasteners.",
        "",
    ]
    (OUTPUT_DIR / "MESH_AND_CLEARANCE_VALIDATION.md").write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def write_dimensions(mesh: trimesh.Trimesh) -> None:
    rows = [
        ("Feature", "Value"),
        ("LEGO body footprint", "7 x 5 studs / 56 x 40 mm"),
        (
            "Overall base with cardboard tabs",
            f"{mesh.extents[0]:.1f} x {mesh.extents[1]:.1f} x {mesh.extents[2]:.1f} mm",
        ),
        ("LEGO interface", "Six Coupon-F split clutch tubes with C anchor feet"),
        ("Original underside tube bores", "All 24 centerlines remain open"),
        ("Non-clutch support tubes", "18 hollow original tubes retained"),
        ("Anchor foot diameter x height", "6.00 x 0.60 mm"),
        ("Anchor notch", "4.20 x 1.55 mm, aligned inward with each split"),
        ("Cardboard tabs", "Two open one-stud-wide x two-stud-long tabs"),
        ("Tab centers", "X = -36 mm and +36 mm; Y = 0 mm"),
        ("Brass-fastener slit", "3.4 x 1.8 mm capsule"),
        ("Brad head recess", "9.1 mm diameter x 1.22 mm deep"),
        ("Tab underside cavity", "16.0 x 6.4 x 2.72 mm"),
        ("Tab-to-base portal", "4.0 x 6.4 x 2.72 mm"),
        ("LED pockets", "Three 5.25 mm pockets at X = -16, 0, +16 mm"),
        ("M3 terminals", "Six side-loaded captive-nut terminals"),
        ("M3 hardware", "6 x M3 x 6 mm, nuts, and washers"),
    ]
    with (OUTPUT_DIR / "PLTW_Three_LED_v2_6_Dimensions.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        csv.writer(handle).writerows(rows)


def render_isometric(
    specs: list[tuple[trimesh.Trimesh, tuple[int, int, int]]],
    filename: str,
    title: str,
    footer: str,
) -> None:
    view = np.array([1.0, -1.35, 0.90])
    view /= np.linalg.norm(view)
    right = np.cross(view, np.array([0.0, 0.0, 1.0]))
    right /= np.linalg.norm(right)
    up = np.cross(right, view)
    up /= np.linalg.norm(up)
    light = np.array([0.30, -0.45, 0.84])
    light /= np.linalg.norm(light)

    triangles = []
    projected_all = []
    for mesh, color in specs:
        triangle_vertices = mesh.vertices[mesh.faces]
        normals = np.cross(
            triangle_vertices[:, 1] - triangle_vertices[:, 0],
            triangle_vertices[:, 2] - triangle_vertices[:, 0],
        )
        lengths = np.linalg.norm(normals, axis=1)
        valid = lengths > 1e-9
        normals[valid] /= lengths[valid, None]
        facing = normals @ view > -0.10
        for triangle, normal in zip(
            triangle_vertices[facing],
            normals[facing],
        ):
            projected = np.column_stack(
                (triangle @ right, -(triangle @ up))
            )
            depth = float(np.mean(triangle @ view))
            shade = 0.70 + 0.30 * max(0.0, float(normal @ light))
            shaded = tuple(
                max(0, min(255, int(channel * shade)))
                for channel in color
            )
            triangles.append((depth, projected, shaded))
            projected_all.append(projected)

    all_points = np.vstack(projected_all)
    low = all_points.min(axis=0)
    high = all_points.max(axis=0)
    canvas = (1500, 1000)
    margin = 110
    scale = min(
        (canvas[0] - 2 * margin) / (high[0] - low[0]),
        (canvas[1] - 2 * margin - 100) / (high[1] - low[1]),
    )
    offset = np.array(
        [
            (canvas[0] - (high[0] - low[0]) * scale) / 2
            - low[0] * scale,
            100
            + (canvas[1] - 175 - (high[1] - low[1]) * scale) / 2
            - low[1] * scale,
        ]
    )

    image = Image.new("RGB", canvas, (247, 249, 252))
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    draw.text((45, 28), title, fill=(30, 40, 54), font=font)
    for _, projected, color in sorted(
        triangles,
        key=lambda item: item[0],
    ):
        points = [
            (
                float(x * scale + offset[0]),
                float(y * scale + offset[1]),
            )
            for x, y in projected
        ]
        draw.polygon(points, fill=color)
    draw.text((45, 955), footer, fill=(30, 40, 54), font=font)
    image.save(OUTPUT_DIR / filename)


def led_preview_part(
    x: float,
    color: tuple[int, int, int],
) -> tuple[trimesh.Trimesh, tuple[int, int, int]]:
    stem = cylinder_at(x, 0.0, 2.50, 4.75, z0=10.0)
    dome = trimesh.creation.uv_sphere(radius=2.50, count=[32, 16])
    dome.apply_translation([x, 0.0, 14.75])
    return trimesh.util.concatenate([stem, dome]), color


def terminal_hardware() -> trimesh.Trimesh:
    pieces = []
    for x in TERMINAL_X:
        for y in TERMINAL_Y:
            pieces.append(cylinder_at(x, y, 5.0, 0.70, z0=10.0))
            pieces.append(cylinder_at(x, y, 3.15, 1.50, z0=10.70))
    return trimesh.util.concatenate(pieces)


def render_previews(base: trimesh.Trimesh) -> None:
    red_led = led_preview_part(-16.0, (212, 62, 64))
    yellow_led = led_preview_part(0.0, (232, 184, 55))
    green_led = led_preview_part(16.0, (65, 168, 105))
    hardware = terminal_hardware()

    render_isometric(
        [
            (base, (174, 184, 194)),
            red_led,
            yellow_led,
            green_led,
            (hardware, (195, 199, 203)),
        ],
        "PLTW_Three_LED_v2_6_Assembly_Preview.png",
        "PLTW THREE-LED v2.6 - OPEN TABS + ANCHOR FEET",
        "Six M3 terminals; three 5 mm LED pockets; two open 3.4 x 1.8 mm cardboard tabs.",
    )

    render_isometric(
        [(base, (174, 184, 194))],
        "PLTW_Three_LED_v2_6_Top_Preview.png",
        "THREE-LED v2.6 - PRINTABLE BASE",
        "The physically successful LED layout and all six side-loaded M3 nut paths are retained.",
    )

    underside = base.copy()
    underside.apply_transform(
        trimesh.transformations.rotation_matrix(
            math.radians(180.0),
            [1.0, 0.0, 0.0],
        )
    )
    render_isometric(
        [(underside, (174, 184, 194))],
        "PLTW_Three_LED_v2_6_Underside_Preview.png",
        "THREE-LED v2.6 - LEGO UNDERSIDE",
        "All 24 tube centerlines stay open; six Coupon-F tubes gain aligned 0.60 mm C anchor feet.",
    )


def create_package() -> None:
    package_names = [
        "README_FIRST.md",
        OUTPUT_STL.name,
        "PLTW_Three_LED_v2_6_Dimensions.csv",
        "MESH_AND_CLEARANCE_VALIDATION.md",
        "MESH_AND_CLEARANCE_VALIDATION.json",
        "PLTW_Three_LED_v2_6_Assembly_Preview.png",
        "PLTW_Three_LED_v2_6_Top_Preview.png",
        "PLTW_Three_LED_v2_6_Underside_Preview.png",
    ]
    prefix = "PLTW_Three_LED_M3_Module_v2_6"
    with zipfile.ZipFile(
        OUTPUT_ZIP,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for name in package_names:
            archive.write(OUTPUT_DIR / name, f"{prefix}/{name}")
        archive.write(
            Path(__file__),
            f"{prefix}/SOURCE/{Path(__file__).name}",
        )


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    source, base = build_base()
    checks = validate(source, base)
    write_validation(checks)
    write_dimensions(base)
    render_previews(base)
    create_package()

    print(f"output_stl={OUTPUT_STL}")
    print(f"output_zip={OUTPUT_ZIP}")
    print(f"watertight={checks['watertight']}")
    print(f"winding={checks['winding_consistent']}")
    print(f"components={checks['components']}")
    print(f"extents_mm={checks['extents_mm']}")
    print(f"anchor_feet={checks['anchor_feet_expected']}")
    print(f"all_required_checks_pass={checks['all_required_checks_pass']}")

    if not checks["all_required_checks_pass"]:
        raise SystemExit("Required mesh or clearance validation failed")


if __name__ == "__main__":
    main()

# PLTW Three-LED M3 Terminal Module v2.6

This revision keeps the physically successful three-LED holder, six M3
terminals, polarity labels, Coupon-F interface, and open cardboard tabs from
v2.5. It adds the first-layer anchor treatment without filling the module's
original hollow underside tubes.

## What changed

- Added one 0.60 mm C-shaped first-layer anchor foot beneath each of the six
  Coupon-F clutch tubes.
- Rotated every anchor-foot notch toward the center to match its existing
  inward Coupon-F split.
- Kept all 24 original underside tube centerlines open, including all 18
  non-clutch support tubes; no solid support plugs were added.
- Retained the two short-end brick-style cardboard tabs from v2.5.
- Retained the fully open 6.4 mm tab cavities and portals into the main LEGO
  cavity, with no hidden floor or partition.
- Retained the 3.4 x 1.8 mm brass-fastener slits and shallow 9.1 mm head
  recesses.
- Kept all six M3 nut-loading paths, all six screw bores, and all three LED
  pockets open.

The tabs remain on the short X ends because the six captive nuts load from the
two long Y sides. Moving the tabs to the long sides would interfere with those
paths.

## Hardware

- Three 5 mm LEDs
- Six M3 x 6 mm screws
- Six standard M3 hex nuts
- Six 9-10 mm M3 washers
- One current-limiting resistor for every LED circuit
- Two classroom brass fasteners for direct cardboard mounting

## Printing

- Bambu A1 mini or comparable printer
- PLA with a 0.4 mm nozzle
- Bambu 0.20 mm Standard profile
- Keep the remaining process settings at their defaults
- LEGO underside on the build plate
- Supports off; raft off
- Use the supplied orientation

## Assembly

1. Insert all six M3 nuts through the long-side loading openings.
2. Install each LED with its longer anode lead routed toward `+` and its shorter
   cathode lead routed toward `-`.
3. Capture each lead beneath a washer and tighten gently.
4. Always include an appropriate current-limiting resistor in each circuit.
5. For cardboard use, insert both brass fasteners from the top, pass their legs
   through the cardboard, spread the legs, and cover exposed metal with tape.

## Pilot-print status

The LED bodies and terminal layout were physically successful before this
revision. Automated checks confirm that the v2.6 mesh is watertight and one
component, all six anchor feet and aligned notches are present, every original
tube and LEGO stud center remains open, the cardboard paths are continuous,
and all LED and M3 openings remain clear.

The combined anchor-foot and dual-mount revision remains a prototype. Before
classroom quantities, pilot one complete assembly on the classroom LEGO plate
and confirm first-layer adhesion, full seating and removal, all six M3 nuts,
LED fit and polarity, cardboard seating, and both brass fasteners.

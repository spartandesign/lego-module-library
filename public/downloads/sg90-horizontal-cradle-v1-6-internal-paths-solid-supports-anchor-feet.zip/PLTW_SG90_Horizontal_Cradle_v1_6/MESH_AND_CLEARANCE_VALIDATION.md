# SG90 Horizontal Cradle v1.6 validation

- Overall verdict: `PASS`
- Watertight / winding / one component: `True` / `True` / `True`
- Every edge has two incident faces: `True`
- No degenerate or duplicate faces: `True` / `True`
- Prior loose STL equals prior ZIP member byte-for-byte: `True`
- Removal only and confined to the two paths: `True` / `True`
- Exact expected boolean result after STL reload: `True`
- Extents unchanged: `True`
- Full / trimmed solid support cores: `True` / `True`
- 6 Coupon-F bores open; 6 C anchors retained: `True` / `True`
- C-anchor notches open: `True`
- LEGO seating centerlines open at three heights: `True`
- Both 3.60 x 1.80 paths open: `True`
- Mechanism clearances open and all non-path geometry preserved: `True` / `True`
- ZIP CRC / no duplicates / byte-exact files / exact source: `True` / `True` / `True` / `True`
- All required checks pass: `True`

A physical print, cardboard fit, LEGO clutch, servo fit, and full motion pilot remain required.

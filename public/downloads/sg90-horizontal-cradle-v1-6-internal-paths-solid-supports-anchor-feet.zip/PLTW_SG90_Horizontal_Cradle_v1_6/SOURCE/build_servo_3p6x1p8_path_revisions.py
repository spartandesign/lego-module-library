from __future__ import annotations

import csv
import hashlib
import json
import math
import shutil
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath


CAD_DEPS = Path(r"C:\Users\trira\.codex\tmp\cad_pydeps")
sys.path.insert(0, str(CAD_DEPS))

import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont


OUTPUT_ROOT = Path(__file__).resolve().parent
SOURCE_ROOT = OUTPUT_ROOT.parent / "33_Buzzer_and_Servo_Supportless_Upgrades"
PATH_OVERALL = 3.60
PATH_WIDTH = 1.80
SUPPORT_HEIGHT = 2.85
SUPPORT_DIAMETER = 5.20
ANCHOR_HEIGHT = 0.60
BOOLEAN_TOLERANCE_MM3 = 0.0002


def grid(xs: tuple[float, ...], ys: tuple[float, ...]) -> tuple[tuple[float, float], ...]:
    return tuple((x, y) for x in xs for y in ys)


SHARED_TUBES = grid(
    (-24.0, -16.0, -8.0, 0.0, 8.0, 16.0, 24.0),
    (-16.0, -8.0, 0.0, 8.0, 16.0),
)
SHARED_CLUTCH = tuple((x, y) for x in (-24.0, 0.0, 24.0) for y in (-16.0, 16.0))
SHARED_STUDS = grid(
    (-28.0, -20.0, -12.0, -4.0, 4.0, 12.0, 20.0, 28.0),
    (-20.0, -12.0, -4.0, 4.0, 12.0, 20.0),
)
VERTICAL_TUBES = grid(
    (-24.0, -16.0, -8.0, 0.0, 8.0, 16.0, 24.0),
    (-8.0, 0.0, 8.0),
)
VERTICAL_CLUTCH = tuple((x, y) for x in (-24.0, 0.0, 24.0) for y in (-8.0, 8.0))
VERTICAL_STUDS = tuple(
    (x, y)
    for x, y in grid(
        (-28.0, -20.0, -12.0, -4.0, 4.0, 12.0, 20.0, 28.0),
        (-12.0, -4.0, 4.0, 12.0),
    )
    if not (abs(x) == 28.0 and abs(y) == 4.0)
)
DOOR_TUBES = grid(
    (-32.0, -24.0, -16.0, -8.0, 0.0, 8.0, 16.0, 24.0, 32.0),
    (-16.0, -8.0, 0.0, 8.0, 16.0),
)
DOOR_CLUTCH = tuple((x, y) for x in (-32.0, 0.0, 32.0) for y in (-16.0, 16.0))
DOOR_STUDS = grid(
    (-36.0, -28.0, -20.0, -12.0, -4.0, 4.0, 12.0, 20.0, 28.0, 36.0),
    (-20.0, -12.0, -4.0, 4.0, 12.0, 20.0),
)


@dataclass(frozen=True)
class ModuleConfig:
    key: str
    title: str
    version: str
    prior_version: str
    file_prefix: str
    archive_prefix: str
    source_subdir: str
    source_stl_name: str
    source_zip_name: str
    output_stl_name: str
    output_zip_name: str
    footprint: str
    tube_centers: tuple[tuple[float, float], ...]
    clutch_centers: tuple[tuple[float, float], ...]
    split_directions: tuple[tuple[float, float], ...]
    stud_centers: tuple[tuple[float, float], ...]
    mount_mode: str
    path_centers: tuple[tuple[float, float], ...]
    accessories: tuple[str, ...]
    preserved_features: tuple[str, ...]
    pilot_note: str
    preview_kind: str = "horizontal"
    tab_centers_x: tuple[float, float] | None = None
    body_edges_x: tuple[float, float] | None = None
    tab_height: float = 9.50
    portal_trimmed_support_centers: tuple[tuple[float, float], ...] = ()

    @property
    def source_dir(self) -> Path:
        return SOURCE_ROOT / self.source_subdir

    @property
    def source_stl(self) -> Path:
        return self.source_dir / self.source_stl_name

    @property
    def source_zip(self) -> Path:
        return self.source_dir / self.source_zip_name

    @property
    def output_dir(self) -> Path:
        return OUTPUT_ROOT / self.key

    @property
    def output_stl(self) -> Path:
        return self.output_dir / self.output_stl_name

    @property
    def output_zip(self) -> Path:
        return self.output_dir / self.output_zip_name


COMMON_ASSETS = (
    "MECHANISM_ASSEMBLY_REFERENCE.md",
    "PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl",
)


CONFIGS = (
    ModuleConfig(
        key="servo_horizontal_v1_6",
        title="SG90 Horizontal Cradle",
        version="v1.6",
        prior_version="v1.5",
        file_prefix="PLTW_SG90_Horizontal_Cradle_v1_6",
        archive_prefix="PLTW_SG90_Horizontal_Cradle_v1_6",
        source_subdir="servo_horizontal_v1_5",
        source_stl_name="PLTW_SG90_Horizontal_Cradle_v1_5_DualMount.stl",
        source_zip_name="PLTW_SG90_Horizontal_Cradle_v1_5_Internal_Paths_Solid_Supports_Anchor_Feet.zip",
        output_stl_name="PLTW_SG90_Horizontal_Cradle_v1_6_DualMount.stl",
        output_zip_name="sg90-horizontal-cradle-v1-6-internal-paths-solid-supports-anchor-feet.zip",
        footprint="8 x 6 studs / 64 x 48 mm",
        tube_centers=SHARED_TUBES,
        clutch_centers=SHARED_CLUTCH,
        split_directions=((0.0, 1.0),) * 6,
        stud_centers=SHARED_STUDS,
        mount_mode="internal_paths",
        path_centers=((-20.0, -12.0), (20.0, -12.0)),
        accessories=COMMON_ASSETS + ("PLTW_SG90_Horizontal_Cradle_v1_3_Retaining_Strap.stl",),
        preserved_features=(
            "12.4 mm body fit and 1.8 mm retaining-post pilots",
            "two 8 mm label-up horn gaps",
            "central rear wire exit and exact retaining strap",
        ),
        pilot_note="Pilot the widened cardboard paths with the intended board and brass fasteners before classroom quantities.",
    ),
    ModuleConfig(
        key="servo_vertical_v1_3",
        title="SG90 Vertical Cradle",
        version="v1.3",
        prior_version="v1.2",
        file_prefix="PLTW_SG90_Vertical_Cradle_v1_3",
        archive_prefix="PLTW_SG90_Vertical_Cradle_v1_3",
        source_subdir="servo_vertical_v1_2",
        source_stl_name="PLTW_SG90_Vertical_Cradle_v1_2_DualMount.stl",
        source_zip_name="PLTW_SG90_Vertical_Cradle_v1_2_Open_Tabs_Solid_Supports_Anchor_Feet.zip",
        output_stl_name="PLTW_SG90_Vertical_Cradle_v1_3_DualMount.stl",
        output_zip_name="sg90-vertical-cradle-v1-3-open-tabs-solid-supports-anchor-feet.zip",
        footprint="compact 56 x 24 mm body plus two open X-end tabs",
        tube_centers=VERTICAL_TUBES,
        clutch_centers=VERTICAL_CLUTCH,
        split_directions=((0.0, 1.0),) * 6,
        stud_centers=VERTICAL_STUDS,
        mount_mode="open_tabs",
        path_centers=((-36.0, 0.0), (36.0, 0.0)),
        tab_centers_x=(-36.0, 36.0),
        body_edges_x=(-28.0, 28.0),
        accessories=COMMON_ASSETS,
        preserved_features=(
            "12.5 mm body channel and 27.5 mm ear spacing",
            "1.8 mm tower pilots and both lower wire portals",
            "upright horn sweep above the 25 mm towers",
            "two open brick-style X-end tabs and four continuation seating cavities",
        ),
        pilot_note="Pilot the widened open tabs with the intended cardboard and brass fasteners before classroom quantities.",
        preview_kind="vertical",
        portal_trimmed_support_centers=((-24.0, 0.0), (24.0, 0.0)),
    ),
    ModuleConfig(
        key="servo_gauge_v2_1",
        title="SG90 Upright Dashboard Gauge",
        version="v2.1",
        prior_version="v2.0",
        file_prefix="PLTW_SG90_Upright_Dashboard_Gauge_v2_1",
        archive_prefix="PLTW_SG90_Upright_Dashboard_Gauge_v2_1",
        source_subdir="servo_gauge_v2_0",
        source_stl_name="PLTW_SG90_Upright_Dashboard_Gauge_v2_0_DualMount.stl",
        source_zip_name="PLTW_SG90_Upright_Dashboard_Gauge_v2_0_Solid_Supports_Anchor_Feet.zip",
        output_stl_name="PLTW_SG90_Upright_Dashboard_Gauge_v2_1_DualMount.stl",
        output_zip_name="sg90-upright-dashboard-gauge-v2-1-solid-supports-anchor-feet.zip",
        footprint="8 x 6 studs / 64 x 48 mm",
        tube_centers=SHARED_TUBES,
        clutch_centers=SHARED_CLUTCH,
        split_directions=((0.0, -1.0),) * 6,
        stud_centers=SHARED_STUDS,
        mount_mode="internal_paths",
        path_centers=((-20.0, 12.0), (20.0, 12.0)),
        accessories=COMMON_ASSETS
        + (
            "PLTW_SG90_Gauge_Panel_v1_8_60mm_RightOpening_0_90_180.stl",
            "PLTW_SG90_Gauge_Panel_v1_8_60mm_RightOpening_P2_4_SAFE_ARMED_ALERT.stl",
            "PLTW_SG90_Gauge_Panel_v1_8_60mm_RightOpening_P3_2_READY_ACTIVE_DONE.stl",
            "PLTW_SG90_Upright_Dashboard_v1_8_Retaining_Strap.stl",
        ),
        preserved_features=(
            "three exact 60 mm panels and their holder engagement",
            "18 mm right-side horn opening and label-up orientation",
            "raised markings, wire exit, and exact retaining strap",
        ),
        pilot_note="Pilot the widened cardboard paths and complete pointer sweep before classroom quantities.",
    ),
    ModuleConfig(
        key="servo_latch_v1_3",
        title="SG90 Positional Latch / Deadbolt",
        version="v1.3",
        prior_version="v1.2",
        file_prefix="PLTW_SG90_Positional_Latch_Deadbolt_v1_3",
        archive_prefix="PLTW_SG90_Positional_Latch_Deadbolt_v1_3",
        source_subdir="servo_latch_v1_2",
        source_stl_name="PLTW_SG90_Positional_Latch_Deadbolt_v1_2_DualMount.stl",
        source_zip_name="PLTW_SG90_Latch_Deadbolt_Module_v1_2_Solid_Supports_Anchor_Feet.zip",
        output_stl_name="PLTW_SG90_Positional_Latch_Deadbolt_v1_3_DualMount.stl",
        output_zip_name="sg90-latch-deadbolt-module-v1-3-solid-supports-anchor-feet.zip",
        footprint="8 x 6 studs / 64 x 48 mm",
        tube_centers=SHARED_TUBES,
        clutch_centers=SHARED_CLUTCH,
        split_directions=((0.0, 1.0),) * 6,
        stud_centers=SHARED_STUDS,
        mount_mode="internal_paths",
        path_centers=((-20.0, -12.0), (12.0, -4.0)),
        accessories=COMMON_ASSETS + ("PLTW_SG90_Positional_Latch_Deadbolt_v1_Retaining_Strap.stl",),
        preserved_features=(
            "single-arm horn as the moving bolt",
            "reinforced open-top keeper and closed end stop",
            "90-degree unlocked / tuned-toward-zero locked workflow",
        ),
        pilot_note="Pilot the widened paths, horn sweep, keeper clearance, and stall-safe endpoints before classroom quantities.",
    ),
    ModuleConfig(
        key="servo_door_v1_3",
        title="SG90 Positional Door / Flap Linkage",
        version="v1.3",
        prior_version="v1.2",
        file_prefix="PLTW_SG90_Door_Flap_Linkage_v1_3",
        archive_prefix="PLTW_SG90_Door_Flap_Linkage_v1_3",
        source_subdir="servo_door_v1_2",
        source_stl_name="PLTW_SG90_Door_Flap_Linkage_v1_2_DualMount.stl",
        source_zip_name="PLTW_SG90_Door_Flap_Linkage_Module_v1_2_Solid_Supports_Anchor_Feet.zip",
        output_stl_name="PLTW_SG90_Door_Flap_Linkage_v1_3_DualMount.stl",
        output_zip_name="sg90-door-flap-linkage-module-v1-3-solid-supports-anchor-feet.zip",
        footprint="10 x 6 studs / 80 x 48 mm",
        tube_centers=DOOR_TUBES,
        clutch_centers=DOOR_CLUTCH,
        split_directions=((0.0, 1.0),) * 6,
        stud_centers=DOOR_STUDS,
        mount_mode="internal_paths",
        path_centers=((-28.0, -12.0), (28.0, -12.0)),
        accessories=COMMON_ASSETS
        + (
            "PLTW_SG90_Door_Flap_Linkage_v1_8_32_Hinged_Flap.stl",
            "PLTW_SG90_Door_Flap_Linkage_v1_Retaining_Strap.stl",
            "PLTW_SG90_Door_Flap_Link_v1_25p5mm.stl",
            "PLTW_SG90_Door_Flap_Link_v1_26p0mm.stl",
            "PLTW_SG90_Door_Flap_Link_v1_26p5mm.stl",
        ),
        preserved_features=(
            "4.6 mm horizontal 8-32 hinge and 0.5 mm flap side clearance",
            "three exact link lengths: 25.5, 26.0, and 26.5 mm",
            "two 3.6 mm flap attachment holes and the original retaining strap",
        ),
        pilot_note="Pilot the widened paths, hinge cleanup, linkage binding, and safe endpoints before classroom quantities.",
    ),
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cylinder_at(
    x: float,
    y: float,
    radius: float,
    height: float,
    z0: float = 0.0,
    sections: int = 64,
) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    mesh.apply_translation([x, y, z0 + height / 2.0])
    return mesh


def capsule_y(
    x: float,
    y: float,
    overall: float,
    width: float,
    height: float,
    z0: float,
    sections: int = 64,
) -> trimesh.Trimesh:
    radius = width / 2.0
    straight = overall - width
    middle = trimesh.creation.box(extents=[width, straight, height])
    middle.apply_translation([x, y, z0 + height / 2.0])
    ends = [
        cylinder_at(x, y + offset, radius, height, z0=z0, sections=sections)
        for offset in (-straight / 2.0, straight / 2.0)
    ]
    return as_mesh(trimesh.boolean.union([middle, *ends], engine="manifold"))


def as_mesh(value: object) -> trimesh.Trimesh:
    if value is None:
        return trimesh.Trimesh()
    if isinstance(value, trimesh.Scene):
        meshes = tuple(value.geometry.values())
        return trimesh.util.concatenate(meshes) if meshes else trimesh.Trimesh()
    if isinstance(value, (list, tuple)):
        return trimesh.util.concatenate(value) if value else trimesh.Trimesh()
    assert isinstance(value, trimesh.Trimesh)
    return value


def difference(a: trimesh.Trimesh, b: trimesh.Trimesh) -> trimesh.Trimesh:
    if len(a.faces) == 0:
        return trimesh.Trimesh()
    if len(b.faces) == 0:
        return a.copy()
    return as_mesh(trimesh.boolean.difference([a, b], engine="manifold"))


def intersection(a: trimesh.Trimesh, b: trimesh.Trimesh) -> trimesh.Trimesh:
    if len(a.faces) == 0 or len(b.faces) == 0:
        return trimesh.Trimesh()
    return as_mesh(trimesh.boolean.intersection([a, b], engine="manifold"))


def mesh_volume(mesh: trimesh.Trimesh) -> float:
    return abs(float(mesh.volume)) if len(mesh.faces) else 0.0


def support_centers(config: ModuleConfig) -> tuple[tuple[float, float], ...]:
    clutch = set(config.clutch_centers)
    return tuple(point for point in config.tube_centers if point not in clutch)


def source_zip_stl_is_exact(config: ModuleConfig) -> tuple[bool, str]:
    with zipfile.ZipFile(config.source_zip) as archive:
        matches = [
            name
            for name in archive.namelist()
            if PurePosixPath(name).name == config.source_stl_name
        ]
        if len(matches) != 1:
            return False, ""
        data = archive.read(matches[0])
    return data == config.source_stl.read_bytes(), matches[0]


def build_mesh(config: ModuleConfig) -> tuple[trimesh.Trimesh, trimesh.Trimesh, list[trimesh.Trimesh]]:
    source = as_mesh(trimesh.load_mesh(config.source_stl, process=True))
    cutter_height = config.tab_height + 2.0 if config.mount_mode == "open_tabs" else 11.0
    cutters = [
        capsule_y(x, y, PATH_OVERALL, PATH_WIDTH, cutter_height, -1.0)
        for x, y in config.path_centers
    ]
    result = source.copy()
    for cutter in cutters:
        result = difference(result, cutter)
    result.remove_unreferenced_vertices()
    config.output_dir.mkdir(parents=True, exist_ok=True)
    result.export(config.output_stl)
    exported = as_mesh(trimesh.load_mesh(config.output_stl, process=True))
    exported.remove_unreferenced_vertices()
    return source, exported, cutters


def copy_assets(config: ModuleConfig) -> dict[str, dict[str, object]]:
    records: dict[str, dict[str, object]] = {}
    for name in config.accessories:
        source = config.source_dir / name
        destination = config.output_dir / name
        shutil.copyfile(source, destination)
        records[name] = {
            "source_sha256": sha256(source),
            "output_sha256": sha256(destination),
            "byte_exact": source.read_bytes() == destination.read_bytes(),
        }
    return records


def dense_open_points(
    centers: tuple[tuple[float, float], ...],
    zs: tuple[float, ...],
    radii: tuple[float, ...] = (0.0, 1.15, 2.05),
) -> list[tuple[float, float, float]]:
    points: list[tuple[float, float, float]] = []
    for x, y in centers:
        for z in zs:
            for radius in radii:
                angles = (0.0,) if radius == 0.0 else tuple(math.radians(v) for v in range(0, 360, 45))
                for angle in angles:
                    points.append((x + radius * math.cos(angle), y + radius * math.sin(angle), z))
    return points


def all_points_outside(mesh: trimesh.Trimesh, points: list[tuple[float, float, float]]) -> bool:
    return not any(bool(value) for value in mesh.contains(np.asarray(points, dtype=float)))


def all_points_inside(mesh: trimesh.Trimesh, points: list[tuple[float, float, float]]) -> bool:
    return all(bool(value) for value in mesh.contains(np.asarray(points, dtype=float)))


def topology_checks(mesh: trimesh.Trimesh) -> dict[str, object]:
    counts = np.bincount(mesh.edges_unique_inverse)
    nondegenerate = mesh.nondegenerate_faces()
    unique = mesh.unique_faces()
    return {
        "watertight": bool(mesh.is_watertight),
        "winding_consistent": bool(mesh.is_winding_consistent),
        "connected_components": len(mesh.split(only_watertight=False)),
        "every_edge_has_two_incident_faces": bool(len(counts) and np.all(counts == 2)),
        "no_degenerate_faces": bool(np.all(nondegenerate)),
        "no_duplicate_faces": bool(np.all(unique)),
        "vertices": int(len(mesh.vertices)),
        "faces": int(len(mesh.faces)),
        "bounds_mm": [[round(float(value), 5) for value in row] for row in mesh.bounds],
        "extents_mm": [round(float(value), 5) for value in mesh.extents],
    }


def validate_supports(config: ModuleConfig, mesh: trimesh.Trimesh) -> dict[str, object]:
    trimmed = set(config.portal_trimmed_support_centers)
    full = tuple(point for point in support_centers(config) if point not in trimmed)
    missing: dict[str, float] = {}
    for x, y in full:
        core = cylinder_at(x, y, 2.48, 2.76, z0=0.04, sections=48)
        missing[f"{x:g},{y:g}"] = mesh_volume(difference(core, mesh))
    trimmed_missing: dict[str, float] = {}
    for x, y in config.portal_trimmed_support_centers:
        core = cylinder_at(x, y, 1.85, 2.76, z0=0.04, sections=48)
        trimmed_missing[f"{x:g},{y:g}"] = mesh_volume(difference(core, mesh))
    return {
        "total_safe_non_clutch_supports": len(support_centers(config)),
        "full_round_support_count": len(full),
        "portal_trimmed_support_count": len(config.portal_trimmed_support_centers),
        "nominal_full_support_diameter_mm": SUPPORT_DIAMETER,
        "nominal_support_height_mm": SUPPORT_HEIGHT,
        "dense_full_core_missing_volume_mm3_by_center": missing,
        "dense_trimmed_core_missing_volume_mm3_by_center": trimmed_missing,
        "all_full_support_cores_solid": max(missing.values(), default=0.0) <= BOOLEAN_TOLERANCE_MM3,
        "all_trimmed_support_cores_solid": max(trimmed_missing.values(), default=0.0) <= BOOLEAN_TOLERANCE_MM3,
    }


def validate_anchors_and_lego(config: ModuleConfig, mesh: trimesh.Trimesh) -> tuple[dict[str, object], dict[str, object]]:
    bore_intersections: dict[str, float] = {}
    notch_points: list[tuple[float, float, float]] = []
    anchor_material: list[tuple[float, float, float]] = []
    anchor_above: list[tuple[float, float, float]] = []
    for (x, y), (dx, dy) in zip(config.clutch_centers, config.split_directions):
        bore = cylinder_at(x, y, 1.90, 1.80, z0=0.64, sections=48)
        bore_intersections[f"{x:g},{y:g}"] = mesh_volume(intersection(mesh, bore))
        px, py = -dy, dx
        for radius in (0.0, 0.65, 1.30, 2.30):
            for z in (0.06, 0.30, 0.56):
                notch_points.append((x + dx * radius, y + dy * radius, z))
        for mx, my in (
            (x - dx * 1.55, y - dy * 1.55),
            (x + px * 1.65, y + py * 1.65),
            (x - px * 1.65, y - py * 1.65),
        ):
            for z in (0.06, 0.30, 0.56):
                anchor_material.append((mx, my, z))
            anchor_above.append((mx, my, 0.62))
    anchor_checks = {
        "coupon_f_bore_count": len(config.clutch_centers),
        "c_anchor_count": len(config.clutch_centers),
        "upper_bore_intersection_volume_mm3_by_center": bore_intersections,
        "all_upper_coupon_f_bores_open": max(bore_intersections.values(), default=0.0) <= BOOLEAN_TOLERANCE_MM3,
        "all_c_anchor_notches_open": all_points_outside(mesh, notch_points),
        "all_c_anchor_material_present_through_z_0p56": all_points_inside(mesh, anchor_material),
        "c_anchor_material_ends_before_z_0p62": all_points_outside(mesh, anchor_above),
        "anchor_height_mm": ANCHOR_HEIGHT,
    }

    # Some retained body seating locations in the compact vertical cradle lie
    # exactly on the body perimeter and are intentionally edge-open rather than
    # full circular underside cavities.  Validate their complete centerlines at
    # three heights, matching the established package definition, then use the
    # removal-only delta proof to establish that none became more obstructed.
    lego_points = dense_open_points(
        config.stud_centers,
        (0.12, 1.20, 2.35),
        radii=(0.0,),
    )
    continuation_centers: tuple[tuple[float, float], ...] = ()
    if config.mount_mode == "open_tabs":
        assert config.tab_centers_x is not None
        continuation_centers = tuple(
            (center_x + offset, 0.0)
            for center_x in config.tab_centers_x
            for offset in (-4.0, 4.0)
        )
    continuation_points = dense_open_points(continuation_centers, (0.12, 1.20, 2.35))
    lego_checks = {
        "body_lego_seating_point_count": len(config.stud_centers),
        "body_seating_centerlines_open_at_three_heights": all_points_outside(mesh, lego_points),
        "open_tab_continuation_seating_point_count": len(continuation_centers),
        "dense_continuation_seating_samples_open": all_points_outside(mesh, continuation_points) if continuation_points else True,
    }
    return anchor_checks, lego_checks


def validate_cardboard(config: ModuleConfig, mesh: trimesh.Trimesh) -> dict[str, object]:
    path_height = config.tab_height - 0.10 if config.mount_mode == "open_tabs" else 7.90
    path_z0 = 0.05
    inset_paths = [
        capsule_y(x, y, 3.56, 1.76, path_height - path_z0, path_z0, sections=48)
        for x, y in config.path_centers
    ]
    intersections = {
        f"{x:g},{y:g}": mesh_volume(intersection(mesh, cutter))
        for (x, y), cutter in zip(config.path_centers, inset_paths)
    }
    checks: dict[str, object] = {
        "path_count": 2,
        "path_centers_mm": [[x, y] for x, y in config.path_centers],
        "capsule_overall_length_mm": PATH_OVERALL,
        "capsule_width_mm": PATH_WIDTH,
        "inset_path_intersection_volume_mm3_by_center": intersections,
        "both_3p60x1p80_paths_open": max(intersections.values(), default=0.0) <= BOOLEAN_TOLERANCE_MM3,
        "included_coupon": "PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl",
        "recommended_coupon_row": "3.6 mm row",
    }
    if config.mount_mode == "internal_paths":
        head_intersections: dict[str, float] = {}
        for x, y in config.path_centers:
            pocket = cylinder_at(x, y, 4.15, 2.90, z0=5.05, sections=64)
            head_intersections[f"{x:g},{y:g}"] = mesh_volume(intersection(mesh, pocket))
        floor_points = [
            (x + dx, y + dy, 4.90)
            for x, y in config.path_centers
            for dx, dy in ((3.0, 0.0), (-3.0, 0.0), (0.0, 3.0), (0.0, -3.0))
        ]
        checks.update(
            {
                "mount_type": "two compact top-open internal paths",
                "head_pocket_diameter_mm": 8.50,
                "head_pocket_z_mm": [5.0, 8.0],
                "head_pocket_intersection_volume_mm3_by_center": head_intersections,
                "both_head_pockets_open": max(head_intersections.values(), default=0.0) <= BOOLEAN_TOLERANCE_MM3,
                "solid_floor_retained_around_both_paths": all_points_inside(mesh, floor_points),
            }
        )
    else:
        assert config.tab_centers_x is not None and config.body_edges_x is not None
        open_points = [
            (x, y, z)
            for center_x, edge_x in zip(config.tab_centers_x, config.body_edges_x)
            for x in (
                edge_x - math.copysign(1.0, edge_x),
                edge_x,
                edge_x + math.copysign(1.0, edge_x),
                center_x - math.copysign(4.0, center_x),
                center_x + math.copysign(4.0, center_x),
            )
            for y in (-2.4, 0.0, 2.4)
            for z in (0.15, 1.30, 2.55)
        ]
        recesses = [
            cylinder_at(center_x, 0.0, 4.45, 1.10, z0=8.34, sections=64)
            for center_x in config.tab_centers_x
        ]
        recess_intersections = {
            f"{center_x:g},0": mesh_volume(intersection(mesh, recess))
            for center_x, recess in zip(config.tab_centers_x, recesses)
        }
        checks.update(
            {
                "mount_type": "two open brick-style X-end tabs",
                "tab_body_mm": [17.0, 10.0, config.tab_height],
                "tab_underside_cavity_mm": [16.0, 6.40, 2.72],
                "body_portal_mm": [4.0, 6.40, 2.72],
                "head_recess_diameter_depth_mm": [9.10, 1.22],
                "dense_tab_cavity_and_portal_samples_open": all_points_outside(mesh, open_points),
                "head_recess_intersection_volume_mm3_by_center": recess_intersections,
                "both_head_recesses_open": max(recess_intersections.values(), default=0.0) <= BOOLEAN_TOLERANCE_MM3,
            }
        )
    return checks


def validate_delta(
    config: ModuleConfig,
    source: trimesh.Trimesh,
    mesh: trimesh.Trimesh,
    cutters: list[trimesh.Trimesh],
) -> dict[str, object]:
    cutter_union = as_mesh(trimesh.boolean.union(cutters, engine="manifold"))
    expected = source.copy()
    for cutter in cutters:
        expected = difference(expected, cutter)
    added = difference(mesh, source)
    removed = difference(source, mesh)
    removed_outside = difference(removed, cutter_union)
    expected_minus_output = difference(expected, mesh)
    output_minus_expected = difference(mesh, expected)
    individual = [mesh_volume(intersection(removed, cutter)) for cutter in cutters]
    source_bounds = np.asarray(source.bounds)
    output_bounds = np.asarray(mesh.bounds)
    removed_bounds = (
        [[round(float(value), 5) for value in row] for row in removed.bounds]
        if len(removed.faces)
        else []
    )
    return {
        "operation": "subtract only two 3.60 x 1.80 mm capsule cutters from the exact prior packaged STL",
        "no_transform_applied": True,
        "source_coordinate_frame_retained": True,
        "source_sha256": sha256(config.source_stl),
        "output_sha256": sha256(config.output_stl),
        "source_volume_mm3": round(mesh_volume(source), 6),
        "output_volume_mm3": round(mesh_volume(mesh), 6),
        "removed_volume_mm3": round(mesh_volume(removed), 6),
        "individual_path_removed_volume_mm3": [round(value, 6) for value in individual],
        "removed_bounds_mm": removed_bounds,
        "added_volume_mm3": mesh_volume(added),
        "removed_outside_two_path_cutters_volume_mm3": mesh_volume(removed_outside),
        "expected_minus_output_volume_mm3": mesh_volume(expected_minus_output),
        "output_minus_expected_volume_mm3": mesh_volume(output_minus_expected),
        "unchanged_extents": bool(np.allclose(source_bounds, output_bounds, atol=0.00001, rtol=0.0)),
        "removal_only": mesh_volume(added) <= BOOLEAN_TOLERANCE_MM3,
        "delta_localized_to_two_paths": mesh_volume(removed_outside) <= BOOLEAN_TOLERANCE_MM3,
        "both_paths_remove_material": all(value > 0.10 for value in individual),
        "exact_boolean_result_after_stl_reload": (
            mesh_volume(expected_minus_output) <= BOOLEAN_TOLERANCE_MM3
            and mesh_volume(output_minus_expected) <= BOOLEAN_TOLERANCE_MM3
        ),
        "all_geometry_outside_path_cutters_unchanged_at_every_z": mesh_volume(removed_outside) <= BOOLEAN_TOLERANCE_MM3,
    }


def mechanism_clearance_points(config: ModuleConfig) -> list[tuple[float, float, float]]:
    if config.preview_kind == "vertical":
        return [(x, 0.0, z) for x in (-13.75, 13.75) for z in (19.5, 22.0, 24.5)]
    points = [(x, 5.0, z) for x in (-17.5, 17.5) for z in (15.5, 18.0, 20.0)]
    if config.key == "servo_latch_v1_3":
        points.extend((x, -19.0, z) for x in (5.0, 10.0, 16.0) for z in (10.0, 14.0, 18.0))
    if config.key == "servo_door_v1_3":
        points.extend((30.0, y, 16.0) for y in (-24.0, -21.5, -10.0, 9.5, 12.0))
    return points


def validate(
    config: ModuleConfig,
    source: trimesh.Trimesh,
    mesh: trimesh.Trimesh,
    cutters: list[trimesh.Trimesh],
    asset_records: dict[str, dict[str, object]],
) -> dict[str, object]:
    source_zip_exact, source_member = source_zip_stl_is_exact(config)
    prior_validation_path = config.source_dir / "MESH_AND_CLEARANCE_VALIDATION.json"
    prior_validation = json.loads(prior_validation_path.read_text(encoding="utf-8"))
    topology = topology_checks(mesh)
    delta = validate_delta(config, source, mesh, cutters)
    supports = validate_supports(config, mesh)
    anchors, lego = validate_anchors_and_lego(config, mesh)
    cardboard = validate_cardboard(config, mesh)
    mechanism_open = all_points_outside(mesh, mechanism_clearance_points(config))
    mechanism = {
        "mechanism_hardware_clearance_samples_open": mechanism_open,
        "all_non_path_geometry_preserved_by_removal_only_delta": delta[
            "all_geometry_outside_path_cutters_unchanged_at_every_z"
        ],
        "preserved_features": list(config.preserved_features),
        "M3_features": "N/A",
        "LED_features": "N/A",
    }
    inputs = {
        "exact_prior_loose_stl": str(config.source_stl),
        "prior_package": str(config.source_zip),
        "prior_package_stl_member": source_member,
        "loose_stl_is_byte_exact_copy_of_prior_package_member": source_zip_exact,
        "prior_validation_sha256": sha256(prior_validation_path),
        "prior_validation_all_required_checks_pass": bool(prior_validation.get("all_required_checks_pass")),
    }
    packaging = {
        "zip_crc_ok": False,
        "zip_has_no_duplicate_entries": False,
        "zip_has_exact_archive_root": False,
        "zip_files_match_local_bytes": False,
        "zip_source_script_matches_builder_bytes": False,
    }
    geometric_pass = bool(
        topology["watertight"]
        and topology["winding_consistent"]
        and topology["connected_components"] == 1
        and topology["every_edge_has_two_incident_faces"]
        and topology["no_degenerate_faces"]
        and topology["no_duplicate_faces"]
        and inputs["loose_stl_is_byte_exact_copy_of_prior_package_member"]
        and inputs["prior_validation_all_required_checks_pass"]
        and delta["unchanged_extents"]
        and delta["removal_only"]
        and delta["delta_localized_to_two_paths"]
        and delta["both_paths_remove_material"]
        and delta["exact_boolean_result_after_stl_reload"]
        and supports["all_full_support_cores_solid"]
        and supports["all_trimmed_support_cores_solid"]
        and anchors["all_upper_coupon_f_bores_open"]
        and anchors["all_c_anchor_notches_open"]
        and anchors["all_c_anchor_material_present_through_z_0p56"]
        and anchors["c_anchor_material_ends_before_z_0p62"]
        and lego["body_seating_centerlines_open_at_three_heights"]
        and lego["dense_continuation_seating_samples_open"]
        and cardboard["both_3p60x1p80_paths_open"]
        and cardboard.get("both_head_pockets_open", True)
        and cardboard.get("solid_floor_retained_around_both_paths", True)
        and cardboard.get("dense_tab_cavity_and_portal_samples_open", True)
        and cardboard.get("both_head_recesses_open", True)
        and mechanism_open
        and all(record["byte_exact"] for record in asset_records.values())
    )
    return {
        "module": config.title,
        "version": config.version,
        "prior_version": config.prior_version,
        "status": "PASS" if geometric_pass else "FAIL",
        "inputs": inputs,
        "topology": topology,
        "removal_only_delta": delta,
        "supportless_underside": supports,
        "coupon_f_and_c_anchors": anchors,
        "lego_seating": lego,
        "cardboard_mount": cardboard,
        "mechanism_integrity": mechanism,
        "accessories": asset_records,
        "packaging": packaging,
        "geometric_checks_pass": geometric_pass,
        "all_required_checks_pass": False,
        "physical_pilot_required": True,
    }


def write_source_manifest(config: ModuleConfig, checks: dict[str, object]) -> None:
    manifest = {
        "revision": f"{config.title} {config.version}",
        "source": checks["inputs"],
        "operation": checks["removal_only_delta"]["operation"],
        "path_centers_mm": checks["cardboard_mount"]["path_centers_mm"],
        "path_dimensions_mm": [PATH_OVERALL, PATH_WIDTH],
        "accessory_source_hashes": {
            name: record["source_sha256"] for name, record in checks["accessories"].items()
        },
    }
    (config.output_dir / "SOURCE_INPUT_MANIFEST.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )


def write_readme(config: ModuleConfig, checks: dict[str, object]) -> None:
    support = checks["supportless_underside"]
    feature_lines = "\n".join(f"- {item}" for item in config.preserved_features)
    centers = ", ".join(f"({x:g}, {y:g})" for x, y in config.path_centers)
    if config.mount_mode == "internal_paths":
        mount = (
            "The two compact internal paths retain their 8.50 mm top-open head pockets "
            "from Z=5.00 to Z=8.00 and their solid floors outside the narrow slit."
        )
    else:
        mount = (
            "The two X-end tabs retain their 17 x 10 x 9.50 mm bodies, 16 x 6.40 x "
            "2.72 mm underside cavities, 4 x 6.40 x 2.72 mm body portals, and 9.10 mm "
            "top head recesses."
        )
    trimmed = (
        f" Two edge supports remain intentionally portal-trimmed, with solid center cores."
        if config.portal_trimmed_support_centers
        else ""
    )
    text = f"""# {config.title} {config.version}

This is a narrow cardboard-fit revision of {config.prior_version}. It starts from the exact
STL stored in the preceding tested package and subtracts only the two cardboard paths.

## Change in this revision

- Both brass-fastener paths are now 3.60 mm overall x 1.80 mm wide capsules.
- Path centers remain exactly {centers} mm.
- No transform, support addition, mechanism edit, or accessory edit was applied.
- The exported STL was reloaded and compared geometrically with the prior STL. The
  removal-only delta is confined to the two path cutters, and the overall extents are unchanged.

## Supportless LEGO underside retained

- {support['total_safe_non_clutch_supports']} safe non-clutch roof supports at 5.20 mm diameter x 2.85 mm high.
- {support['full_round_support_count']} full-round supports and {support['portal_trimmed_support_count']} portal-trimmed supports.{trimmed}
- All {len(config.clutch_centers)} Coupon-F bores remain open.
- All {len(config.clutch_centers)} 0.60 mm C-shaped first-layer anchors remain present and notch-aligned.
- All {len(config.stud_centers)} body LEGO seating points remain open.

## Cardboard mounting

{mount}

The included coupon contains 3.2, 3.4, and 3.6 mm rows. Start with the **3.6 mm row**
because this module is fixed at 3.60 x 1.80 mm. Use the coupon to confirm the chosen
printer/material combination before making a class set.

## Preserved mechanism and accessories

{feature_lines}

Every supplied strap, panel, link, flap, guide, and coupon is copied byte-for-byte from
the preceding package. M3-specific and LED-specific checks are not applicable to these
five servo mechanisms.

## Printing

- PLA, 0.4 mm nozzle, 0.20 mm Standard profile
- LEGO underside flat on the build plate
- Supports off; raft off
- Print moving accessories in their documented flat orientation

## Pilot status

{config.pilot_note}

The mesh and package checks pass digitally, but a physical fit and motion pilot is still required.
"""
    (config.output_dir / "README_FIRST.md").write_text(text, encoding="utf-8")


def write_dimensions(config: ModuleConfig, mesh: trimesh.Trimesh) -> None:
    rows = [
        ("Feature", "Value"),
        ("Module", f"{config.title} {config.version}"),
        ("Prior exact packaged STL", config.source_stl_name),
        ("LEGO footprint", config.footprint),
        ("Overall mesh extents", " x ".join(f"{value:.2f}" for value in mesh.extents) + " mm"),
        ("Cardboard path count", "2"),
        ("Cardboard path centers", "; ".join(f"({x:g}, {y:g}) mm" for x, y in config.path_centers)),
        ("Brass-fastener slit", "3.60 overall x 1.80 mm capsule"),
        ("Coupon recommendation", "Start with included 3.6 mm row"),
        ("Safe non-clutch roof supports", str(len(support_centers(config)))),
        (
            "Full-round / portal-trimmed supports",
            f"{len(support_centers(config)) - len(config.portal_trimmed_support_centers)} / {len(config.portal_trimmed_support_centers)}",
        ),
        ("Full support diameter x height", "5.20 x 2.85 mm"),
        ("Coupon-F clutch bores", f"{len(config.clutch_centers)} open"),
        ("C anchor feet", f"{len(config.clutch_centers)} retained at 0.60 mm high"),
        ("Body LEGO seating points", f"{len(config.stud_centers)} open"),
        ("M3 geometry", "N/A"),
        ("LED geometry", "N/A"),
    ]
    if config.mount_mode == "internal_paths":
        rows.extend(
            [
                ("Cardboard mount", "Two compact top-open internal paths"),
                ("Head pockets", "8.50 mm diameter, top-open from Z=5.00 to Z=8.00"),
                ("Pocket floor", "Solid outside slit from cavity roof to Z=5.00"),
            ]
        )
    else:
        rows.extend(
            [
                ("Cardboard mount", "Two open X-end brick tabs"),
                ("Tab body", "17 x 10 x 9.50 mm"),
                ("Tab underside cavity", "16 x 6.40 x 2.72 mm"),
                ("Tab body portal", "4 x 6.40 x 2.72 mm"),
                ("Head recess", "9.10 mm diameter x 1.22 mm deep"),
                ("Continuation LEGO seating points", "4 open"),
            ]
        )
    with (config.output_dir / f"{config.file_prefix}_Dimensions.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        csv.writer(handle).writerows(rows)


def write_validation(config: ModuleConfig, checks: dict[str, object]) -> None:
    (config.output_dir / "MESH_AND_CLEARANCE_VALIDATION.json").write_text(
        json.dumps(checks, indent=2) + "\n", encoding="utf-8"
    )
    top = checks["topology"]
    delta = checks["removal_only_delta"]
    support = checks["supportless_underside"]
    anchors = checks["coupon_f_and_c_anchors"]
    lego = checks["lego_seating"]
    cardboard = checks["cardboard_mount"]
    packaging = checks["packaging"]
    lines = [
        f"# {config.title} {config.version} validation",
        "",
        f"- Overall verdict: `{checks['status']}`",
        f"- Watertight / winding / one component: `{top['watertight']}` / `{top['winding_consistent']}` / `{top['connected_components'] == 1}`",
        f"- Every edge has two incident faces: `{top['every_edge_has_two_incident_faces']}`",
        f"- No degenerate or duplicate faces: `{top['no_degenerate_faces']}` / `{top['no_duplicate_faces']}`",
        f"- Prior loose STL equals prior ZIP member byte-for-byte: `{checks['inputs']['loose_stl_is_byte_exact_copy_of_prior_package_member']}`",
        f"- Removal only and confined to the two paths: `{delta['removal_only']}` / `{delta['delta_localized_to_two_paths']}`",
        f"- Exact expected boolean result after STL reload: `{delta['exact_boolean_result_after_stl_reload']}`",
        f"- Extents unchanged: `{delta['unchanged_extents']}`",
        f"- Full / trimmed solid support cores: `{support['all_full_support_cores_solid']}` / `{support['all_trimmed_support_cores_solid']}`",
        f"- {anchors['coupon_f_bore_count']} Coupon-F bores open; {anchors['c_anchor_count']} C anchors retained: `{anchors['all_upper_coupon_f_bores_open']}` / `{anchors['all_c_anchor_material_present_through_z_0p56']}`",
        f"- C-anchor notches open: `{anchors['all_c_anchor_notches_open']}`",
        f"- LEGO seating centerlines open at three heights: `{lego['body_seating_centerlines_open_at_three_heights']}`",
        f"- Both 3.60 x 1.80 paths open: `{cardboard['both_3p60x1p80_paths_open']}`",
        f"- Mechanism clearances open and all non-path geometry preserved: `{checks['mechanism_integrity']['mechanism_hardware_clearance_samples_open']}` / `{checks['mechanism_integrity']['all_non_path_geometry_preserved_by_removal_only_delta']}`",
        f"- ZIP CRC / no duplicates / byte-exact files / exact source: `{packaging['zip_crc_ok']}` / `{packaging['zip_has_no_duplicate_entries']}` / `{packaging['zip_files_match_local_bytes']}` / `{packaging['zip_source_script_matches_builder_bytes']}`",
        f"- All required checks pass: `{checks['all_required_checks_pass']}`",
        "",
        "A physical print, cardboard fit, LEGO clutch, servo fit, and full motion pilot remain required.",
        "",
    ]
    (config.output_dir / "MESH_AND_CLEARANCE_VALIDATION.md").write_text(
        "\n".join(lines), encoding="utf-8"
    )


def font(size: int, bold: bool = False) -> ImageFont.ImageFont:
    name = "arialbd.ttf" if bold else "arial.ttf"
    path = Path(r"C:\Windows\Fonts") / name
    return ImageFont.truetype(str(path), size) if path.exists() else ImageFont.load_default()


def render_isometric(
    specs: list[tuple[trimesh.Trimesh, tuple[int, int, int]]],
    path: Path,
    title: str,
    footer: str,
    view: tuple[float, float, float] = (1.0, -1.35, 0.90),
    overlay_count: int = 0,
) -> None:
    view_vector = np.asarray(view, dtype=float)
    view_vector /= np.linalg.norm(view_vector)
    right = np.cross(view_vector, np.array([0.0, 0.0, 1.0]))
    right /= np.linalg.norm(right)
    up = np.cross(right, view_vector)
    up /= np.linalg.norm(up)
    light = np.array([0.30, -0.45, 0.84])
    light /= np.linalg.norm(light)
    normal_triangles: list[tuple[float, np.ndarray, tuple[int, int, int]]] = []
    overlays: list[tuple[float, np.ndarray, tuple[int, int, int]]] = []
    projected_all: list[np.ndarray] = []
    overlay_start = len(specs) - overlay_count
    for index, (mesh, color) in enumerate(specs):
        if len(mesh.faces) == 0:
            continue
        tri3 = mesh.vertices[mesh.faces]
        normals = np.cross(tri3[:, 1] - tri3[:, 0], tri3[:, 2] - tri3[:, 0])
        lengths = np.linalg.norm(normals, axis=1)
        valid = lengths > 1e-9
        normals[valid] /= lengths[valid, None]
        facing = normals @ view_vector > -0.10
        for triangle, normal in zip(tri3[facing], normals[facing]):
            projected = np.column_stack((triangle @ right, -(triangle @ up)))
            depth = float(np.mean(triangle @ view_vector))
            shade = 0.70 + 0.30 * max(0.0, float(normal @ light))
            shaded = tuple(max(0, min(255, int(channel * shade))) for channel in color)
            target = overlays if overlay_count and index >= overlay_start else normal_triangles
            target.append((depth, projected, shaded))
            projected_all.append(projected)
    all_points = np.vstack(projected_all)
    low = all_points.min(axis=0)
    high = all_points.max(axis=0)
    canvas = (1500, 1000)
    margin = 115
    scale = min(
        (canvas[0] - 2 * margin) / max(1e-9, high[0] - low[0]),
        (canvas[1] - 2 * margin - 105) / max(1e-9, high[1] - low[1]),
    )
    offset = np.array(
        [
            (canvas[0] - (high[0] - low[0]) * scale) / 2 - low[0] * scale,
            105 + (canvas[1] - 190 - (high[1] - low[1]) * scale) / 2 - low[1] * scale,
        ]
    )
    image = Image.new("RGB", canvas, (247, 249, 252))
    draw = ImageDraw.Draw(image)
    for collection in (normal_triangles, overlays):
        for _, projected, color in sorted(collection, key=lambda item: item[0]):
            points = [(float(x * scale + offset[0]), float(y * scale + offset[1])) for x, y in projected]
            draw.polygon(points, fill=color)
    draw.rounded_rectangle((28, 20, 1472, 78), radius=14, fill=(255, 255, 255), outline=(210, 216, 224), width=2)
    draw.text((52, 31), title, fill=(28, 38, 52), font=font(27, bold=True))
    draw.rounded_rectangle((28, 933, 1472, 982), radius=12, fill=(255, 255, 255), outline=(210, 216, 224), width=2)
    draw.text((52, 945), footer, fill=(34, 48, 64), font=font(20))
    image.save(path)


def assembly_reference(config: ModuleConfig) -> trimesh.Trimesh:
    if config.preview_kind == "vertical":
        servo = trimesh.creation.box(extents=[23.0, 12.4, 22.7])
        servo.apply_translation([0.0, 0.0, 19.35])
        return servo
    servo = trimesh.creation.box(extents=[23.0, 22.7, 12.4])
    servo.apply_translation([0.0, 0.0, 14.20])
    return servo


def render_previews(config: ModuleConfig, mesh: trimesh.Trimesh) -> None:
    reference = assembly_reference(config)
    render_isometric(
        [(mesh, (177, 186, 197)), (reference, (48, 125, 96))],
        config.output_dir / f"{config.file_prefix}_Assembly_Preview.png",
        f"{config.title.upper()} {config.version} — 3.60 x 1.80 mm PATHS",
        "Exact revised base with SG90 fit reference; print support-free with LEGO underside down.",
    )
    render_isometric(
        [(mesh, (177, 186, 197))],
        config.output_dir / f"{config.file_prefix}_Top_Preview.png",
        f"{config.title.upper()} {config.version} — TOP / MECHANISM VIEW",
        "Only the two cardboard capsules changed; mechanism and accessory geometry is retained.",
        view=(0.60, -0.95, 1.80),
    )
    support_zones = trimesh.util.concatenate(
        [cylinder_at(x, y, 2.62, 2.85, z0=0.0, sections=48) for x, y in support_centers(config)]
    )
    anchor_zones = trimesh.util.concatenate(
        [cylinder_at(x, y, 3.04, 0.60, z0=0.0, sections=48) for x, y in config.clutch_centers]
    )
    support_overlay = intersection(mesh, support_zones)
    anchor_overlay = intersection(mesh, anchor_zones)
    rotation = trimesh.transformations.rotation_matrix(math.pi, [1.0, 0.0, 0.0])
    underside = mesh.copy()
    underside.apply_transform(rotation)
    support_overlay.apply_transform(rotation)
    anchor_overlay.apply_transform(rotation)
    support_overlay.apply_translation([0.0, 0.0, 0.025])
    anchor_overlay.apply_translation([0.0, 0.0, 0.045])
    render_isometric(
        [
            (underside, (177, 186, 197)),
            (support_overlay, (79, 151, 101)),
            (anchor_overlay, (55, 112, 170)),
        ],
        config.output_dir / f"{config.file_prefix}_Underside_Preview.png",
        f"{config.title.upper()} {config.version} — VERIFIED UNDERSIDE",
        "Green = retained solid supports; blue = retained Coupon-F / C-anchor regions.",
        overlay_count=2,
    )


def local_package_files(config: ModuleConfig) -> list[str]:
    return [
        "README_FIRST.md",
        config.output_stl_name,
        *config.accessories,
        f"{config.file_prefix}_Dimensions.csv",
        "SOURCE_INPUT_MANIFEST.json",
        "MESH_AND_CLEARANCE_VALIDATION.md",
        "MESH_AND_CLEARANCE_VALIDATION.json",
        f"{config.file_prefix}_Assembly_Preview.png",
        f"{config.file_prefix}_Top_Preview.png",
        f"{config.file_prefix}_Underside_Preview.png",
    ]


def create_package(config: ModuleConfig) -> None:
    with zipfile.ZipFile(config.output_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in local_package_files(config):
            archive.write(config.output_dir / name, f"{config.archive_prefix}/{name}")
        archive.write(Path(__file__), f"{config.archive_prefix}/SOURCE/{Path(__file__).name}")


def verify_package(config: ModuleConfig) -> dict[str, object]:
    expected_local = local_package_files(config)
    expected_names = [f"{config.archive_prefix}/{name}" for name in expected_local]
    source_member = f"{config.archive_prefix}/SOURCE/{Path(__file__).name}"
    expected_names.append(source_member)
    with zipfile.ZipFile(config.output_zip) as archive:
        names = archive.namelist()
        crc_ok = archive.testzip() is None
        exact_files = all(
            archive.read(f"{config.archive_prefix}/{name}") == (config.output_dir / name).read_bytes()
            for name in expected_local
        )
        source_exact = archive.read(source_member) == Path(__file__).read_bytes()
    return {
        "zip_crc_ok": crc_ok,
        "zip_has_no_duplicate_entries": len(names) == len(set(names)),
        "zip_has_exact_archive_root": set(names) == set(expected_names) and all(
            name.startswith(f"{config.archive_prefix}/") for name in names
        ),
        "zip_files_match_local_bytes": exact_files,
        "zip_source_script_matches_builder_bytes": source_exact,
        "zip_entry_count": len(names),
        "zip_sha256": sha256(config.output_zip),
    }


def package_checks_pass(packaging: dict[str, object]) -> bool:
    return bool(
        packaging["zip_crc_ok"]
        and packaging["zip_has_no_duplicate_entries"]
        and packaging["zip_has_exact_archive_root"]
        and packaging["zip_files_match_local_bytes"]
        and packaging["zip_source_script_matches_builder_bytes"]
    )


def validation_package_record(packaging: dict[str, object]) -> dict[str, object]:
    # A ZIP cannot truthfully contain its own final SHA-256 because recording
    # that digest changes the archive.  Keep the archive digest in the external
    # build summary and store only stable, independently repeatable checks in
    # the validation file that is itself packaged.
    return {key: value for key, value in packaging.items() if key != "zip_sha256"}


def main() -> None:
    summaries: list[dict[str, object]] = []
    for config in CONFIGS:
        print(f"Building {config.title} {config.version} from exact {config.prior_version} STL...")
        config.output_dir.mkdir(parents=True, exist_ok=True)
        asset_records = copy_assets(config)
        source, mesh, cutters = build_mesh(config)
        checks = validate(config, source, mesh, cutters, asset_records)
        write_source_manifest(config, checks)
        write_readme(config, checks)
        write_dimensions(config, mesh)
        render_previews(config, mesh)

        write_validation(config, checks)
        create_package(config)
        first_package = verify_package(config)
        checks["packaging"] = validation_package_record(first_package)
        checks["all_required_checks_pass"] = bool(
            checks["geometric_checks_pass"] and package_checks_pass(first_package)
        )
        checks["status"] = "PASS" if checks["all_required_checks_pass"] else "FAIL"
        write_validation(config, checks)
        create_package(config)
        final_package = verify_package(config)
        if not package_checks_pass(final_package):
            raise RuntimeError(f"Final package verification failed for {config.key}: {final_package}")
        checks["packaging"] = validation_package_record(final_package)
        checks["all_required_checks_pass"] = bool(
            checks["geometric_checks_pass"] and package_checks_pass(final_package)
        )
        checks["status"] = "PASS" if checks["all_required_checks_pass"] else "FAIL"
        if not checks["all_required_checks_pass"]:
            write_validation(config, checks)
            raise RuntimeError(f"Required validation failed for {config.key}")

        summaries.append(
            {
                "key": config.key,
                "status": checks["status"],
                "output_stl": str(config.output_stl),
                "output_zip": str(config.output_zip),
                "stl_sha256": sha256(config.output_stl),
                "zip_sha256": sha256(config.output_zip),
                "removed_volume_mm3": checks["removal_only_delta"]["removed_volume_mm3"],
                "support_count": checks["supportless_underside"]["total_safe_non_clutch_supports"],
                "coupon_f_bore_count": checks["coupon_f_and_c_anchors"]["coupon_f_bore_count"],
            }
        )
        print(
            f"PASS {config.key}: removed={checks['removal_only_delta']['removed_volume_mm3']} mm^3; "
            f"supports={checks['supportless_underside']['total_safe_non_clutch_supports']}; "
            f"anchors={checks['coupon_f_and_c_anchors']['c_anchor_count']}"
        )

    (OUTPUT_ROOT / "BUILD_SUMMARY.json").write_text(
        json.dumps({"all_pass": True, "modules": summaries}, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"All five packages passed. Summary: {OUTPUT_ROOT / 'BUILD_SUMMARY.json'}")


if __name__ == "__main__":
    main()

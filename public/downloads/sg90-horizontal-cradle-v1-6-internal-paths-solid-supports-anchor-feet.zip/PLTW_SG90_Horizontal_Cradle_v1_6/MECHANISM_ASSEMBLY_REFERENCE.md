# Preserved mechanism assembly reference

This guide came from the last mechanism revision. The printable base in this package supersedes its underside and cardboard-mount geometry.

---

# SG90 horizontal LEGO cradle v1.3 - dual horn gap

This retains the successful original horizontal-cradle geometry. The low
horn-side locator now has two 8 mm gaps, one for each horn position when the
servo is rotated 180 degrees while keeping its label facing upward. The
original rear wire opening is restored.

## Installation

1. Place the servo on its side with the label facing upward.
2. Choose the orientation that gives the wire the straighter exit.
3. Align the horn/output shaft with either 8 mm gap in the same low rail.
4. Route the wire through the central opening between the rear blocks.
5. Install the retaining strap with two original servo mounting screws.
6. Tighten only until the servo cannot lift.

## Printing

- Bambu A1 mini
- PLA
- 0.20 mm Standard
- Four walls
- 20% gyroid
- Supports off
- LEGO underside on the build plate
- Strap flat on the build plate

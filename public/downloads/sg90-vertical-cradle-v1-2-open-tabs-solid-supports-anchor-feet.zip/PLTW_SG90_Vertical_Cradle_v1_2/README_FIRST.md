# SG90 Vertical Cradle v1.2

This revision responds to the physical potentiometer bridge failure by adding
solid roof support at every safe non-gripping underside tube while preserving
all compliant Coupon-F clutch bores. It also retains two open brick-style X-end tabs with continuous underside portals.

## Supportless underside

- 15 non-gripping tube centers are solid through the cavity roof.
- 2 edge supports are intentionally trimmed by the open tab portals; their centerlines remain solid.
- 13 supports remain full-round.
- All 6 Coupon-F clutch bores remain open.
- Every clutch ring gains a 0.60 mm C-shaped first-layer anchor pad.
- Each anchor notch follows the ring's existing split direction.
- All 28 surrounding LEGO seating points remain clear.
- Added roof-support geometry stops at Z = 2.85 mm and cannot enter the
  mechanism or fastener geometry above the base.

## Preserved mechanism geometry

- 12.5 mm body channel and 27.5 mm ear spacing
- 1.8 mm tower pilots and both lower wire portals
- upright horn sweep above the 25 mm towers

## Cardboard mounting

The retained mounting uses the classroom-selected 3.4 x 1.8 mm brass-fastener
slit. Open cavities or top-open pockets avoid hidden support material. Print
and test the included 3.2 / 3.4 / 3.6 mm coupon before a classroom batch.

## Printing

- Bambu A1 mini or comparable printer
- PLA, 0.4 mm nozzle
- Bambu 0.20 mm Standard profile
- LEGO underside on the build plate
- Supports off; raft off


## Pilot status

Servo fit is confirmed; pilot the open-tab and solid-support combination on the classroom plate and cardboard before quantities.

Inspect the cavity roof after printing. It should be carried by clean solid
columns with no loose bridge strands. Then verify full LEGO seating and removal,
cardboard seating, both brass fasteners, and the complete moving/electrical
assembly before classroom quantities.

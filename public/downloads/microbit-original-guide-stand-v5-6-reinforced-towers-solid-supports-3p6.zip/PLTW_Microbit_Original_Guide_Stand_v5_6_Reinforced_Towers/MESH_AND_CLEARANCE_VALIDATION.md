# PLTW micro:bit stand v5.6 validation

- Exact packaged v5.5 source: True
- Watertight / winding consistent: True / True
- Connected components: 1
- Extents preserved: True
- Source removal volume: 3.5e-08 mm^3
- Added reinforcement volume: 3625.698991 mm^3
- Exact guide / board collision: 0.0 / 0.0 mm^3
- Guide, board, and clip insertion keepouts clear: True
- High-shaft area at least 1.9x: True
- High-shaft inertias at least 3.5x: True
- Supportless added geometry: True
- 39 solid roof supports retained: True
- Six open Coupon-F bores and anchors retained: True
- All 60 LEGO clearances retained: True
- Both 3.6 x 1.8 paths/head pockets/floors retained: True
- Package embeds exact files: True
- All required checks pass: True

All mesh checks use the exact binary STL after export and reload.
A physical pilot remains required before classroom quantities.

# PLTW micro:bit Original-Guide Stand v5.5

This package starts from the exact current v5.4 STL and
changes the classroom brass-fastener capsule from 3.4 x 1.8 mm to
3.6 x 1.8 mm. Use the **3.6 mm row** of the included 3.2 / 3.4 / 3.6 mm coupon
before printing classroom quantities.

## What changed

- Both existing cardboard capsules are lengthened by 0.20 mm total: only
  0.10 mm of material is removed at each end; width stays 1.80 mm.
- Cardboard mount style remains two top-open internal paths.
- Source extents and all unrelated geometry are preserved.
- Actual brad-only removed volume: 2.070101 mm^3.
- M3-clearance removed volume: 0.000000 mm^3.
- Added solid-support volume: 914.650555 mm^3.

The exact-guide cradle and all upper stand geometry are retained. All 39 safe non-clutch centers become solid while six true clutch bores and their C anchors stay open.

## Retained standards

- Footprint: 6 x 10 studs / 48 x 80 mm nominal base
- Overall exported extents: 48.00 x 80.10 x 57.00 mm
- 39 full 5.20 mm-diameter x 2.85 mm safe roof supports
- 6 open Coupon-F bores with aligned 0.60 mm C anchors
- M3 hardware: N/A for this stand.
- LED pockets: N/A.

## micro:bit roof-support correction

All 39 non-clutch tube centers now receive full 5.20 mm-diameter x 2.85 mm
solid posts. The six true Coupon-F bores and their C anchors remain open. The
two widened internal paths remain top-open, all 60 LEGO stud clearances remain
open, and the exact-guide cradle and attributed guide STL are unchanged.

## Printing and assembly

- PLA, 0.4 mm nozzle, 0.20 mm Standard profile
- LEGO underside on the build plate
- Supports off; raft off
- Print and test the 3.6 mm coupon row first
- Confirm LEGO seating, removal, cardboard fit, both fasteners, and the complete
  electrical/mechanical assembly before classroom quantities

Automated checks use the exact STL after export and reload. They do not replace
a physical pilot with the classroom printer, plate, hardware, and cardboard.

from __future__ import annotations

import csv
import json
import math
import sys
import zipfile
from pathlib import Path


CAD_DEPS = Path(r"C:\Users\trira\.codex\tmp\cad_pydeps")
sys.path.insert(0, str(CAD_DEPS))

import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont


OUTPUT_DIR = Path(__file__).resolve().parent
IM_TESTBED = OUTPUT_DIR.parents[1]
FAMILY_DIR = (
    IM_TESTBED
    / "02_LATEST_NEEDS_TESTING"
    / "18_All_Modules_InternalBrad_3Dot_v0_1"
)
SOURCE_BASE = (
    FAMILY_DIR
    / "sources"
    / "potentiometer__PLTW_Potentiometer_v1_FFit_3Terminal_Control_Dial_Base.stl"
)
ORIGINAL_ZIP = (
    IM_TESTBED
    / "02_LATEST_NEEDS_TESTING"
    / "04_Potentiometer_v1"
    / "PLTW_Potentiometer_LEGO_Control_Dial_Module_v1.zip"
)
BRAD_COUPON = (
    FAMILY_DIR / "STL" / "PLTW_Brad_Slit_Fit_Coupon_3p2_3p4_3p6.stl"
)

OUTPUT_STL = OUTPUT_DIR / (
    "PLTW_Potentiometer_v1_3_FFit_DualMount_OpenBrickTabs_"
    "SolidRoofSupports_AnchoredCouponFFeet_3p4x1p8.stl"
)
OUTPUT_ZIP = OUTPUT_DIR / (
    "PLTW_Potentiometer_Control_Dial_v1_3_"
    "Solid_Roof_Supports_Anchor_Feet.zip"
)

TAB_HEIGHT = 9.50
CAVITY_HEIGHT = 2.72
ANCHOR_FOOT_RADIUS = 3.00
ANCHOR_FOOT_HEIGHT = 0.60
ANCHOR_NOTCH_WIDTH = 1.55
ANCHOR_NOTCH_LENGTH = 4.20
SUPPORT_POST_RADIUS = 2.60
SUPPORT_POST_HEIGHT = 2.85
TAB_CENTER_X = -4.0
TAB_CENTER_Y = 24.0

CLUTCH_CENTERS = {
    (-16.0, -8.0),
    (-16.0, 8.0),
    (16.0, -8.0),
    (16.0, 8.0),
}
TUBE_GRID = [
    (x, y)
    for x in (-16.0, -8.0, 0.0, 8.0, 16.0)
    for y in (-8.0, 0.0, 8.0)
]
NON_CLUTCH_TUBE_CENTERS = [
    pt for pt in TUBE_GRID if pt not in CLUTCH_CENTERS
]
STUD_CENTERS = [
    (x, y)
    for x in (-20.0, -12.0, -4.0, 4.0, 12.0, 20.0)
    for y in (-12.0, -4.0, 4.0, 12.0)
]
TERMINALS = {
    "GND": (11.0, -10.0),
    "SIG": (18.0, 0.0),
    "3V": (11.0, 10.0),
}

ORIGINAL_PREFIX = "PLTW_Potentiometer_LEGO_Control_Dial_Module_v1/"
ORIGINAL_ASSETS = {
    "P2p4_P3p2_ACTIVITY_GUIDE.md": "P2p4_P3p2_ACTIVITY_GUIDE.md",
    "PLTW_Potentiometer_v1_Combination_Dial_Knob_B5p9mm_DEFAULT.stl": (
        "PLTW_Potentiometer_v1_Combination_Dial_Knob_B5p9mm_DEFAULT.stl"
    ),
    "PLTW_Potentiometer_v1_Accessible_Wing_Knob_B5p9mm_DEFAULT.stl": (
        "PLTW_Potentiometer_v1_Accessible_Wing_Knob_B5p9mm_DEFAULT.stl"
    ),
    "PLTW_Potentiometer_v1_Bushing_Fit_Coupon_A7p4_B7p6_C7p8.stl": (
        "PLTW_Potentiometer_v1_Bushing_Fit_Coupon_A7p4_B7p6_C7p8.stl"
    ),
    "PLTW_Potentiometer_v1_Shaft_Fit_Coupon_A5p7_B5p9_C6p1.stl": (
        "PLTW_Potentiometer_v1_Shaft_Fit_Coupon_A5p7_B5p9_C6p1.stl"
    ),
    "PLTW_Potentiometer_v1_M3_Nut_Trap_Coupon.stl": (
        "PLTW_Potentiometer_v1_M3_Nut_Trap_Coupon.stl"
    ),
    "Reference_16mm_P160_WH148_Potentiometer_Not_For_Print.stl": (
        "Reference_16mm_P160_WH148_Potentiometer_Not_For_Print.stl"
    ),
}


def cylinder_at(
    x: float,
    y: float,
    radius: float,
    height: float,
    z0: float = 0.0,
    sections: int = 64,
) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(
        radius=radius,
        height=height,
        sections=sections,
    )
    mesh.apply_translation([x, y, z0 + height / 2.0])
    return mesh


def rounded_slot(center_y: float) -> trimesh.Trimesh:
    """Create the confirmed 3.4 x 1.8 mm capsule across a Y-end tab."""
    radius = 0.90
    straight = 1.60
    height = TAB_HEIGHT + 2.0

    middle = trimesh.creation.box(extents=[straight, 1.80, height])
    middle.apply_translation([TAB_CENTER_X, center_y, TAB_HEIGHT / 2.0])

    ends = []
    for x in (
        TAB_CENTER_X - straight / 2.0,
        TAB_CENTER_X + straight / 2.0,
    ):
        end = cylinder_at(
            x=x,
            y=center_y,
            radius=radius,
            height=height,
            z0=-1.0,
            sections=48,
        )
        ends.append(end)
    return trimesh.boolean.union([middle, *ends], engine="manifold")


def coupon_f_anchor_foot(x: float, y: float) -> trimesh.Trimesh:
    """Add the resistor-style C foot aligned to the pot's +Y split."""
    disk = cylinder_at(
        x,
        y,
        ANCHOR_FOOT_RADIUS,
        ANCHOR_FOOT_HEIGHT,
    )
    notch = trimesh.creation.box(
        extents=[
            ANCHOR_NOTCH_WIDTH,
            ANCHOR_NOTCH_LENGTH,
            ANCHOR_FOOT_HEIGHT + 0.40,
        ]
    )
    notch.apply_translation(
        [x, y + 2.0, ANCHOR_FOOT_HEIGHT / 2.0]
    )
    return trimesh.boolean.difference(
        [disk, notch],
        engine="manifold",
    )


def brick_anchor(sign: int) -> trimesh.Trimesh:
    """Open one-stud-wide, two-stud-long tab on a long side."""
    center_y = sign * TAB_CENTER_Y

    # X=-4 is an actual stud column on this even-width, six-stud body. The
    # seventeen-millimetre Y length clears continuation studs at Y=20/28.
    solid = trimesh.creation.box(extents=[10.0, 17.0, TAB_HEIGHT])
    solid.apply_translation(
        [TAB_CENTER_X, center_y, TAB_HEIGHT / 2.0]
    )

    # The cavity clears both continuation studs and overlaps the portal cut,
    # eliminating the hidden floor/partition found in the earlier edge tabs.
    cavity = trimesh.creation.box(
        extents=[6.40, 16.0, CAVITY_HEIGHT]
    )
    cavity.apply_translation(
        [TAB_CENTER_X, sign * 23.0, CAVITY_HEIGHT / 2.0]
    )

    recess = cylinder_at(
        x=TAB_CENTER_X,
        y=center_y,
        radius=4.55,
        height=1.22,
        z0=TAB_HEIGHT - 1.22,
    )

    return trimesh.boolean.difference(
        [solid, cavity, recess, rounded_slot(center_y)],
        engine="manifold",
    )


def build_base() -> trimesh.Trimesh:
    source = trimesh.load_mesh(SOURCE_BASE)

    # The physical v1.2 print showed that hollow non-gripping tube centers did
    # not reliably carry the large cavity roof. Fill those 11 safe
    # between-stud centers to the roof while keeping all four Coupon-F bores
    # open and compliant.
    support_posts = [
        cylinder_at(
            x,
            y,
            SUPPORT_POST_RADIUS,
            SUPPORT_POST_HEIGHT,
        )
        for x, y in NON_CLUTCH_TUBE_CENTERS
    ]

    # Add a 0.60 mm C-shaped first-layer pad to each Coupon-F clutch tube.
    # Each pad's notch follows the tube's existing +Y split.
    anchor_feet = [
        coupon_f_anchor_foot(x, y)
        for x, y in sorted(CLUTCH_CENTERS)
    ]

    combined = trimesh.boolean.union(
        [
            source,
            *support_posts,
            *anchor_feet,
            brick_anchor(-1),
            brick_anchor(1),
        ],
        engine="manifold",
    )

    # Open each tab cavity through the original long-side skirt and into the
    # main LEGO cavity. These cuts are well away from all +X nut-loading paths.
    portals = []
    for sign in (-1, 1):
        portal = trimesh.creation.box(
            extents=[6.40, 4.0, CAVITY_HEIGHT]
        )
        portal.apply_translation(
            [TAB_CENTER_X, sign * 16.0, CAVITY_HEIGHT / 2.0]
        )
        portals.append(portal)

    result = trimesh.boolean.difference(
        [combined, *portals],
        engine="manifold",
    )
    result.remove_unreferenced_vertices()
    result.export(OUTPUT_STL)
    return result


def extract_original_assets() -> None:
    with zipfile.ZipFile(ORIGINAL_ZIP, "r") as archive:
        for source_name, destination_name in ORIGINAL_ASSETS.items():
            data = archive.read(ORIGINAL_PREFIX + source_name)
            (OUTPUT_DIR / destination_name).write_bytes(data)

    (OUTPUT_DIR / BRAD_COUPON.name).write_bytes(BRAD_COUPON.read_bytes())


def contains_points(mesh: trimesh.Trimesh, points: list[tuple[float, float, float]]) -> list[bool]:
    return [bool(value) for value in mesh.contains(np.asarray(points))]


def validate(mesh: trimesh.Trimesh) -> dict[str, object]:
    components = len(mesh.split(only_watertight=False))
    clutch_bore_points = [
        (x, y, z)
        for x, y in CLUTCH_CENTERS
        for z in (0.05, 0.30, 0.59, 0.61, 1.40, 2.50)
    ]
    anchor_material_points = [
        (x, y - 1.50, 0.30)
        for x, y in CLUTCH_CENTERS
    ]
    anchor_notch_points = [
        (x, y + 1.50, 0.30)
        for x, y in CLUTCH_CENTERS
    ]
    solid_support_points = [
        (x, y, z)
        for x, y in NON_CLUTCH_TUBE_CENTERS
        for z in (0.05, 0.30, 1.40, 2.50, 2.80)
    ]
    stud_points = [(x, y, 1.40) for x, y in STUD_CENTERS]
    tab_stud_points = [
        (TAB_CENTER_X, y, 1.40)
        for y in (-28.0, -20.0, 20.0, 28.0)
    ]
    portal_points = [
        (TAB_CENTER_X, -16.0, 1.40),
        (TAB_CENTER_X, 16.0, 1.40),
    ]
    m3_nut_path_points = []
    for terminal_x, terminal_y in TERMINALS.values():
        for sample_x in np.linspace(terminal_x, 23.5, 5):
            m3_nut_path_points.append(
                (float(sample_x), terminal_y, 6.50)
            )
    slit_points = [
        (TAB_CENTER_X, y, z)
        for y in (-TAB_CENTER_Y, TAB_CENTER_Y)
        for z in (0.50, 4.75, 9.00)
    ]

    checks = {
        "watertight": bool(mesh.is_watertight),
        "winding_consistent": bool(mesh.is_winding_consistent),
        "components": components,
        "extents_mm": [round(float(v), 3) for v in mesh.extents],
        "bounds_mm": [
            [round(float(v), 3) for v in row]
            for row in mesh.bounds
        ],
        "faces": int(len(mesh.faces)),
        "anchor_feet_expected": len(CLUTCH_CENTERS),
        "anchor_foot_material_present": all(
            contains_points(mesh, anchor_material_points)
        ),
        "anchor_notches_open": not any(
            contains_points(mesh, anchor_notch_points)
        ),
        "all_4_coupon_f_bore_centers_open": not any(
            contains_points(mesh, clutch_bore_points)
        ),
        "all_11_non_clutch_roof_supports_solid": all(
            contains_points(mesh, solid_support_points)
        ),
        "all_24_body_stud_centers_open": not any(
            contains_points(mesh, stud_points)
        ),
        "four_tab_stud_centers_open": not any(
            contains_points(mesh, tab_stud_points)
        ),
        "tab_portals_open": not any(contains_points(mesh, portal_points)),
        "all_three_m3_nut_paths_open": not any(
            contains_points(mesh, m3_nut_path_points)
        ),
        "both_brad_slits_open_through_tab": not any(
            contains_points(mesh, slit_points)
        ),
        "panel_bushing_center_open": not any(
            contains_points(mesh, [(-13.0, 0.0, 25.0)])
        ),
        "nut_path_to_tab_nominal_gap_mm": 2.30,
        "tab_centers_mm": [
            [TAB_CENTER_X, -TAB_CENTER_Y],
            [TAB_CENTER_X, TAB_CENTER_Y],
        ],
        "brad_slit_mm": [3.4, 1.8],
    }

    required = (
        checks["watertight"]
        and checks["winding_consistent"]
        and components == 1
        and checks["anchor_foot_material_present"]
        and checks["anchor_notches_open"]
        and checks["all_4_coupon_f_bore_centers_open"]
        and checks["all_11_non_clutch_roof_supports_solid"]
        and checks["all_24_body_stud_centers_open"]
        and checks["four_tab_stud_centers_open"]
        and checks["tab_portals_open"]
        and checks["all_three_m3_nut_paths_open"]
        and checks["both_brad_slits_open_through_tab"]
        and checks["panel_bushing_center_open"]
    )
    checks["all_required_checks_pass"] = bool(required)
    return checks


def write_validation(checks: dict[str, object]) -> None:
    (OUTPUT_DIR / "MESH_AND_CLEARANCE_VALIDATION.json").write_text(
        json.dumps(checks, indent=2) + "\n",
        encoding="utf-8",
    )

    lines = [
        "# Potentiometer v1.3 mesh and clearance validation",
        "",
        f"- Watertight: `{checks['watertight']}`",
        f"- Winding consistent: `{checks['winding_consistent']}`",
        f"- Connected components: `{checks['components']}`",
        f"- Mesh extents: `{checks['extents_mm']} mm`",
        f"- Coupon-F C-shaped anchor feet: `{checks['anchor_feet_expected']}`",
        f"- Anchor-foot material present: `{checks['anchor_foot_material_present']}`",
        f"- All four +Y anchor notches open: `{checks['anchor_notches_open']}`",
        f"- All four Coupon-F clutch-bore centers open: `{checks['all_4_coupon_f_bore_centers_open']}`",
        f"- All 11 non-clutch roof supports solid through Z=2.80 mm: `{checks['all_11_non_clutch_roof_supports_solid']}`",
        f"- All 24 original LEGO stud centers open: `{checks['all_24_body_stud_centers_open']}`",
        f"- Four continuation-stud centers under tabs open: `{checks['four_tab_stud_centers_open']}`",
        f"- Both tab-to-base portals open: `{checks['tab_portals_open']}`",
        f"- All three M3 nut-loading paths open: `{checks['all_three_m3_nut_paths_open']}`",
        f"- Both brass-fastener slits open through the tabs: `{checks['both_brad_slits_open_through_tab']}`",
        f"- Potentiometer bushing center open: `{checks['panel_bushing_center_open']}`",
        f"- All required automated checks pass: `{checks['all_required_checks_pass']}`",
        "",
        "The tab placement is on the two long sides, away from the three +X M3 nut-loading paths.",
        "The 11 solid between-stud supports address the cavity-roof bridge failure observed in the physical v1.2 print.",
        "The mesh checks do not replace a pilot print with the actual potentiometer, LEGO plate, M3 hardware, cardboard, and brass fasteners.",
        "",
    ]
    (OUTPUT_DIR / "MESH_AND_CLEARANCE_VALIDATION.md").write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def write_dimensions(mesh: trimesh.Trimesh) -> None:
    rows = [
        ("Feature", "Value"),
        ("LEGO body footprint", "6 x 4 studs / 48 x 32 mm"),
        ("Overall base with cardboard tabs", f"{mesh.extents[0]:.1f} x {mesh.extents[1]:.1f} mm"),
        ("LEGO interface", "Four Coupon-F split clutch tubes with C anchor feet"),
        ("Coupon-F clutch bores", "All four remain open"),
        ("Solid roof supports", "11 filled non-gripping between-stud tubes"),
        ("Support diameter x height", "5.20 x 2.85 mm"),
        ("Anchor feet", "Four first-layer C pads on Coupon-F tubes"),
        ("Anchor foot diameter x height", "6.00 x 0.60 mm"),
        ("Anchor notch", "1.55 x 4.20 mm, aligned to each +Y split"),
        ("Cardboard tabs", "Two open one-stud-wide x two-stud-long tabs"),
        ("Tab centers", "X = -4 mm; Y = -24 mm and +24 mm"),
        ("Brass-fastener slit", "3.4 x 1.8 mm capsule"),
        ("Brad head recess", "9.1 mm diameter x 1.22 mm deep"),
        ("Tab underside cavity", "6.4 x 16.0 x 2.72 mm"),
        ("Supported potentiometer", "16-17 mm panel-mount linear pot"),
        ("Default panel opening", "7.80 mm supportless teardrop"),
        ("Panel", "30 x 28 x 2.80 mm"),
        ("Default knob bore", "5.90 mm"),
        ("M3 terminal labels", "3V, SIG, GND"),
        ("M3 hardware", "3 x M3 x 6 mm, nuts, and 9-10 mm washers"),
    ]
    with (OUTPUT_DIR / "PLTW_Potentiometer_v1_3_Dimensions.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        csv.writer(handle).writerows(rows)


def transformed_knob() -> trimesh.Trimesh:
    knob = trimesh.load_mesh(
        OUTPUT_DIR
        / "PLTW_Potentiometer_v1_Combination_Dial_Knob_B5p9mm_DEFAULT.stl"
    ).copy()
    knob.apply_transform(
        trimesh.transformations.rotation_matrix(
            math.radians(-90.0),
            [0.0, 1.0, 0.0],
        )
    )
    knob.apply_translation([-33.2, 0.0, 25.0])
    return knob


def terminal_hardware() -> trimesh.Trimesh:
    pieces = []
    for x, y in TERMINALS.values():
        pieces.append(cylinder_at(x, y, 5.0, 0.75, z0=10.0))
        pieces.append(cylinder_at(x, y, 3.15, 2.0, z0=10.75))
    return trimesh.util.concatenate(pieces)


def render_isometric(
    specs: list[tuple[trimesh.Trimesh, tuple[int, int, int]]],
    filename: str,
    title: str,
    footer: str,
) -> None:
    view = np.array([1.0, -1.35, 0.82])
    view /= np.linalg.norm(view)
    right = np.cross(view, np.array([0.0, 0.0, 1.0]))
    right /= np.linalg.norm(right)
    up = np.cross(right, view)
    up /= np.linalg.norm(up)
    light = np.array([0.35, -0.45, 0.82])
    light /= np.linalg.norm(light)

    triangles = []
    projected_all = []
    for mesh, color in specs:
        tri3 = mesh.vertices[mesh.faces]
        normals = np.cross(
            tri3[:, 1] - tri3[:, 0],
            tri3[:, 2] - tri3[:, 0],
        )
        lengths = np.linalg.norm(normals, axis=1)
        valid = lengths > 1e-9
        normals[valid] /= lengths[valid, None]
        facing = normals @ view > -0.10
        for triangle, normal in zip(tri3[facing], normals[facing]):
            projected = np.column_stack(
                (triangle @ right, -(triangle @ up))
            )
            depth = float(np.mean(triangle @ view))
            shade = 0.70 + 0.30 * max(0.0, float(normal @ light))
            shaded = tuple(
                max(0, min(255, int(channel * shade)))
                for channel in color
            )
            triangles.append((depth, projected, shaded))
            projected_all.append(projected)

    all_points = np.vstack(projected_all)
    low = all_points.min(axis=0)
    high = all_points.max(axis=0)
    canvas = (1500, 1000)
    margin = 110
    scale = min(
        (canvas[0] - 2 * margin) / (high[0] - low[0]),
        (canvas[1] - 2 * margin - 100) / (high[1] - low[1]),
    )
    offset = np.array(
        [
            (canvas[0] - (high[0] - low[0]) * scale) / 2
            - low[0] * scale,
            100
            + (canvas[1] - 175 - (high[1] - low[1]) * scale) / 2
            - low[1] * scale,
        ]
    )

    image = Image.new("RGB", canvas, (247, 249, 252))
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    draw.text((45, 28), title, fill=(30, 40, 54), font=font)
    for _, projected, color in sorted(triangles, key=lambda item: item[0]):
        points = [
            (
                float(x * scale + offset[0]),
                float(y * scale + offset[1]),
            )
            for x, y in projected
        ]
        draw.polygon(points, fill=color)
    draw.text((45, 955), footer, fill=(30, 40, 54), font=font)
    image.save(OUTPUT_DIR / filename)


def render_previews(base: trimesh.Trimesh) -> None:
    reference = trimesh.load_mesh(
        OUTPUT_DIR / "Reference_16mm_P160_WH148_Potentiometer_Not_For_Print.stl"
    )
    knob = transformed_knob()
    hardware = terminal_hardware()

    render_isometric(
        [
            (base, (174, 184, 194)),
            (reference, (205, 126, 62)),
            (knob, (74, 137, 185)),
            (hardware, (195, 199, 203)),
        ],
        "PLTW_Potentiometer_v1_3_Assembly_Preview.png",
        "PLTW POTENTIOMETER v1.3 - SOLID ROOF SUPPORTS",
        "Open tabs, four clutch anchors, and 11 solid between-stud supports for the cavity roof.",
    )

    render_isometric(
        [(base, (174, 184, 194))],
        "PLTW_Potentiometer_v1_3_Top_Preview.png",
        "POTENTIOMETER v1.3 - PRINTABLE BASE",
        "Long-side tabs preserve all three M3 nut-loading openings on the +X end.",
    )

    underside = base.copy()
    underside.apply_transform(
        trimesh.transformations.rotation_matrix(
            math.radians(180.0),
            [1.0, 0.0, 0.0],
        )
    )
    render_isometric(
        [(underside, (174, 184, 194))],
        "PLTW_Potentiometer_v1_3_Underside_Preview.png",
        "POTENTIOMETER v1.3 - SUPPORTED LEGO UNDERSIDE",
        "Four Coupon-F bores stay open; 11 safe non-gripping centers are solid to carry the roof.",
    )


def create_package() -> None:
    package_names = [
        "README_FIRST.md",
        "P2p4_P3p2_ACTIVITY_GUIDE.md",
        OUTPUT_STL.name,
        "PLTW_Potentiometer_v1_Combination_Dial_Knob_B5p9mm_DEFAULT.stl",
        "PLTW_Potentiometer_v1_Accessible_Wing_Knob_B5p9mm_DEFAULT.stl",
        "PLTW_Potentiometer_v1_Bushing_Fit_Coupon_A7p4_B7p6_C7p8.stl",
        "PLTW_Potentiometer_v1_Shaft_Fit_Coupon_A5p7_B5p9_C6p1.stl",
        "PLTW_Potentiometer_v1_M3_Nut_Trap_Coupon.stl",
        BRAD_COUPON.name,
        "PLTW_Potentiometer_v1_3_Dimensions.csv",
        "MESH_AND_CLEARANCE_VALIDATION.md",
        "MESH_AND_CLEARANCE_VALIDATION.json",
        "PLTW_Potentiometer_v1_3_Assembly_Preview.png",
        "PLTW_Potentiometer_v1_3_Top_Preview.png",
        "PLTW_Potentiometer_v1_3_Underside_Preview.png",
    ]

    prefix = "PLTW_Potentiometer_Control_Dial_v1_3"
    with zipfile.ZipFile(
        OUTPUT_ZIP,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for name in package_names:
            archive.write(OUTPUT_DIR / name, f"{prefix}/{name}")
        archive.write(
            Path(__file__),
            f"{prefix}/SOURCE/{Path(__file__).name}",
        )


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    extract_original_assets()
    base = build_base()
    checks = validate(base)
    write_validation(checks)
    write_dimensions(base)
    render_previews(base)
    create_package()

    print(f"output_stl={OUTPUT_STL}")
    print(f"output_zip={OUTPUT_ZIP}")
    print(f"watertight={checks['watertight']}")
    print(f"winding={checks['winding_consistent']}")
    print(f"components={checks['components']}")
    print(f"extents_mm={checks['extents_mm']}")
    print(f"anchor_feet={checks['anchor_feet_expected']}")
    print(f"all_required_checks_pass={checks['all_required_checks_pass']}")

    if not checks["all_required_checks_pass"]:
        raise SystemExit("Required mesh or clearance validation failed")


if __name__ == "__main__":
    main()

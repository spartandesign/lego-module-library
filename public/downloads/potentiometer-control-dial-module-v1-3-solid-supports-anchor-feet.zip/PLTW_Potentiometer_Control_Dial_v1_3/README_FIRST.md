# PLTW Potentiometer Control Dial v1.3

Version 1.3 corrects the cavity-roof bridge failure seen in the physical v1.2
support-free print. It keeps the open long-side cardboard tabs and four
Coupon-F anchor feet, then turns the 11 safe non-gripping between-stud tube
centers into solid supports that reach the cavity roof.

## Do not print the circular end-tab base

Any potentiometer base with round cardboard ears centered on the short ends is
the superseded v1.1 geometry. The ear on the M3-loading end sits directly in
front of the middle terminal and blocks insertion of its nut. Do not use that
base.

The current v1.3 base is visually distinct: it has two rectangular, open-bottom
tabs on the long sides. The short +X end stays free so all three M3 nuts can be
loaded before the potentiometer is installed.

## Why v1.2 is superseded

The v1.2 mesh kept all 15 underside tube centers hollow. During the physical
print, those hollow first-layer islands did not provide dependable support for
the large horizontal cavity roof. The roof printed as loose bridge strands and
is not acceptable for classroom use.

## What changed

- Filled the 11 non-gripping between-stud tube centers with 5.20 mm diameter
  solid posts through Z = 2.85 mm, overlapping the cavity roof.
- Kept all four Coupon-F clutch bores open.
- Kept one 0.60 mm C-shaped first-layer anchor pad under each clutch tube.
- Kept every anchor notch aligned with the tube's existing `+Y` split.
- Retained the two open long-side cardboard tabs, 3.4 x 1.8 mm fastener slits,
  shallow 9.1 mm head recesses, and open tab-to-base portals.
- Preserved all three M3 nut-loading paths, the potentiometer panel opening,
  the two knob choices, and all fit coupons.

The solid posts are centered between LEGO studs; they do not occupy the LEGO
stud positions. Do not fill the four Coupon-F clutch bores.

## Printing

- Bambu A1 mini or comparable printer
- PLA with a 0.4 mm nozzle
- Bambu 0.20 mm Standard profile
- LEGO underside on the build plate
- Supports off; raft off
- Keep the remaining process settings at their defaults

## Pilot check

Print one base before classroom quantities. Inspect the entire cavity roof: it
should be carried by the 11 solid supports without loose bridge strands. Then
confirm full LEGO seating and removal, four compliant clutch tubes, all three
M3 nuts, potentiometer and knob fit, and both cardboard fasteners.

The physical v1.2 result is retained as the failure evidence for this change;
v1.2 should not be printed again.

# Potentiometer v1.3 mesh and clearance validation

- Watertight: `True`
- Winding consistent: `True`
- Connected components: `1`
- Mesh extents: `[48.0, 65.0, 38.0] mm`
- Coupon-F C-shaped anchor feet: `4`
- Anchor-foot material present: `True`
- All four +Y anchor notches open: `True`
- All four Coupon-F clutch-bore centers open: `True`
- All 11 non-clutch roof supports solid through Z=2.80 mm: `True`
- All 24 original LEGO stud centers open: `True`
- Four continuation-stud centers under tabs open: `True`
- Both tab-to-base portals open: `True`
- All three M3 nut-loading paths open: `True`
- Both brass-fastener slits open through the tabs: `True`
- Potentiometer bushing center open: `True`
- All required automated checks pass: `True`

The tab placement is on the two long sides, away from the three +X M3 nut-loading paths.
The 11 solid between-stud supports address the cavity-roof bridge failure observed in the physical v1.2 print.
The mesh checks do not replace a pilot print with the actual potentiometer, LEGO plate, M3 hardware, cardboard, and brass fasteners.

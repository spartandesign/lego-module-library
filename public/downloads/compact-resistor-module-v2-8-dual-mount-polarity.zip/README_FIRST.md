# PLTW Compact Resistor LEGO Module v2.8

This revision preserves the physically confirmed v2.7 LEGO underside and adds
raised polarity marks beside the top terminals.

- Left terminal: `+` (shared signal/sensor connection)
- Right terminal: `-` (GND)
- Symbols: 0.6 mm raised, positioned below the terminal washers
- LEGO interface, brass-fastener tabs, M3 nut pockets, and resistor cradle:
  unchanged from v2.7

## Hardware

- One axial resistor
- Two M3 nuts
- Two M3 x 6 mm screws
- Two 9-12 mm M3 washers

## Printing

- Print in the supplied orientation with the LEGO underside on the build plate.
- PLA, 0.20 mm Standard, 4 walls, 20% gyroid
- Supports off; raft off
- Use a 6-8 mm outer brim if corner lifting occurs.
- Keep the auxiliary fan off and avoid drafts.

The v2.7 LEGO fit was reported excellent. This v2.8 model changes only the
top labels, so the confirmed underside geometry is preserved exactly.

# PLTW Photocell Module Family v1.5

This package contains three compact LEGO/cardboard dual-mount modules for a 5 mm GL5516 or GL5528 photoresistor:

- **AMBIENT** — exposed sensor for room light and shadow interactions.
- **BEAM** — opposing walls help students aim a flashlight or interrupt a light path.
- **COVER** — a raised hood supports covered/uncovered and “secret compartment” interactions.

## Terminal convention

- `+` connects to **3V**.
- `P` connects to the micro:bit **signal pin / shared resistor junction**.

The photoresistor itself is non-polarized. These markings establish one repeatable classroom wiring convention.

## Mounting geometry

- Coupon-F LEGO clutch geometry is unchanged.
- Four Coupon-F split clutch tubes remain hollow at the corner positions of the underside tube grid.
- Eight non-gripping support tubes are solid at their original **between-stud** centers. They shorten cavity-roof bridge spans without occupying LEGO stud centers.
- Two open cardboard tabs accept the physically selected **3.4 × 1.8 mm** brass-fastener slit.
- The tab cavities remain open to the LEGO underside; there is no hidden partition below the brad head.
- End-loaded M3 nut paths remain unobstructed.

## Hardware

Per module:

- 1 × 5 mm GL5516 or GL5528 photoresistor
- 2 × M3 × 6 mm screws
- 2 × standard M3 hex nuts
- Optional 2 × paper craft brads for cardboard mounting

## Printing

Use the saved orientation with the LEGO underside on the build plate.

- Bambu 0.20 mm Standard profile
- Default Bambu settings
- Supports off
- Raft off

Do not print v1.4; its added feet were accidentally placed on LEGO stud centers. Print one v1.5 module as a pilot before classroom quantities. This correction is mesh-validated but still awaits physical confirmation.

## Assembly

1. Insert the two M3 nuts through the open end-loading slots.
2. Place one photoresistor lead at each terminal.
3. Install the M3 screws and tighten only enough to make reliable contact.
4. Connect `+` to 3V and `P` to the micro:bit signal/resistor junction.
5. Snap the module onto a LEGO plate, or pass brads through the end tabs and cardboard.

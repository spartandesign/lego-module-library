# Universal FSR Pressure Testbed v2.4

This pack combines the v2 interchangeable pressure surfaces with the v2.4 end-loaded M3 nut correction.

## Included

- v2.4 extended Coupon-F base with end-loaded nut tunnels
- v2.4 dual-connector M3 clamp
- Three-guide carrier
- Flat 45 mm, narrow 45 x 20 mm, and accessible 55 mm tops
- 1.0 and 1.2 mm actuator pucks

## Assembly

1. Insert both M3 nuts through the extended connector end before installing the sensor.
2. Keep the FSR flat and centered in its pocket.
3. Use the clamp to retain the sensor connector and the alligator-clip adapter without pinching either cable.
4. Install the guide carrier, one top, and the 1.0 mm puck.
5. Check free movement and safe hard-stop contact before applying force.

Use two M3 x 8 mm screws. This is an input/trigger testbed, not a calibrated scale.

## Print

- Bambu A1 mini, 0.20 mm Standard
- PLA, four walls, 20% gyroid
- Supports off; preserve supplied orientations

Status: v2.4 corrects the nut-to-screw alignment problem found in v2.3. The complete v2.4 combination is a prototype pending a physical pilot print.
